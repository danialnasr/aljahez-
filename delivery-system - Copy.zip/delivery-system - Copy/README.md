# نظام التوصيل الاحترافي - Delivery System

## نظرة عامة

نظام التوصيل الاحترافي هو منصة شاملة لإدارة خدمات التوصيل تدعم أنواع مختلفة من المستخدمين (العملاء، السائقين، التجار، المديرين) مع نظام مدفوعات متكامل ونظام نقاط الولاء.

## الميزات الرئيسية

### 🔐 نظام المصادقة المتقدم
- مصادقة باستخدام OTP عبر SMS/WhatsApp/Telegram/Email
- دعم أنواع مستخدمين متعددة
- نظام أذونات متدرج
- حماية أمنية متقدمة

### 📱 إدارة المستخدمين
- **العملاء العاديين**: طلب وتتبع الطلبات
- **السائقين**: قبول وتوصيل الطلبات
- **التجار**: إدارة المنتجات والطلبات
- **المديرين**: إدارة النظام والمراقبة

### 🛒 نظام الطلبات الذكي
- إنشاء طلبات متعددة التجار
- تتبع حالة الطلب في الوقت الفعلي
- نظام OTP للتحقق من التسليم
- إدارة أوقات التحضير والتوصيل

### 💳 نظام المدفوعات المتكامل
- دعم المحفظة الرقمية
- دعم البطاقات الائتمانية
- دعم زين كاش
- الدفع نقداً عند التسليم
- توزيع تلقائي للأرباح والعمولات

### 🎯 نظام نقاط الولاء
- كسب نقاط مع كل عملية شراء
- استبدال النقاط بخصومات
- تتبع معاملات النقاط

### ⭐ نظام التقييمات والشكاوى
- تقييم السائقين والتجار
- نظام شكاوى شامل
- إدارة التقييمات والتعليقات

### 🔔 نظام الإشعارات
- إشعارات فورية عبر FCM
- رسائل SMS
- رسائل WhatsApp
- إشعارات البريد الإلكتروني

## متطلبات النظام

- PHP 8.1 أو أحدث
- Laravel 10.x
- SQLite/MySQL/PostgreSQL
- Composer
- Node.js 16+ (للتطوير الأمامي)
- Git

## التثبيت

### 1. استنساخ المشروع
```bash
git clone https://github.com/your-username/delivery-system.git
cd delivery-system
```

### 2. تثبيت التبعيات
```bash
# تثبيت تبعيات PHP
composer install

# تثبيت تبعيات Node.js (إذا كان هناك frontend)
npm install
```

### 3. إعداد البيئة
```bash
# نسخ ملف البيئة
cp .env.example .env

# إنشاء مفتاح التطبيق
php artisan key:generate
```

### 4. إعداد قاعدة البيانات

#### للـ SQLite (الافتراضي)
```bash
# إنشاء ملف قاعدة البيانات
touch database/database.sqlite

# تحديث ملف .env
DB_CONNECTION=sqlite
DB_DATABASE=database/database.sqlite
```

#### للـ MySQL
```env
DB_CONNECTION=mysql
DB_HOST=127.0.0.1
DB_PORT=3306
DB_DATABASE=delivery_system
DB_USERNAME=your_username
DB_PASSWORD=your_password
```

#### للـ PostgreSQL
```env
DB_CONNECTION=pgsql
DB_HOST=127.0.0.1
DB_PORT=5432
DB_DATABASE=delivery_system
DB_USERNAME=your_username
DB_PASSWORD=your_password
```

### 5. تشغيل migrations وإنشاء البيانات التجريبية
```bash
# تشغيل migrations
php artisan migrate

# إنشاء بيانات تجريبية (اختياري)
php artisan db:seed

# أو تشغيل migrations مع البيانات التجريبية معاً
php artisan migrate:fresh --seed
```

### 6. إنشاء رابط التخزين
```bash
php artisan storage:link
```

### 7. إعداد الصلاحيات (Linux/Mac)
```bash
chmod -R 775 storage bootstrap/cache
```

### 8. تشغيل الخادم
```bash
# تشغيل خادم Laravel
php artisan serve

# تشغيل queue worker (في terminal منفصل)
php artisan queue:work

# تشغيل scheduler (في production)
# أضف هذا السطر إلى crontab
# * * * * * cd /path-to-your-project && php artisan schedule:run >> /dev/null 2>&1
```

## إعداد المتغيرات البيئية

### إعدادات التطبيق الأساسية
```env
APP_NAME="Delivery System"
APP_ENV=local
APP_KEY=base64:your_generated_key
APP_DEBUG=true
APP_URL=http://localhost:8000

# إعدادات الـ timezone
APP_TIMEZONE=Asia/Baghdad
```

### قاعدة البيانات
```env
DB_CONNECTION=sqlite
DB_DATABASE=database/database.sqlite
```

### خدمات الإشعارات
```env
# Firebase Cloud Messaging
FCM_SERVER_KEY=your_fcm_server_key

# SMS Service (Twilio مثلاً)
SMS_API_URL=https://api.twilio.com/2010-04-01
SMS_API_KEY=your_twilio_account_sid
SMS_API_SECRET=your_twilio_auth_token
SMS_FROM_NUMBER=+1234567890

# WhatsApp Business API
WHATSAPP_API_URL=https://graph.facebook.com/v17.0
WHATSAPP_TOKEN=your_whatsapp_token
WHATSAPP_PHONE_NUMBER_ID=your_phone_number_id

# Telegram Bot API
TELEGRAM_BOT_TOKEN=your_telegram_bot_token

# Email Configuration
MAIL_MAILER=smtp
MAIL_HOST=smtp.gmail.com
MAIL_PORT=587
MAIL_USERNAME=your_email@gmail.com
MAIL_PASSWORD=your_app_password
MAIL_ENCRYPTION=tls
MAIL_FROM_ADDRESS=your_email@gmail.com
MAIL_FROM_NAME="${APP_NAME}"
```

### خدمات الدفع
```env
# Stripe
STRIPE_KEY=pk_test_your_stripe_publishable_key
STRIPE_SECRET=sk_test_your_stripe_secret_key
STRIPE_WEBHOOK_SECRET=whsec_your_webhook_secret

# Zain Cash
ZAIN_CASH_API_URL=https://test.zaincash.iq/transaction
ZAIN_CASH_MERCHANT_ID=your_merchant_id
ZAIN_CASH_SECRET_KEY=your_secret_key
ZAIN_CASH_MSISDN=your_msisdn
```

### خدمات الخرائط والموقع
```env
# Google Maps API
GOOGLE_MAPS_API_KEY=your_google_maps_api_key

# Here Maps API (بديل)
HERE_API_KEY=your_here_api_key
```

### إعدادات الـ Queue والـ Cache
```env
# Queue Configuration
QUEUE_CONNECTION=database

# Cache Configuration
CACHE_DRIVER=file
SESSION_DRIVER=file
```

### إعدادات الأمان
```env
# Rate Limiting
RATE_LIMIT_PER_MINUTE=60
OTP_RATE_LIMIT_PER_HOUR=5

# Security Headers
SECURITY_HEADERS_ENABLED=true
```

## هيكل API

### المصادقة
```
POST /api/v1/auth/send-otp          # إرسال رمز OTP
POST /api/v1/auth/verify-otp        # التحقق من OTP
POST /api/v1/auth/register          # تسجيل حساب جديد
POST /api/v1/auth/logout            # تسجيل الخروج
GET  /api/v1/auth/me                # معلومات المستخدم الحالي
POST /api/v1/auth/refresh-token     # تحديث التوكن
POST /api/v1/auth/test-otp          # اختبار OTP (للتطوير فقط)
```

### إدارة المستخدمين
```
GET    /api/v1/user/profile         # عرض الملف الشخصي
PUT    /api/v1/user/profile         # تحديث الملف الشخصي
POST   /api/v1/user/upload-image    # رفع صورة الملف الشخصي
PUT    /api/v1/user/location        # تحديث الموقع
PUT    /api/v1/user/password        # تغيير كلمة المرور
```

### الطلبات
```
GET    /api/v1/orders               # قائمة الطلبات
POST   /api/v1/orders               # إنشاء طلب جديد
GET    /api/v1/orders/{id}          # تفاصيل طلب محدد
PUT    /api/v1/orders/{id}/status   # تحديث حالة الطلب
POST   /api/v1/orders/{id}/verify-delivery  # تأكيد التسليم
POST   /api/v1/orders/{id}/accept-delivery  # قبول التوصيل
POST   /api/v1/orders/{id}/cancel   # إلغاء الطلب
GET    /api/v1/orders/{id}/track    # تتبع الطلب
```

### المنتجات والفئات
```
GET    /api/v1/categories           # قائمة الفئات
GET    /api/v1/products             # قائمة المنتجات
POST   /api/v1/products             # إضافة منتج جديد (للتجار)
GET    /api/v1/products/{id}        # تفاصيل منتج
PUT    /api/v1/products/{id}        # تحديث منتج
DELETE /api/v1/products/{id}        # حذف منتج
GET    /api/v1/products/search      # البحث في المنتجات
POST   /api/v1/products/{id}/toggle-availability  # تفعيل/إلغاء المنتج
```

### التجار
```
GET    /api/v1/merchants            # قائمة التجار
GET    /api/v1/merchants/{id}       # تفاصيل تاجر
GET    /api/v1/merchants/{id}/products  # منتجات تاجر محدد
```

### السائقين
```
POST   /api/v1/driver/online        # تفعيل حالة متاح
POST   /api/v1/driver/offline       # تفعيل حالة غير متاح
GET    /api/v1/driver/orders        # طلبات السائق
GET    /api/v1/driver/earnings      # أرباح السائق
GET    /api/v1/driver/stats         # إحصائيات السائق
PUT    /api/v1/driver/location      # تحديث موقع السائق
```

### المحفظة والمعاملات المالية
```
GET    /api/v1/wallet               # رصيد المحفظة
POST   /api/v1/wallet/topup        # شحن المحفظة
GET    /api/v1/wallet/transactions # تاريخ المعاملات
POST   /api/v1/wallet/withdraw     # سحب من المحفظة
```

### نقاط الولاء
```
GET    /api/v1/loyalty/points       # نقاط الولاء الحالية
POST   /api/v1/loyalty/redeem       # استبدال النقاط
GET    /api/v1/loyalty/transactions # تاريخ نقاط الولاء
GET    /api/v1/loyalty/rewards      # المكافآت المتاحة
```

### التقييمات والشكاوى
```
POST   /api/v1/ratings             # إضافة تقييم
GET    /api/v1/ratings/{id}        # عرض تقييم
PUT    /api/v1/ratings/{id}        # تحديث تقييم
DELETE /api/v1/ratings/{id}        # حذف تقييم

POST   /api/v1/complaints          # تقديم شكوى
GET    /api/v1/complaints          # قائمة الشكاوى
GET    /api/v1/complaints/{id}     # تفاصيل شكوى
PUT    /api/v1/complaints/{id}     # تحديث شكوى
```

### البحث المتقدم
```
GET    /api/v1/search              # البحث العام
GET    /api/v1/search/advanced     # البحث المتقدم
GET    /api/v1/search/suggestions  # اقتراحات البحث
GET    /api/v1/search/products     # البحث في المنتجات
GET    /api/v1/search/merchants    # البحث في التجار
GET    /api/v1/search/popular      # البحثات الشائعة
```

### لوحة الإدارة (Admin)
```
GET    /api/v1/admin/users         # إدارة المستخدمين
GET    /api/v1/admin/orders        # إدارة الطلبات
GET    /api/v1/admin/merchants     # إدارة التجار
GET    /api/v1/admin/drivers       # إدارة السائقين
GET    /api/v1/admin/analytics     # الإحصائيات والتحليلات
GET    /api/v1/admin/complaints    # إدارة الشكاوى
POST   /api/v1/admin/categories    # إدارة الفئات
PUT    /api/v1/admin/settings      # إعدادات النظام
```
