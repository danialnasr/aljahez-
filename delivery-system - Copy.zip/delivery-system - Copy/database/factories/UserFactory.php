<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\User>
 */
class UserFactory extends Factory
{
    /**
     * The current password being used by the factory.
     */
    protected static ?string $password;

    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        return [
            'phone' => fake()->unique()->phoneNumber(),
            'email' => fake()->unique()->safeEmail(),
            'full_name' => fake()->name(),
            'user_type' => fake()->randomElement(['regular', 'driver', 'merchant']),
            'profile_image' => fake()->imageUrl(),
            'home_lat' => fake()->latitude(),
            'home_lng' => fake()->longitude(),
            'home_address' => fake()->address(),
            'is_active' => true,
            'is_online' => fake()->boolean(),
            'wallet_balance' => fake()->randomFloat(2, 0, 1000),
            'loyalty_points' => fake()->numberBetween(0, 500),
            'rating_count' => fake()->numberBetween(0, 100),
            'rating_average' => fake()->randomFloat(2, 1, 5),
            'email_verified_at' => now(),
            'password' => static::$password ??= Hash::make('password'),
            'remember_token' => Str::random(10),
        ];
    }

    /**
     * Indicate that the model's email address should be unverified.
     */
    public function unverified(): static
    {
        return $this->state(fn (array $attributes) => [
            'email_verified_at' => null,
        ]);
    }

    /**
     * Create a regular user.
     */
    public function regular(): static
    {
        return $this->state(fn (array $attributes) => [
            'user_type' => 'regular',
        ]);
    }

    /**
     * Create a driver user.
     */
    public function driver(): static
    {
        return $this->state(fn (array $attributes) => [
            'user_type' => 'driver',
            'vin_number' => fake()->bothify('??###??###'),
            'id_card_image' => fake()->imageUrl(),
            'is_freelance' => fake()->boolean(),
        ]);
    }

    /**
     * Create a merchant user.
     */
    public function merchant(): static
    {
        return $this->state(fn (array $attributes) => [
            'user_type' => 'merchant',
            'business_type' => fake()->randomElement(['restaurant', 'grocery', 'pharmacy', 'electronics']),
            'id_card_image' => fake()->imageUrl(),
            'bank_card' => fake()->creditCardNumber(),
            'working_hours' => [
                'monday' => ['09:00', '22:00'],
                'tuesday' => ['09:00', '22:00'],
                'wednesday' => ['09:00', '22:00'],
                'thursday' => ['09:00', '22:00'],
                'friday' => ['09:00', '22:00'],
                'saturday' => ['10:00', '23:00'],
                'sunday' => ['10:00', '21:00'],
            ],
        ]);
    }

    /**
     * Create an admin user.
     */
    public function admin(): static
    {
        return $this->state(fn (array $attributes) => [
            'user_type' => 'admin',
        ]);
    }
}
