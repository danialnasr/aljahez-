<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        // Orders table indexes for performance
        Schema::table('orders', function (Blueprint $table) {
            $table->index(['customer_id', 'status'], 'orders_customer_status_idx');
            $table->index(['driver_id', 'status'], 'orders_driver_status_idx');
            $table->index(['status', 'created_at'], 'orders_status_created_idx');
            $table->index(['payment_status'], 'orders_payment_status_idx');
            $table->index(['delivery_lat', 'delivery_lng'], 'orders_delivery_location_idx');
            $table->index(['created_at'], 'orders_created_at_idx');
        });

        // Order items table indexes
        Schema::table('order_items', function (Blueprint $table) {
            $table->index(['order_id'], 'order_items_order_idx');
            $table->index(['product_id'], 'order_items_product_idx');
            $table->index(['merchant_id'], 'order_items_merchant_idx');
            $table->index(['merchant_id', 'created_at'], 'order_items_merchant_created_idx');
        });

        // Products table indexes
        Schema::table('products', function (Blueprint $table) {
            $table->index(['category_id', 'is_available'], 'products_category_available_idx');
            $table->index(['merchant_id', 'is_available'], 'products_merchant_available_idx');
            $table->index(['is_available', 'stock_quantity'], 'products_available_stock_idx');
            $table->index(['price'], 'products_price_idx');
            $table->index(['created_at'], 'products_created_at_idx');
        });

        // Users table indexes
        Schema::table('users', function (Blueprint $table) {
            $table->index(['user_type', 'is_active'], 'users_type_active_idx');
            $table->index(['phone'], 'users_phone_idx');
            $table->index(['email'], 'users_email_idx');
            $table->index(['lat', 'lng'], 'users_location_idx');
            $table->index(['is_active', 'created_at'], 'users_active_created_idx');
        });

        // Wallet transactions indexes
        Schema::table('wallet_transactions', function (Blueprint $table) {
            $table->index(['user_id', 'type'], 'wallet_transactions_user_type_idx');
            $table->index(['user_id', 'created_at'], 'wallet_transactions_user_created_idx');
            $table->index(['order_id'], 'wallet_transactions_order_idx');
            $table->index(['type', 'created_at'], 'wallet_transactions_type_created_idx');
        });

        // Loyalty transactions indexes
        Schema::table('loyalty_transactions', function (Blueprint $table) {
            $table->index(['user_id', 'type'], 'loyalty_transactions_user_type_idx');
            $table->index(['user_id', 'created_at'], 'loyalty_transactions_user_created_idx');
            $table->index(['type', 'status'], 'loyalty_transactions_type_status_idx');
            $table->index(['created_at'], 'loyalty_transactions_created_idx');
        });

        // OTP codes indexes
        Schema::table('otp_codes', function (Blueprint $table) {
            $table->index(['phone', 'expires_at'], 'otp_codes_phone_expires_idx');
            $table->index(['phone', 'is_used'], 'otp_codes_phone_used_idx');
            $table->index(['expires_at'], 'otp_codes_expires_idx');
        });

        // Categories table indexes
        Schema::table('categories', function (Blueprint $table) {
            $table->index(['is_active'], 'categories_active_idx');
            $table->index(['name'], 'categories_name_idx');
        });

        // Ratings table indexes
        Schema::table('ratings', function (Blueprint $table) {
            $table->index(['user_id'], 'ratings_user_idx');
            $table->index(['rated_user_id'], 'ratings_rated_user_idx');
            $table->index(['order_id'], 'ratings_order_idx');
            $table->index(['type', 'rating'], 'ratings_type_rating_idx');
            $table->index(['created_at'], 'ratings_created_idx');
        });

        // Complaints table indexes
        Schema::table('complaints', function (Blueprint $table) {
            $table->index(['user_id'], 'complaints_user_idx');
            $table->index(['order_id'], 'complaints_order_idx');
            $table->index(['status'], 'complaints_status_idx');
            $table->index(['type'], 'complaints_type_idx');
            $table->index(['created_at'], 'complaints_created_idx');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        // Drop all indexes
        Schema::table('orders', function (Blueprint $table) {
            $table->dropIndex('orders_customer_status_idx');
            $table->dropIndex('orders_driver_status_idx');
            $table->dropIndex('orders_status_created_idx');
            $table->dropIndex('orders_payment_status_idx');
            $table->dropIndex('orders_delivery_location_idx');
            $table->dropIndex('orders_created_at_idx');
        });

        Schema::table('order_items', function (Blueprint $table) {
            $table->dropIndex('order_items_order_idx');
            $table->dropIndex('order_items_product_idx');
            $table->dropIndex('order_items_merchant_idx');
            $table->dropIndex('order_items_merchant_created_idx');
        });

        Schema::table('products', function (Blueprint $table) {
            $table->dropIndex('products_category_available_idx');
            $table->dropIndex('products_merchant_available_idx');
            $table->dropIndex('products_available_stock_idx');
            $table->dropIndex('products_price_idx');
            $table->dropIndex('products_created_at_idx');
        });

        Schema::table('users', function (Blueprint $table) {
            $table->dropIndex('users_type_active_idx');
            $table->dropIndex('users_phone_idx');
            $table->dropIndex('users_email_idx');
            $table->dropIndex('users_location_idx');
            $table->dropIndex('users_active_created_idx');
        });

        Schema::table('wallet_transactions', function (Blueprint $table) {
            $table->dropIndex('wallet_transactions_user_type_idx');
            $table->dropIndex('wallet_transactions_user_created_idx');
            $table->dropIndex('wallet_transactions_order_idx');
            $table->dropIndex('wallet_transactions_type_created_idx');
        });

        Schema::table('loyalty_transactions', function (Blueprint $table) {
            $table->dropIndex('loyalty_transactions_user_type_idx');
            $table->dropIndex('loyalty_transactions_user_created_idx');
            $table->dropIndex('loyalty_transactions_type_status_idx');
            $table->dropIndex('loyalty_transactions_created_idx');
        });

        Schema::table('otp_codes', function (Blueprint $table) {
            $table->dropIndex('otp_codes_phone_expires_idx');
            $table->dropIndex('otp_codes_phone_used_idx');
            $table->dropIndex('otp_codes_expires_idx');
        });

        Schema::table('categories', function (Blueprint $table) {
            $table->dropIndex('categories_active_idx');
            $table->dropIndex('categories_name_idx');
        });

        Schema::table('ratings', function (Blueprint $table) {
            $table->dropIndex('ratings_user_idx');
            $table->dropIndex('ratings_rated_user_idx');
            $table->dropIndex('ratings_order_idx');
            $table->dropIndex('ratings_type_rating_idx');
            $table->dropIndex('ratings_created_idx');
        });

        Schema::table('complaints', function (Blueprint $table) {
            $table->dropIndex('complaints_user_idx');
            $table->dropIndex('complaints_order_idx');
            $table->dropIndex('complaints_status_idx');
            $table->dropIndex('complaints_type_idx');
            $table->dropIndex('complaints_created_idx');
        });
    }
};
