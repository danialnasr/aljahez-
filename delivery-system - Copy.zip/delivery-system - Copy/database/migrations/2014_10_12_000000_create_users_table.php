<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('users', function (Blueprint $table) {
            $table->id();
            $table->string('phone')->unique();
            $table->string('email')->nullable()->unique();
            $table->timestamp('email_verified_at')->nullable();
            $table->string('password')->nullable();
            $table->enum('user_type', ['regular', 'driver', 'merchant', 'temp', 'admin'])->default('regular');
            $table->string('full_name');
            $table->string('profile_image')->nullable();
            $table->decimal('home_lat', 10, 8)->nullable();
            $table->decimal('home_lng', 11, 8)->nullable();
            $table->string('home_address')->nullable();
            $table->string('id_card_image')->nullable();
            $table->string('vin_number')->nullable();
            $table->string('business_type')->nullable();
            $table->boolean('is_active')->default(false);
            $table->boolean('is_online')->default(false);
            $table->json('working_hours')->nullable();
            $table->string('bank_card')->nullable();
            $table->decimal('wallet_balance', 10, 2)->default(0);
            $table->integer('rating_count')->default(0);
            $table->decimal('rating_average', 3, 2)->default(0);
            $table->integer('loyalty_points')->default(0);
            $table->boolean('is_freelance')->default(false);
            $table->string('fcm_token')->nullable();
            $table->string('internal_otp')->nullable();
            $table->rememberToken();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('users');
    }
};
