# 📚 Delivery System API - Comprehensive Endpoint Descriptions

This document provides detailed descriptions for all API endpoints in the Postman collection to help developers understand and use the delivery system API effectively.

## 🔐 Authentication Endpoints

### 1. **Auth - Send OTP**
- **Purpose**: Initiates passwordless authentication by sending OTP to user's phone
- **Method**: POST `/api/v1/auth/send-otp`
- **Features**: 
  - Rate limited (5 requests/hour per phone)
  - Multi-channel delivery (SMS, WhatsApp, Telegram, Email)
  - Input sanitization and validation
- **Required Fields**: `phone`, `type`
- **Use Cases**: User registration, login, phone verification

### 2. **Auth - Verify OTP**
- **Purpose**: Verifies OTP code and returns authentication token
- **Method**: POST `/api/v1/auth/verify-otp`
- **Features**:
  - Rate limited (10 attempts/hour per phone)
  - Auto-expiration (5 minutes)
  - Secure token generation
- **Required Fields**: `phone`, `otp`
- **Response**: Bearer token for API authentication

### 3. **Auth - Register**
- **Purpose**: Creates new user account with role-based access
- **Method**: POST `/api/v1/auth/register`
- **Features**:
  - Multi-role support (regular, merchant, driver, admin)
  - Location integration
  - Automatic wallet creation
- **Required Fields**: `phone`, `full_name`, `user_type`, `email`, `home_lat`, `home_lng`, `home_address`

### 4. **Auth - Login (OTP)**
- **Purpose**: Alternative login endpoint for existing users
- **Method**: POST `/api/v1/auth/verify-otp`
- **Features**: Same as verify-otp but for returning users
- **Required Fields**: `phone`, `otp`

### 5. **Auth - Me (Get Profile)**
- **Purpose**: Retrieves authenticated user's profile information
- **Method**: GET `/api/v1/auth/me`
- **Authentication**: Bearer token required
- **Response**: Complete user profile with role-specific data

### 6. **Auth - Logout**
- **Purpose**: Invalidates user session and token
- **Method**: POST `/api/v1/auth/logout`
- **Authentication**: Bearer token required
- **Features**: Secure session termination

### 7. **Auth - Refresh Token**
- **Purpose**: Generates new authentication token
- **Method**: POST `/api/v1/auth/refresh-token`
- **Authentication**: Valid Bearer token required
- **Features**: Extends session without re-authentication

## 🛍️ Product & Category Endpoints

### 8. **Products - List All**
- **Purpose**: Retrieves paginated list of available products
- **Method**: GET `/api/v1/products`
- **Features**:
  - Pagination support
  - Filtering by category, merchant, availability
  - Search functionality
  - Performance optimized with database indexes

### 9. **Products - Get Single Product**
- **Purpose**: Retrieves detailed information for specific product
- **Method**: GET `/api/v1/products/{id}`
- **Features**:
  - Complete product details
  - Merchant information
  - Category data
  - Stock availability

### 10. **Products - Search**
- **Purpose**: Searches products by name, description, or keywords
- **Method**: GET `/api/v1/products/search?q={query}`
- **Features**:
  - Full-text search
  - Relevance scoring
  - Filter combinations
  - Fast response with indexes

### 11. **Categories - List All**
- **Purpose**: Retrieves all active product categories
- **Method**: GET `/api/v1/categories`
- **Features**:
  - Multi-language support (Arabic/English)
  - Image URLs
  - Active status filtering

### 12. **Products - Create Product (Merchant)**
- **Purpose**: Allows merchants to add new products
- **Method**: POST `/api/v1/products`
- **Authentication**: Merchant role required
- **Required Fields**: `name`, `name_ar`, `description`, `price`, `category_id`, `images`

## 🏪 Merchant Endpoints

### 13. **Merchants - List All**
- **Purpose**: Retrieves list of active merchants
- **Method**: GET `/api/v1/merchants`
- **Features**:
  - Location-based filtering
  - Search by name, phone, email
  - Distance calculation
  - Pagination support

### 14. **Merchant - Get Orders**
- **Purpose**: Retrieves orders for authenticated merchant
- **Method**: GET `/api/v1/merchant/orders`
- **Authentication**: Merchant role required
- **Features**: Status filtering, date range, pagination

### 15. **Merchant - Accept Order**
- **Purpose**: Allows merchant to accept incoming orders
- **Method**: POST `/api/v1/merchant/orders/{id}/accept`
- **Authentication**: Merchant role required
- **Required Fields**: `estimated_preparation_time`

## 📦 Order Management Endpoints

### 16. **Orders - List My Orders**
- **Purpose**: Retrieves user's order history
- **Method**: GET `/api/v1/orders`
- **Authentication**: Bearer token required
- **Features**:
  - Role-based filtering (customer/driver/merchant view)
  - Status filtering
  - Date range queries

### 17. **Orders - Create New Order**
- **Purpose**: Creates new delivery order with race condition protection
- **Method**: POST `/api/v1/orders`
- **Authentication**: Bearer token required
- **Features**:
  - Stock reservation with database locks
  - Distance validation
  - Delivery time estimation
  - Payment method validation
- **Required Fields**: `items`, `delivery_lat`, `delivery_lng`, `delivery_address`, `payment_method`

### 18. **Orders - Get Single Order**
- **Purpose**: Retrieves detailed order information
- **Method**: GET `/api/v1/orders/{id}`
- **Authentication**: Bearer token required
- **Features**: Real-time tracking, route planning, status updates

### 19. **Orders - Update Status**
- **Purpose**: Updates order status with state machine validation
- **Method**: PUT `/api/v1/orders/{id}/status`
- **Authentication**: Role-based permissions
- **Features**:
  - State transition validation
  - Permission checking
  - Payment processing on delivery

### 20. **Orders - Cancel Order**
- **Purpose**: Cancels order with proper rollback
- **Method**: POST `/api/v1/orders/{id}/cancel`
- **Authentication**: Bearer token required
- **Features**: Stock release, refund processing, notification

## 🚗 Driver Endpoints

### 21. **Driver - Go Online**
- **Purpose**: Sets driver status to available for orders
- **Method**: POST `/api/v1/driver/online`
- **Authentication**: Driver role required
- **Features**: Location tracking, availability management

### 22. **Driver - Get Available Orders**
- **Purpose**: Retrieves orders available for pickup
- **Method**: GET `/api/v1/driver/orders`
- **Authentication**: Driver role required
- **Features**: Distance-based filtering, priority sorting

### 23. **Driver - Accept Order**
- **Purpose**: Assigns order to driver
- **Method**: POST `/api/v1/driver/orders/{id}/accept`
- **Authentication**: Driver role required
- **Features**: Automatic assignment, route calculation

### 24. **Driver - Update Location**
- **Purpose**: Updates driver's real-time location
- **Method**: PUT `/api/v1/driver/location`
- **Authentication**: Driver role required
- **Required Fields**: `lat`, `lng`

## 👤 User Profile Endpoints

### 25. **User - Get Profile**
- **Purpose**: Retrieves detailed user profile
- **Method**: GET `/api/v1/user/profile`
- **Authentication**: Bearer token required
- **Features**: Complete profile data, preferences, statistics

### 26. **User - Update Profile**
- **Purpose**: Updates user profile information
- **Method**: PUT `/api/v1/user/profile`
- **Authentication**: Bearer token required
- **Features**: Input validation, data sanitization

### 27. **User - Update Location**
- **Purpose**: Updates user's location coordinates
- **Method**: PUT `/api/v1/user/profile/location`
- **Authentication**: Bearer token required
- **Required Fields**: `lat`, `lng`, `address`

## 💰 Wallet & Payment Endpoints

### 28. **Wallet - Get Balance**
- **Purpose**: Retrieves user's wallet balance with race condition protection
- **Method**: GET `/api/v1/wallet`
- **Authentication**: Bearer token required
- **Features**: Atomic balance calculation, transaction history

### 29. **Wallet - Top Up**
- **Purpose**: Adds funds to user wallet via payment gateway
- **Method**: POST `/api/v1/wallet/topup`
- **Authentication**: Bearer token required
- **Features**:
  - Real payment gateway integration (Stripe, Zain Cash)
  - Transaction safety
  - Fraud protection
- **Required Fields**: `amount`, `payment_method`, `payment_token`

### 30. **Wallet - Get Transactions**
- **Purpose**: Retrieves wallet transaction history
- **Method**: GET `/api/v1/wallet/transactions`
- **Authentication**: Bearer token required
- **Features**: Pagination, filtering, audit trail

## 🎁 Loyalty Program Endpoints

### 31. **Loyalty - Get Points**
- **Purpose**: Retrieves user's loyalty points with race condition protection
- **Method**: GET `/api/v1/loyalty/points`
- **Authentication**: Bearer token required
- **Features**: Atomic point calculation, real-time balance

### 32. **Loyalty - Redeem Points**
- **Purpose**: Redeems loyalty points for rewards
- **Method**: POST `/api/v1/loyalty/redeem`
- **Authentication**: Bearer token required
- **Features**:
  - Atomic redemption with database locks
  - Validation and error handling
  - Audit logging
- **Required Fields**: `points`, `reward_type`

## ⭐ Rating & Review Endpoints

### 33. **Ratings - Create Rating**
- **Purpose**: Allows users to rate orders, drivers, or merchants
- **Method**: POST `/api/v1/ratings`
- **Authentication**: Bearer token required
- **Features**: Validation, duplicate prevention, statistics update
- **Required Fields**: `rated_user_id`, `rating`, `type`

## 📞 Complaint Management Endpoints

### 34. **Complaints - List My Complaints**
- **Purpose**: Retrieves user's complaint history
- **Method**: GET `/api/v1/complaints`
- **Authentication**: Bearer token required
- **Features**: Role-based filtering, status tracking

### 35. **Complaints - Create Complaint**
- **Purpose**: Creates new complaint about order or service
- **Method**: POST `/api/v1/complaints`
- **Authentication**: Bearer token required
- **Features**: Categorization, priority assignment, notification
- **Required Fields**: `order_id`, `type`, `description`

## 🛡️ Admin Endpoints

### 36. **Admin - Dashboard**
- **Purpose**: Provides comprehensive system metrics and analytics
- **Method**: GET `/api/v1/admin/dashboard`
- **Authentication**: Admin role required
- **Features**:
  - Real-time statistics
  - Performance metrics
  - Business intelligence data

### 37. **Admin - Get All Users**
- **Purpose**: Retrieves system users with management capabilities
- **Method**: GET `/api/v1/admin/users`
- **Authentication**: Admin role required
- **Features**: User management, role assignment, status control

## 🔧 System Monitoring Endpoints

### 38. **Health Check**
- **Purpose**: Monitors system health and component status
- **Method**: GET `/api/health`
- **Authentication**: None required
- **Features**:
  - Database connectivity
  - Cache system status
  - Storage accessibility
  - Queue system health

### 39. **System Metrics**
- **Purpose**: Provides detailed system performance metrics
- **Method**: GET `/api/metrics`
- **Authentication**: None required
- **Features**:
  - System resource usage
  - Database performance
  - Order statistics
  - User activity metrics

## 🔒 Security Features

All endpoints include:
- **Rate Limiting**: Prevents abuse and ensures fair usage
- **Input Validation**: Comprehensive data sanitization
- **Authentication**: Secure token-based access control
- **Authorization**: Role-based permission checking
- **Audit Logging**: Complete transaction trail
- **Error Handling**: Secure error responses without data leakage

## 🚀 Performance Features

- **Database Indexes**: Optimized query performance
- **Race Condition Protection**: Atomic operations with locks
- **Caching**: Improved response times
- **Pagination**: Efficient data loading
- **Query Optimization**: Reduced database load

## 📱 Integration Features

- **Real Payment Gateways**: Stripe and Zain Cash integration
- **Multi-channel Notifications**: SMS, Email, WhatsApp, Telegram
- **Location Services**: GPS tracking and distance calculation
- **Real-time Updates**: Live order tracking and status updates

This comprehensive API collection provides a complete delivery system with enterprise-grade features, security, and performance optimizations suitable for production deployment.
