<?php

require_once __DIR__ . '/vendor/autoload.php';

$app = require_once __DIR__ . '/bootstrap/app.php';
$app->make(Illuminate\Contracts\Console\Kernel::class)->bootstrap();

use App\Models\Category;
use App\Models\User;
use App\Models\Product;

try {
    echo "Creating test data...\n";

    // Create test categories
    $category1 = Category::create([
        'name' => 'Fast Food',
        'name_ar' => 'وجبات سريعة',
        'image' => 'fastfood.jpg',
        'is_active' => true
    ]);

    $category2 = Category::create([
        'name' => 'Beverages',
        'name_ar' => 'مشروبات',
        'image' => 'beverages.jpg',
        'is_active' => true
    ]);

    echo "Categories created: {$category1->name}, {$category2->name}\n";

    // Create test merchant user (check if exists first)
    $merchant = User::where('email', 'merchant@test.com')->first();
    if (!$merchant) {
        $merchant = User::create([
            'phone' => '+1234567891',
            'email' => 'merchant@test.com',
            'full_name' => 'Test Merchant',
            'user_type' => 'merchant',
            'is_active' => true,
            'home_lat' => '40.7589',
            'home_lng' => '-73.9851',
            'home_address' => '456 Business Ave, New York, NY',
            'wallet_balance' => 1000.00
        ]);
        echo "Merchant created: {$merchant->full_name}\n";
    } else {
        echo "Merchant already exists: {$merchant->full_name}\n";
    }

    echo "Merchant created: {$merchant->full_name}\n";

    // Create test products
    $product1 = Product::create([
        'name' => 'Burger Deluxe',
        'name_ar' => 'برجر ديلوكس',
        'description' => 'Delicious beef burger with cheese',
        'description_ar' => 'برجر لحم لذيذ مع الجبن',
        'price' => 12.99,
        'category_id' => $category1->id,
        'merchant_id' => $merchant->id,
        'images' => json_encode(['burger1.jpg', 'burger2.jpg']),
        'is_available' => true,
        'preparation_time' => 15
    ]);

    $product2 = Product::create([
        'name' => 'Cola Drink',
        'name_ar' => 'مشروب كولا',
        'description' => 'Refreshing cola beverage',
        'description_ar' => 'مشروب كولا منعش',
        'price' => 2.99,
        'category_id' => $category2->id,
        'merchant_id' => $merchant->id,
        'images' => json_encode(['cola1.jpg']),
        'is_available' => true,
        'preparation_time' => 2
    ]);

    $product3 = Product::create([
        'name' => 'Pizza Margherita',
        'name_ar' => 'بيتزا مارغريتا',
        'description' => 'Classic pizza with tomato and mozzarella',
        'description_ar' => 'بيتزا كلاسيكية بالطماطم والموزاريلا',
        'price' => 18.99,
        'category_id' => $category1->id,
        'merchant_id' => $merchant->id,
        'images' => json_encode(['pizza1.jpg', 'pizza2.jpg']),
        'is_available' => true,
        'preparation_time' => 20
    ]);

    echo "Products created: {$product1->name}, {$product2->name}, {$product3->name}\n";
    echo "Test data creation completed successfully!\n";

} catch (Exception $e) {
    echo "Error creating test data: " . $e->getMessage() . "\n";
}
