<?php

return [
    /*
    |--------------------------------------------------------------------------
    | Delivery System Configuration
    |--------------------------------------------------------------------------
    |
    | Configuration settings for the delivery system including payment gateways,
    | delivery constraints, and business rules.
    |
    */

    // Order value constraints
    'min_order_value' => env('MIN_ORDER_VALUE', 5.00),
    'max_order_value' => env('MAX_ORDER_VALUE', 500.00),

    // Commission settings
    'commission_rate' => env('COMMISSION_RATE', 0.1), // 10% default

    // Delivery constraints
    'max_delivery_distance' => env('MAX_DELIVERY_DISTANCE', 20), // kilometers
    'delivery_speed_kmh' => env('DELIVERY_SPEED_KMH', 30), // average speed
    'delivery_buffer_minutes' => env('DELIVERY_BUFFER_MINUTES', 10), // buffer time

    // Payment gateway configurations
    'payment_gateways' => [
        'stripe' => [
            'enabled' => env('STRIPE_ENABLED', false),
            'public_key' => env('STRIPE_KEY'),
            'secret_key' => env('STRIPE_SECRET'),
            'webhook_secret' => env('STRIPE_WEBHOOK_SECRET'),
            'currency' => env('STRIPE_CURRENCY', 'usd'),
        ],
        'zain_cash' => [
            'enabled' => env('ZAIN_CASH_ENABLED', false),
            'merchant_id' => env('ZAIN_CASH_MERCHANT_ID'),
            'secret' => env('ZAIN_CASH_SECRET'),
            'api_url' => env('ZAIN_CASH_API_URL', 'https://api.zaincash.iq'),
            'currency' => env('ZAIN_CASH_CURRENCY', 'IQD'),
        ],
    ],

    // Rate limiting settings
    'rate_limits' => [
        'otp_send' => env('OTP_SEND_RATE_LIMIT', 5), // per hour
        'otp_verify' => env('OTP_VERIFY_RATE_LIMIT', 10), // per hour
        'order_creation' => env('ORDER_CREATION_RATE_LIMIT', 20), // per hour
    ],

    // Loyalty program settings
    'loyalty' => [
        'points_per_dollar' => env('LOYALTY_POINTS_PER_DOLLAR', 1),
        'point_value' => env('LOYALTY_POINT_VALUE', 0.1), // $0.1 per point
        'min_redemption' => env('LOYALTY_MIN_REDEMPTION', 10), // minimum points to redeem
    ],

    // Notification settings
    'notifications' => [
        'channels' => [
            'sms' => env('SMS_NOTIFICATIONS_ENABLED', true),
            'email' => env('EMAIL_NOTIFICATIONS_ENABLED', true),
            'push' => env('PUSH_NOTIFICATIONS_ENABLED', true),
            'whatsapp' => env('WHATSAPP_NOTIFICATIONS_ENABLED', false),
            'telegram' => env('TELEGRAM_NOTIFICATIONS_ENABLED', false),
        ],
        'queue' => env('NOTIFICATION_QUEUE', 'default'),
    ],

    // Order timeout settings
    'timeouts' => [
        'merchant_acceptance' => env('MERCHANT_ACCEPTANCE_TIMEOUT', 15), // minutes
        'preparation' => env('PREPARATION_TIMEOUT', 60), // minutes
        'delivery_assignment' => env('DELIVERY_ASSIGNMENT_TIMEOUT', 10), // minutes
        'delivery' => env('DELIVERY_TIMEOUT', 45), // minutes
    ],

    // Cache settings
    'cache' => [
        'products_ttl' => env('CACHE_PRODUCTS_TTL', 300), // 5 minutes
        'categories_ttl' => env('CACHE_CATEGORIES_TTL', 3600), // 1 hour
        'merchants_ttl' => env('CACHE_MERCHANTS_TTL', 1800), // 30 minutes
        'user_points_ttl' => env('CACHE_USER_POINTS_TTL', 60), // 1 minute
    ],

    // Performance settings
    'performance' => [
        'pagination_limit' => env('PAGINATION_LIMIT', 50),
        'max_order_items' => env('MAX_ORDER_ITEMS', 20),
        'query_timeout' => env('QUERY_TIMEOUT', 30), // seconds
    ],

    // Security settings
    'security' => [
        'max_login_attempts' => env('MAX_LOGIN_ATTEMPTS', 5),
        'lockout_duration' => env('LOCKOUT_DURATION', 900), // 15 minutes
        'password_reset_timeout' => env('PASSWORD_RESET_TIMEOUT', 3600), // 1 hour
        'otp_expiry' => env('OTP_EXPIRY', 300), // 5 minutes
    ],

    // Monitoring and logging
    'monitoring' => [
        'log_queries' => env('LOG_QUERIES', false),
        'log_payments' => env('LOG_PAYMENTS', true),
        'log_orders' => env('LOG_ORDERS', true),
        'metrics_enabled' => env('METRICS_ENABLED', true),
    ],

    // Business rules
    'business' => [
        'allow_cash_on_delivery' => env('ALLOW_CASH_ON_DELIVERY', true),
        'require_phone_verification' => env('REQUIRE_PHONE_VERIFICATION', true),
        'auto_assign_drivers' => env('AUTO_ASSIGN_DRIVERS', false),
        'allow_order_modification' => env('ALLOW_ORDER_MODIFICATION', false),
        'require_delivery_confirmation' => env('REQUIRE_DELIVERY_CONFIRMATION', true),
    ],
];
