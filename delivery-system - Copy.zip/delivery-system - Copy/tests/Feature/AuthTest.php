<?php

namespace Tests\Feature;

use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Foundation\Testing\WithFaker;
use Tests\TestCase;
use App\Models\User;
use App\Models\OtpCode;

class AuthTest extends TestCase
{
    use RefreshDatabase;

    public function test_send_otp_with_valid_phone()
    {
        $response = $this->postJson('/api/v1/auth/send-otp', [
            'phone' => '+1234567890',
            'type' => 'sms'
        ]);

        $response->assertStatus(200)
                ->assertJson([
                    'success' => true,
                    'message' => 'OTP sent successfully'
                ]);

        $this->assertDatabaseHas('otp_codes', [
            'phone' => '+1234567890',
            'type' => 'sms',
            'is_used' => false
        ]);
    }

    public function test_send_otp_with_invalid_phone()
    {
        $response = $this->postJson('/api/v1/auth/send-otp', [
            'phone' => '123',
            'type' => 'sms'
        ]);

        $response->assertStatus(422)
                ->assertJson([
                    'success' => false,
                    'message' => 'Validation error'
                ]);
    }

    public function test_verify_otp_with_valid_code()
    {
        $otpCode = OtpCode::create([
            'phone' => '+1234567890',
            'code' => '1234',
            'type' => 'sms',
            'expires_at' => now()->addMinutes(5)
        ]);

        $response = $this->postJson('/api/v1/auth/verify-otp', [
            'phone' => '+1234567890',
            'otp' => '1234'
        ]);

        $response->assertStatus(200)
                ->assertJson([
                    'success' => true,
                    'data' => [
                        'requires_registration' => true
                    ]
                ]);

        $this->assertDatabaseHas('otp_codes', [
            'phone' => '+1234567890',
            'code' => '1234',
            'is_used' => true
        ]);
    }

    public function test_verify_otp_with_invalid_code()
    {
        $response = $this->postJson('/api/v1/auth/verify-otp', [
            'phone' => '+1234567890',
            'otp' => '9999'
        ]);

        $response->assertStatus(400)
                ->assertJson([
                    'success' => false,
                    'message' => 'Invalid or expired OTP'
                ]);
    }

    public function test_register_new_user()
    {
        $response = $this->postJson('/api/v1/auth/register', [
            'phone' => '+1234567890',
            'full_name' => 'John Doe',
            'user_type' => 'regular',
            'email' => 'john@example.com',
            'home_lat' => 40.7128,
            'home_lng' => -74.0060,
            'home_address' => '123 Main St, New York, NY'
        ]);

        $response->assertStatus(201)
                ->assertJson([
                    'success' => true,
                    'message' => 'Registration successful. Account pending approval.'
                ])
                ->assertJsonStructure([
                    'data' => [
                        'user' => [
                            'id',
                            'phone',
                            'full_name',
                            'user_type'
                        ],
                        'token'
                    ]
                ]);

        $this->assertDatabaseHas('users', [
            'phone' => '+1234567890',
            'full_name' => 'John Doe',
            'user_type' => 'regular',
            'is_active' => false
        ]);
    }

    public function test_register_merchant_with_required_fields()
    {
        $response = $this->postJson('/api/v1/auth/register', [
            'phone' => '+1234567890',
            'full_name' => 'Restaurant Owner',
            'user_type' => 'merchant',
            'email' => 'restaurant@example.com',
            'home_lat' => 40.7128,
            'home_lng' => -74.0060,
            'home_address' => '123 Restaurant St, New York, NY',
            'id_card_image' => 'base64encodedimage',
            'business_type' => 'restaurant',
            'bank_card' => '1234567890123456',
            'working_hours' => [
                'monday' => ['09:00', '22:00'],
                'tuesday' => ['09:00', '22:00']
            ]
        ]);

        $response->assertStatus(201)
                ->assertJson([
                    'success' => true
                ]);

        $this->assertDatabaseHas('users', [
            'phone' => '+1234567890',
            'user_type' => 'merchant',
            'business_type' => 'restaurant'
        ]);
    }

    public function test_register_driver_with_required_fields()
    {
        $response = $this->postJson('/api/v1/auth/register', [
            'phone' => '+1234567890',
            'full_name' => 'Driver Name',
            'user_type' => 'driver',
            'home_lat' => 40.7128,
            'home_lng' => -74.0060,
            'home_address' => '123 Driver St, New York, NY',
            'id_card_image' => 'base64encodedimage',
            'vin_number' => 'ABC123456789',
            'is_freelance' => true
        ]);

        $response->assertStatus(201)
                ->assertJson([
                    'success' => true
                ]);

        $this->assertDatabaseHas('users', [
            'phone' => '+1234567890',
            'user_type' => 'driver',
            'vin_number' => 'ABC123456789',
            'is_freelance' => true
        ]);
    }

    public function test_login_existing_user_with_otp()
    {
        $user = User::factory()->create([
            'phone' => '+1234567890',
            'is_active' => true
        ]);

        $otpCode = OtpCode::create([
            'phone' => '+1234567890',
            'code' => '1234',
            'type' => 'sms',
            'expires_at' => now()->addMinutes(5)
        ]);

        $response = $this->postJson('/api/v1/auth/verify-otp', [
            'phone' => '+1234567890',
            'otp' => '1234'
        ]);

        $response->assertStatus(200)
                ->assertJson([
                    'success' => true,
                    'message' => 'Login successful',
                    'data' => [
                        'requires_registration' => false
                    ]
                ])
                ->assertJsonStructure([
                    'data' => [
                        'user',
                        'token'
                    ]
                ]);
    }

    public function test_logout_authenticated_user()
    {
        $user = User::factory()->create();
        $token = $user->createToken('test-token')->plainTextToken;

        $response = $this->withHeaders([
            'Authorization' => 'Bearer ' . $token,
        ])->postJson('/api/v1/auth/logout');

        $response->assertStatus(200)
                ->assertJson([
                    'success' => true,
                    'message' => 'Logged out successfully'
                ]);
    }

    public function test_get_authenticated_user_profile()
    {
        $user = User::factory()->create();
        $token = $user->createToken('test-token')->plainTextToken;

        $response = $this->withHeaders([
            'Authorization' => 'Bearer ' . $token,
        ])->getJson('/api/v1/auth/me');

        $response->assertStatus(200)
                ->assertJson([
                    'success' => true
                ])
                ->assertJsonStructure([
                    'data' => [
                        'user' => [
                            'id',
                            'phone',
                            'full_name',
                            'user_type'
                        ]
                    ]
                ]);
    }

    public function test_refresh_token()
    {
        $user = User::factory()->create();
        $token = $user->createToken('test-token')->plainTextToken;

        $response = $this->withHeaders([
            'Authorization' => 'Bearer ' . $token,
        ])->postJson('/api/v1/auth/refresh-token');

        $response->assertStatus(200)
                ->assertJson([
                    'success' => true,
                    'message' => 'Token refreshed successfully'
                ])
                ->assertJsonStructure([
                    'data' => [
                        'token'
                    ]
                ]);
    }

    public function test_unauthorized_access_to_protected_route()
    {
        $response = $this->getJson('/api/v1/auth/me');

        $response->assertStatus(401);
    }
}

