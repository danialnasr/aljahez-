<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class LoyaltyTransaction extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id',
        'merchant_id',
        'points',
        'discount_amount',
        'type',
        'description'
    ];

    protected $casts = [
        'discount_amount' => 'decimal:2'
    ];

    // Relationships
    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function merchant()
    {
        return $this->belongsTo(User::class, 'merchant_id');
    }

    // Scopes
    public function scopeByType($query, $type)
    {
        return $query->where('type', $type);
    }

    public function scopeByUser($query, $userId)
    {
        return $query->where('user_id', $userId);
    }

    public function scopeEarned($query)
    {
        return $query->where('type', 'earned');
    }

    public function scopeRedeemed($query)
    {
        return $query->where('type', 'redeemed');
    }

    public function scopeByMerchant($query, $merchantId)
    {
        return $query->where('merchant_id', $merchantId);
    }

    // Methods
    public static function createEarned($userId, $points, $description = null)
    {
        return static::create([
            'user_id' => $userId,
            'points' => $points,
            'type' => 'earned',
            'description' => $description ?? 'Points earned from purchase'
        ]);
    }

    public static function createRedeemed($userId, $merchantId, $points, $discountAmount = 0, $description = null)
    {
        return static::create([
            'user_id' => $userId,
            'merchant_id' => $merchantId,
            'points' => $points,
            'discount_amount' => $discountAmount,
            'type' => 'redeemed',
            'description' => $description ?? 'Points redeemed for discount'
        ]);
    }

    public function isEarned()
    {
        return $this->type === 'earned';
    }

    public function isRedeemed()
    {
        return $this->type === 'redeemed';
    }

    public function getFormattedPointsAttribute()
    {
        $prefix = $this->isEarned() ? '+' : '-';
        return $prefix . $this->points;
    }
}

