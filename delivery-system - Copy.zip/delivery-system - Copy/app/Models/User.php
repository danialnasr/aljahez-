<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

class User extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
  protected $fillable = [
    'phone', 'email', 'full_name', 'user_type', 'profile_image',
    'home_lat', 'home_lng', 'home_address', 'id_card_image',
    'vin_number', 'business_type', 'is_active', 'is_online',
    'working_hours', 'bank_card', 'wallet_balance', 'loyalty_points',
    'is_freelance', 'fcm_token', 'internal_otp',
    'address', 'date_of_birth', 'gender', 'latitude', 'longitude', 'password'
     ];


    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array<int, string>
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'working_hours' => 'array',
        'home_lat' => 'decimal:8',
        'home_lng' => 'decimal:8',
        'wallet_balance' => 'decimal:2',
        'rating_average' => 'decimal:2',
        'is_active' => 'boolean',
        'is_online' => 'boolean',
        'is_freelance' => 'boolean',
        'email_verified_at' => 'datetime',
        'password' => 'hashed',
    ];

    // Relationships
    public function products()
    {
        return $this->hasMany(Product::class, 'merchant_id');
    }

    public function orders()
    {
        return $this->hasMany(Order::class, 'customer_id');
    }

    public function deliveries()
    {
        return $this->hasMany(Order::class, 'driver_id');
    }

    public function walletTransactions()
    {
        return $this->hasMany(WalletTransaction::class);
    }

    public function loyaltyTransactions()
    {
        return $this->hasMany(LoyaltyTransaction::class);
    }

    public function ratingsGiven()
    {
        return $this->hasMany(Rating::class, 'rater_id');
    }

    public function ratingsReceived()
    {
        return $this->hasMany(Rating::class, 'rated_id');
    }

    public function complaintsSubmitted()
    {
        return $this->hasMany(Complaint::class, 'complainant_id');
    }

    public function complaintsReceived()
    {
        return $this->hasMany(Complaint::class, 'complained_about_id');
    }

    // Helper methods
    public function isDriver()
    {
        return $this->user_type === 'driver';
    }

    public function isMerchant()
    {
        return $this->user_type === 'merchant';
    }

    public function isRegular()
    {
        return $this->user_type === 'regular';
    }

    public function isAdmin()
    {
        return $this->user_type === 'admin';
    }

    public function isTemp()
    {
        return $this->user_type === 'temp';
    }

    public function updateRating()
    {
        $ratings = $this->ratingsReceived;
        $this->rating_count = $ratings->count();
        $this->rating_average = $ratings->avg('rating') ?? 0;
        $this->save();
    }

    public function addLoyaltyPoints($points, $description = null)
    {
        $this->increment('loyalty_points', $points);

        LoyaltyTransaction::create([
            'user_id' => $this->id,
            'points' => $points,
            'type' => 'earned',
            'description' => $description ?? 'Points earned'
        ]);
    }

    public function deductLoyaltyPoints($points, $merchantId = null, $discountAmount = 0)
    {
        if ($this->loyalty_points >= $points) {
            $this->decrement('loyalty_points', $points);

            LoyaltyTransaction::create([
                'user_id' => $this->id,
                'merchant_id' => $merchantId,
                'points' => $points,
                'discount_amount' => $discountAmount,
                'type' => 'redeemed',
                'description' => 'Points redeemed'
            ]);

            return true;
        }

        return false;
    }
}
