<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Rating extends Model
{
    use HasFactory;

    protected $fillable = [
        'order_id',
        'rater_id',
        'rated_id',
        'rating',
        'comment'
    ];

    // Relationships
    public function order()
    {
        return $this->belongsTo(Order::class);
    }

    public function rater()
    {
        return $this->belongsTo(User::class, 'rater_id');
    }

    public function rated()
    {
        return $this->belongsTo(User::class, 'rated_id');
    }

    // Scopes
    public function scopeForUser($query, $userId)
    {
        return $query->where('rated_id', $userId);
    }

    public function scopeByRating($query, $rating)
    {
        return $query->where('rating', $rating);
    }

    public function scopeWithComment($query)
    {
        return $query->whereNotNull('comment');
    }

    // Methods
    public static function createRating($orderId, $raterId, $ratedId, $rating, $comment = null)
    {
        $ratingRecord = static::create([
            'order_id' => $orderId,
            'rater_id' => $raterId,
            'rated_id' => $ratedId,
            'rating' => $rating,
            'comment' => $comment
        ]);

        // Update user's average rating
        $user = User::find($ratedId);
        $user->updateRating();

        return $ratingRecord;
    }

    public function getStarsAttribute()
    {
        return str_repeat('★', $this->rating) . str_repeat('☆', 5 - $this->rating);
    }
}

