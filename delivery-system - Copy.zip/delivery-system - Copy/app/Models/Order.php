<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Order extends Model
{
    use HasFactory;

    protected $fillable = [
        'order_number',
        'customer_id',
        'driver_id',
        'status',
        'subtotal',
        'delivery_fee',
        'commission',
        'tip',
        'total',
        'payment_method',
        'payment_status',
        'delivery_lat',
        'delivery_lng',
        'delivery_address',
        'customer_otp',
        'notes',
        'estimated_delivery_time',
        'delivered_at'
    ];

    protected $casts = [
        'subtotal' => 'decimal:2',
        'delivery_fee' => 'decimal:2',
        'commission' => 'decimal:2',
        'tip' => 'decimal:2',
        'total' => 'decimal:2',
        'delivery_lat' => 'decimal:8',
        'delivery_lng' => 'decimal:8',
        'estimated_delivery_time' => 'datetime',
        'delivered_at' => 'datetime'
    ];

    // Relationships
    public function customer()
    {
        return $this->belongsTo(User::class, 'customer_id');
    }

    public function driver()
    {
        return $this->belongsTo(User::class, 'driver_id');
    }

    public function items()
    {
        return $this->hasMany(OrderItem::class);
    }

    public function ratings()
    {
        return $this->hasMany(Rating::class);
    }

    // Scopes
    public function scopeByStatus($query, $status)
    {
        return $query->where('status', $status);
    }

    public function scopeByCustomer($query, $customerId)
    {
        return $query->where('customer_id', $customerId);
    }

    public function scopeByDriver($query, $driverId)
    {
        return $query->where('driver_id', $driverId);
    }

    public function scopePending($query)
    {
        return $query->where('status', 'pending');
    }

    public function scopeActive($query)
    {
        return $query->whereIn('status', ['pending', 'accepted', 'preparing', 'ready', 'picked_up']);
    }

    public function scopeCompleted($query)
    {
        return $query->where('status', 'delivered');
    }

    // Methods
    public function generateOrderNumber()
    {
        $this->order_number = 'ORD-' . date('Ymd') . '-' . str_pad($this->id, 6, '0', STR_PAD_LEFT);
        $this->save();
        return $this->order_number;
    }

    public function generateOTP()
    {
        $this->customer_otp = str_pad(random_int(0, 9999), 4, '0', STR_PAD_LEFT);
        $this->save();
        return $this->customer_otp;
    }

    public function calculateTotals()
    {
        $this->subtotal = $this->items->sum('total');
        $this->total = $this->subtotal + $this->delivery_fee + $this->tip;
        $this->commission = $this->subtotal * 0.1; // 10% commission
        $this->save();
    }

    public function canBeCancelled()
    {
        return in_array($this->status, ['pending', 'accepted']) && 
               $this->created_at->diffInMinutes(now()) <= 2;
    }

    public function isDelivered()
    {
        return $this->status === 'delivered';
    }

    public function isPending()
    {
        return $this->status === 'pending';
    }

    public function isActive()
    {
        return in_array($this->status, ['pending', 'accepted', 'preparing', 'ready', 'picked_up']);
    }

    public function getMerchants()
    {
        return $this->items->pluck('merchant_id')->unique();
    }

    public function getEstimatedPreparationTime()
    {
        return $this->items->max('preparation_time');
    }
}

