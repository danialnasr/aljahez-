<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    use HasFactory;

    protected $fillable = [
        'merchant_id',
        'category_id',
        'name',
        'name_ar',
        'description',
        'description_ar',
        'price',
        'currency',
        'images',
        'is_available',
        'stock_quantity',
        'min_stock_level',
        'loyalty_points',
        'preparation_time'
    ];

    protected $casts = [
        'images' => 'array',
        'price' => 'decimal:2',
        'is_available' => 'boolean',
        'stock_quantity' => 'integer',
        'min_stock_level' => 'integer'
    ];

    // Relationships
    public function merchant()
    {
        return $this->belongsTo(User::class, 'merchant_id');
    }

    public function category()
    {
        return $this->belongsTo(Category::class);
    }

    public function orderItems()
    {
        return $this->hasMany(OrderItem::class);
    }

    // Scopes
    public function scopeAvailable($query)
    {
        return $query->where('is_available', true);
    }

    public function scopeByMerchant($query, $merchantId)
    {
        return $query->where('merchant_id', $merchantId);
    }

    public function scopeByCategory($query, $categoryId)
    {
        return $query->where('category_id', $categoryId);
    }

    public function scopeSearch($query, $search)
    {
        return $query->where(function($q) use ($search) {
            $q->where('name', 'like', "%{$search}%")
              ->orWhere('name_ar', 'like', "%{$search}%")
              ->orWhere('description', 'like', "%{$search}%")
              ->orWhere('description_ar', 'like', "%{$search}%");
        });
    }

    // Accessors
    public function getLocalizedNameAttribute()
    {
        return app()->getLocale() === 'ar' ? $this->name_ar : $this->name;
    }

    public function getLocalizedDescriptionAttribute()
    {
        return app()->getLocale() === 'ar' ? $this->description_ar : $this->description;
    }

    public function getFirstImageAttribute()
    {
        return $this->images[0] ?? null;
    }

    public function getFormattedPriceAttribute()
    {
        return number_format($this->price, 2) . ' ' . $this->currency;
    }

    // Stock Management Methods
    public function hasStock($quantity = 1)
    {
        return $this->stock_quantity >= $quantity;
    }

    public function reserveStock($quantity)
    {
        return \Illuminate\Support\Facades\DB::transaction(function() use ($quantity) {
            // Lock the product row for update to prevent race conditions
            $product = self::where('id', $this->id)->lockForUpdate()->first();
            
            if (!$product || $product->stock_quantity < $quantity) {
                throw new \Exception("Insufficient stock for product: {$this->name}. Available: {$product->stock_quantity}, Requested: {$quantity}");
            }
            
            $product->decrement('stock_quantity', $quantity);
            
            // Log stock reservation for audit trail
            \Illuminate\Support\Facades\Log::info("Stock reserved for product {$this->id}: {$quantity} units. Remaining: " . ($product->stock_quantity - $quantity));
            
            return true;
        });
    }

    public function releaseStock($quantity)
    {
        return \Illuminate\Support\Facades\DB::transaction(function() use ($quantity) {
            // Lock the product row for update to prevent race conditions
            $product = self::where('id', $this->id)->lockForUpdate()->first();
            
            if (!$product) {
                throw new \Exception("Product not found: {$this->id}");
            }
            
            if ($quantity <= 0) {
                throw new \Exception("Invalid quantity for stock release: {$quantity}");
            }
            
            $product->increment('stock_quantity', $quantity);
            
            // Log stock release for audit trail
            \Illuminate\Support\Facades\Log::info("Stock released for product {$this->id}: {$quantity} units. New total: " . ($product->stock_quantity + $quantity));
            
            return true;
        });
    }

    public function isLowStock()
    {
        return $this->stock_quantity <= $this->min_stock_level;
    }

    public function scopeInStock($query)
    {
        return $query->where('stock_quantity', '>', 0);
    }

    public function scopeLowStock($query)
    {
        return $query->whereRaw('stock_quantity <= min_stock_level');
    }
}

