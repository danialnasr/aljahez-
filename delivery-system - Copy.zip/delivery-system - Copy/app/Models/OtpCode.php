<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class OtpCode extends Model
{
    use HasFactory;

    protected $fillable = [
        'phone',
        'code',
        'type',
        'is_used',
        'expires_at'
    ];

    protected $casts = [
        'is_used' => 'boolean',
        'expires_at' => 'datetime'
    ];

    public function isExpired()
    {
        return $this->expires_at->isPast();
    }

    public function isValid()
    {
        return !$this->is_used && !$this->isExpired();
    }

    public function markAsUsed()
    {
        $this->update(['is_used' => true]);
    }

    public static function generateCode()
    {
        return str_pad(random_int(0, 9999), 4, '0', STR_PAD_LEFT);
    }

    public static function createForPhone($phone, $type = 'sms')
    {
        // Delete old unused codes for this phone
        static::where('phone', $phone)
            ->where('is_used', false)
            ->delete();

        return static::create([
            'phone' => $phone,
            'code' => static::generateCode(),
            'type' => $type,
            'expires_at' => now()->addMinutes(5)
        ]);
    }
}

