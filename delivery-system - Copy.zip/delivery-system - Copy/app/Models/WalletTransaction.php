<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class WalletTransaction extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id',
        'type',
        'amount',
        'description',
        'transaction_id'
    ];

    protected $casts = [
        'amount' => 'decimal:2'
    ];

    // Relationships
    public function user()
    {
        return $this->belongsTo(User::class);
    }

    // Scopes
    public function scopeByType($query, $type)
    {
        return $query->where('type', $type);
    }

    public function scopeByUser($query, $userId)
    {
        return $query->where('user_id', $userId);
    }

    public function scopeTopups($query)
    {
        return $query->where('type', 'topup');
    }

    public function scopePayments($query)
    {
        return $query->where('type', 'payment');
    }

    public function scopeEarnings($query)
    {
        return $query->where('type', 'earning');
    }

    public function scopeCommissions($query)
    {
        return $query->where('type', 'commission');
    }

    // Methods
    public static function createTopup($userId, $amount, $transactionId = null)
    {
        return static::create([
            'user_id' => $userId,
            'type' => 'topup',
            'amount' => $amount,
            'description' => 'Wallet top-up',
            'transaction_id' => $transactionId
        ]);
    }

    public static function createPayment($userId, $amount, $description = 'Payment')
    {
        return static::create([
            'user_id' => $userId,
            'type' => 'payment',
            'amount' => -$amount, // Negative for deduction
            'description' => $description
        ]);
    }

    public static function createEarning($userId, $amount, $description = 'Earning')
    {
        return static::create([
            'user_id' => $userId,
            'type' => 'earning',
            'amount' => $amount,
            'description' => $description
        ]);
    }

    public static function createCommission($userId, $amount, $description = 'Commission deduction')
    {
        return static::create([
            'user_id' => $userId,
            'type' => 'commission',
            'amount' => -$amount, // Negative for deduction
            'description' => $description
        ]);
    }

    public function isCredit()
    {
        return $this->amount > 0;
    }

    public function isDebit()
    {
        return $this->amount < 0;
    }

    public function getFormattedAmountAttribute()
    {
        $prefix = $this->isCredit() ? '+' : '';
        return $prefix . number_format($this->amount, 2);
    }
}

