<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Complaint extends Model
{
    use HasFactory;

    protected $fillable = [
        'complainant_id',
        'complained_about_id',
        'title',
        'description',
        'status',
        'admin_notes'
    ];

    // Relationships
    public function complainant()
    {
        return $this->belongsTo(User::class, 'complainant_id');
    }

    public function complainedAbout()
    {
        return $this->belongsTo(User::class, 'complained_about_id');
    }

    // Scopes
    public function scopeByStatus($query, $status)
    {
        return $query->where('status', $status);
    }

    public function scopePending($query)
    {
        return $query->where('status', 'pending');
    }

    public function scopeInProgress($query)
    {
        return $query->where('status', 'in_progress');
    }

    public function scopeResolved($query)
    {
        return $query->where('status', 'resolved');
    }

    public function scopeByComplainant($query, $userId)
    {
        return $query->where('complainant_id', $userId);
    }

    public function scopeAgainst($query, $userId)
    {
        return $query->where('complained_about_id', $userId);
    }

    // Methods
    public function markAsInProgress($adminNotes = null)
    {
        $this->status = 'in_progress';
        if ($adminNotes) {
            $this->admin_notes = $adminNotes;
        }
        $this->save();
    }

    public function resolve($adminNotes = null)
    {
        $this->status = 'resolved';
        if ($adminNotes) {
            $this->admin_notes = $adminNotes;
        }
        $this->save();
    }

    public function close($adminNotes = null)
    {
        $this->status = 'closed';
        if ($adminNotes) {
            $this->admin_notes = $adminNotes;
        }
        $this->save();
    }

    public function isPending()
    {
        return $this->status === 'pending';
    }

    public function isResolved()
    {
        return $this->status === 'resolved';
    }
}

