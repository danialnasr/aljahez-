<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class DriverMiddleware
{
    /**
     * Handle an incoming request.
     *
     * @param  \Closure(\Illuminate\Http\Request): (\Symfony\Component\HttpFoundation\Response)  $next
     */
    public function handle(Request $request, Closure $next): Response
    {
        if (!auth()->check()) {
            return response()->json([
                'success' => false,
                'message' => 'Unauthorized - Authentication required'
            ], 401);
        }

        $user = auth()->user();
        
        if (!$user->isDriver()) {
            return response()->json([
                'success' => false,
                'message' => 'Forbidden - Driver access required'
            ], 403);
        }

        if (!$user->is_active) {
            return response()->json([
                'success' => false,
                'message' => 'Driver account not activated'
            ], 403);
        }

        // Check if driver has required information
        if (!$user->vin_number || !$user->id_card_image) {
            return response()->json([
                'success' => false,
                'message' => 'Please complete your driver profile'
            ], 400);
        }

        return $next($request);
    }
}

