<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Order;
use App\Models\OrderItem;
use App\Models\Product;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use App\Events\OrderStatusUpdated;

class OrderController extends Controller
{
    public function index(Request $request)
    {
        try {
            $user = $request->user();
            $query = Order::with(['customer', 'driver', 'items.product', 'items.merchant']);

            // Filter based on user type
            if ($user->isRegular() || $user->isTemp()) {
                $query->where('customer_id', $user->id);
            } elseif ($user->isDriver()) {
                $query->where('driver_id', $user->id);
            } elseif ($user->isMerchant()) {
                $query->whereHas('items', function($q) use ($user) {
                    $q->where('merchant_id', $user->id);
                });
            }

            // Apply filters
            if ($request->has('status')) {
                $query->where('status', $request->input('status'));
            }

            if ($request->has('date_from')) {
                $query->whereDate('created_at', '>=', $request->input('date_from'));
            }

            if ($request->has('date_to')) {
                $query->whereDate('created_at', '<=', $request->input('date_to'));
            }

            $orders = $query->orderBy('created_at', 'desc')->paginate(20);

            return response()->json([
                'success' => true,
                'data' => $orders
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to fetch orders',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'items' => 'required|array|min:1',
            'items.*.product_id' => 'required|exists:products,id',
            'items.*.quantity' => 'required|integer|min:1',
            'delivery_lat' => 'required|numeric|between:-90,90',
            'delivery_lng' => 'required|numeric|between:-180,180',
            'delivery_address' => 'required|string',
            'payment_method' => 'required|in:cash,card,zain_cash,wallet',
            'notes' => 'nullable|string',
            'tip' => 'nullable|numeric|min:0'
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Validation error',
                'errors' => $validator->errors()
            ], 422);
        }

        DB::beginTransaction();

        try {
            $user = $request->user();

            // Check if user is active
            if (!$user->is_active) {
                return response()->json([
                    'success' => false,
                    'message' => 'Account not activated'
                ], 403);
            }

            $order = Order::create([
                'customer_id' => $user->id,
                'status' => 'pending',
                'delivery_lat' => $request->delivery_lat,
                'delivery_lng' => $request->delivery_lng,
                'delivery_address' => $request->delivery_address,
                'payment_method' => $request->payment_method,
                'notes' => $request->notes,
                'tip' => $request->tip ?? 0
            ]);

            $order->generateOrderNumber();
            $order->generateOTP();

            $subtotal = 0;
            $totalPreparationTime = 0;
            $reservedProducts = []; // Track reserved products for rollback

            // First pass: Check stock availability for all items
            foreach ($request->items as $item) {
                $product = Product::find($item['product_id']);

                if (!$product->is_available) {
                    throw new \Exception("Product {$product->name} is not available");
                }

                if (!$product->hasStock($item['quantity'])) {
                    throw new \Exception("Insufficient stock for product: {$product->name}. Available: {$product->stock_quantity}, Requested: {$item['quantity']}");
                }
            }

            // Second pass: Reserve stock and create order items
            foreach ($request->items as $item) {
                $product = Product::find($item['product_id']);

                // Reserve stock
                $product->reserveStock($item['quantity']);
                $reservedProducts[] = ['product' => $product, 'quantity' => $item['quantity']];

                $itemTotal = $product->price * $item['quantity'];
                $subtotal += $itemTotal;

                OrderItem::create([
                    'order_id' => $order->id,
                    'product_id' => $product->id,
                    'merchant_id' => $product->merchant_id,
                    'quantity' => $item['quantity'],
                    'price' => $product->price,
                    'total' => $itemTotal,
                    'preparation_time' => $product->preparation_time
                ]);

                $totalPreparationTime = max($totalPreparationTime, $product->preparation_time);
            }

            $deliveryFee = $this->calculateDeliveryFee($order);
            $commissionRate = $this->getCommissionRate();
            $commission = $subtotal * $commissionRate;
            $total = $subtotal + $deliveryFee + $order->tip;

            // Validate order value
            $this->validateOrderValue($total);

            // Validate delivery distance and calculate delivery time
            $deliveryValidation = $this->validateDeliveryDistance($request->delivery_lat, $request->delivery_lng, $merchantLocation);
            if (!$deliveryValidation['valid']) {
                throw new \Exception($deliveryValidation['message']);
            }

            $estimatedDeliveryTime = $this->calculateDeliveryTime($deliveryValidation['distance'], $totalPreparationTime);

            $order->update([
                'subtotal' => $subtotal,
                'delivery_fee' => $deliveryFee,
                'commission' => $commission,
                'total' => $total,
                'estimated_delivery_time' => now()->addMinutes($totalPreparationTime + 30)
            ]);

            // Only validate wallet balance, don't charge yet
            if ($request->payment_method === 'wallet') {
                if ($user->wallet_balance < $total) {
                    throw new \Exception('Insufficient wallet balance');
                }
            }

            // Set initial payment status as pending
            $order->update(['payment_status' => 'pending']);

            // Notify merchants
            $this->notifyMerchants($order);

            // Add loyalty points
            $loyaltyPoints = floor($subtotal / 10); // 1 point per $10
            if ($loyaltyPoints > 0) {
                $user->addLoyaltyPoints($loyaltyPoints, "Order #{$order->order_number}");
            }

            DB::commit();

            return response()->json([
                'success' => true,
                'message' => 'Order placed successfully',
                'data' => [
                    'order' => $order->load('items.product', 'items.merchant')
                ]
            ], 201);

        } catch (\Exception $e) {
            DB::rollBack();

            // Release reserved stock on failure
            if (isset($reservedProducts)) {
                foreach ($reservedProducts as $reserved) {
                    $reserved['product']->releaseStock($reserved['quantity']);
                }
            }

            return response()->json([
                'success' => false,
                'message' => 'Order failed',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    public function show(Request $request, $id)
    {
        try {
            $user = $request->user();
            $query = Order::with(['customer', 'driver', 'items.product', 'items.merchant', 'ratings']);

            // Check permissions
            if ($user->isRegular() || $user->isTemp()) {
                $query->where('customer_id', $user->id);
            } elseif ($user->isDriver()) {
                $query->where('driver_id', $user->id);
            } elseif ($user->isMerchant()) {
                $query->whereHas('items', function($q) use ($user) {
                    $q->where('merchant_id', $user->id);
                });
            }

            $order = $query->findOrFail($id);

            // جلب خطة الطريق والوقت المتوقع
            $routeData = null;
            if ($order->driver_id && $order->driver && $order->delivery_lat && $order->delivery_lng) {
                // نقطة الانطلاق: موقع السائق الحالي (أو موقع التاجر إذا أردت)
                $fromLat = $order->driver->home_lat ?? null;
                $fromLng = $order->driver->home_lng ?? null;
                if ($fromLat && $fromLng) {
                    $paymentService = app(\App\Services\PaymentService::class);
                    try {
                        $routeData = $paymentService->getRouteAndETA($fromLat, $fromLng, $order->delivery_lat, $order->delivery_lng);
                    } catch (\Exception $e) {
                        $routeData = null;
                    }
                }
            }

            return response()->json([
                'success' => true,
                'data' => [
                    'order' => $order,
                    'route' => $routeData
                ]
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Order not found',
                'error' => $e->getMessage()
            ], 404);
        }
    }

    public function updateStatus(Request $request, $id)
    {
        $validator = Validator::make($request->all(), [
            'status' => 'required|in:pending,accepted,preparing,ready_for_delivery,out_for_delivery,delivered,cancelled'
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Validation error',
                'errors' => $validator->errors()
            ], 422);
        }

        try {
            $user = $request->user();
            $order = Order::findOrFail($id);

            // Check permissions
            if (!$this->canUpdateOrderStatus($user, $order, $request->status)) {
                return response()->json([
                    'success' => false,
                    'message' => 'Unauthorized to update this order status'
                ], 403);
            }

            // Validate state transition
            if (!$this->isValidStatusTransition($order->status, $request->status)) {
                return response()->json([
                    'success' => false,
                    'message' => "Invalid status transition from {$order->status} to {$request->status}"
                ], 400);
            }

            $order->update(['status' => $request->status]);

            // بث الحدث عند تحديث الحالة
            event(new OrderStatusUpdated($order, $request->status));

            if ($request->status === 'delivered') {
                DB::beginTransaction();
                try {
                    $order->update(['delivered_at' => now()]);
                    $this->processPayment($order);
                    DB::commit();
                } catch (\Exception $e) {
                    DB::rollBack();
                    // Revert order status if payment fails.
                    $order->update(['status' => 'ready_for_delivery', 'delivered_at' => null]);
                    throw new \Exception('Payment processing failed: ' . $e->getMessage());
                }
            }

            return response()->json([
                'success' => true,
                'message' => 'Order status updated successfully',
                'data' => [
                    'order' => $order->fresh()
                ]
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to update order status',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    public function acceptDelivery(Request $request, $id)
    {
        try {
            $driver = $request->user();

            if (!$driver->isDriver()) {
                return response()->json([
                    'success' => false,
                    'message' => 'Only drivers can accept deliveries'
                ], 403);
            }

            if (!$driver->is_online) {
                return response()->json([
                    'success' => false,
                    'message' => 'Driver must be online to accept deliveries'
                ], 400);
            }

            $order = Order::findOrFail($id);

            if ($order->driver_id) {
                return response()->json([
                    'success' => false,
                    'message' => 'Order already assigned to another driver'
                ], 400);
            }

            if ($order->status !== 'pending') {
                return response()->json([
                    'success' => false,
                    'message' => 'Order is not available for pickup'
                ], 400);
            }

            $order->update([
                'driver_id' => $driver->id,
                'status' => 'accepted'
            ]);

            return response()->json([
                'success' => true,
                'message' => 'Delivery accepted successfully',
                'data' => [
                    'order' => $order->fresh(['customer', 'items.product'])
                ]
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to accept delivery',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    public function verifyDelivery(Request $request, $id)
    {
        $validator = Validator::make($request->all(), [
            'otp' => 'required|string|size:4'
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Validation error',
                'errors' => $validator->errors()
            ], 422);
        }

        try {
            $order = Order::findOrFail($id);

            if ($order->customer_otp !== $request->otp) {
                return response()->json([
                    'success' => false,
                    'message' => 'Invalid OTP'
                ], 400);
            }

            $order->update([
                'status' => 'delivered',
                'delivered_at' => now()
            ]);

            $this->processPayment($order);

            return response()->json([
                'success' => true,
                'message' => 'Delivery verified successfully',
                'data' => [
                    'order' => $order->fresh()
                ]
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to verify delivery',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    public function cancel(Request $request, $id)
    {
        try {
            $user = $request->user();
            $order = Order::findOrFail($id);

            // Check if user can cancel this order
            if ($order->customer_id !== $user->id && !$user->isAdmin()) {
                return response()->json([
                    'success' => false,
                    'message' => 'Unauthorized'
                ], 403);
            }

            if (!$order->canBeCancelled()) {
                return response()->json([
                    'success' => false,
                    'message' => 'Order cannot be cancelled'
                ], 400);
            }

            $order->update(['status' => 'cancelled']);

            // Release reserved stock back to inventory
            foreach ($order->items as $item) {
                $item->product->releaseStock($item->quantity);
            }

            // Refund if payment was made
            if ($order->payment_method === 'wallet' && $order->payment_status === 'completed') {
                $order->customer->increment('wallet_balance', $order->total);
            }

            return response()->json([
                'success' => true,
                'message' => 'Order cancelled successfully',
                'data' => [
                    'order' => $order->fresh()
                ]
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to cancel order',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    private function calculateDeliveryFee($order)
    {
        // Simple distance-based calculation
        // In a real app, you'd use Google Maps API or similar
        $baseDistance = 5; // km
        $baseFee = 2; // USD
        $perKmFee = 0.5; // USD per km

        // For now, return base fee
        // TODO: Implement actual distance calculation
        return $baseFee;
    }

    private function notifyMerchants($order)
    {
        $merchantIds = $order->items->pluck('merchant_id')->unique();
        $notificationService = app(\App\Services\NotificationService::class);
        foreach ($merchantIds as $merchantId) {
            $merchant = User::find($merchantId);
            // إرسال إشعار Push
            $notificationService->sendPushNotification($merchant, [
                'title' => 'طلب جديد',
                'body' => "لديك طلب جديد رقم #{$order->order_number} يحتوي على " . $order->items->where('merchant_id', $merchantId)->count() . " منتج/منتجات.",
                'data' => [
                    'type' => 'new_order',
                    'order_id' => $order->id,
                    'order_number' => $order->order_number
                ]
            ]);
            // إرسال SMS (اختياري)
            $notificationService->sendSMS($merchant->phone, "لديك طلب جديد رقم #{$order->order_number}. الرجاء مراجعة التطبيق.");
        }
    }

    private function processPayment($order)
    {
        // Validate order state before processing payment
        if ($order->payment_status === 'completed') {
            throw new \Exception('Payment already processed for this order');
        }

        if ($order->status !== 'delivered') {
            throw new \Exception('Order must be delivered before processing payment');
        }

        try {
            switch ($order->payment_method) {
                case 'wallet':
                    $this->processWalletPayment($order);
                    break;
                case 'cash':
                    $order->update(['payment_status' => 'completed']);
                    break;
                case 'card':
                case 'zain_cash':
                    $this->processGatewayPayment($order);
                    break;
                default:
                    throw new \Exception('Invalid payment method: ' . $order->payment_method);
            }

            $this->distributePayments($order);

            \Illuminate\Support\Facades\Log::info("Payment processed successfully for order {$order->id}");

        } catch (\Exception $e) {
            \Illuminate\Support\Facades\Log::error("Payment processing failed for order {$order->id}: " . $e->getMessage());
            throw $e; // Re-throw to trigger rollback
        }
    }

    private function processWalletPayment($order)
    {
        $customer = $order->customer;

        // Refresh customer data to get latest wallet balance
        $customer->refresh();

        if ($customer->wallet_balance < $order->total) {
            throw new \Exception("Insufficient wallet balance. Required: {$order->total}, Available: {$customer->wallet_balance}");
        }

        // Use database transaction for atomic wallet update
        DB::transaction(function () use ($customer, $order) {
            // Lock the customer record to prevent race conditions
            $customer = User::where('id', $customer->id)->lockForUpdate()->first();

            if ($customer->wallet_balance < $order->total) {
                throw new \Exception('Insufficient wallet balance after lock');
            }

            $customer->decrement('wallet_balance', $order->total);
            $order->update(['payment_status' => 'completed']);

            // Record transaction
            $customer->walletTransactions()->create([
                'type' => 'payment',
                'amount' => -$order->total,
                'description' => "Payment for order #{$order->order_number}",
                'order_id' => $order->id
            ]);
        });
    }

    private function processGatewayPayment($order)
    {
        try {
            $paymentResult = null;

            switch ($order->payment_method) {
                case 'card':
                    $paymentResult = $this->processStripePayment($order);
                    break;
                case 'zain_cash':
                    $paymentResult = $this->processZainCashPayment($order);
                    break;
                default:
                    throw new \Exception("Unsupported payment method: {$order->payment_method}");
            }

            if (!$paymentResult || !$paymentResult['success']) {
                throw new \Exception("Payment gateway failed: " . ($paymentResult['error'] ?? 'Unknown error'));
            }

            // Update order with payment details
            $order->update([
                'payment_status' => 'completed',
                'payment_gateway_transaction_id' => $paymentResult['transaction_id'] ?? null,
                'payment_gateway_response' => json_encode($paymentResult)
            ]);

            \Illuminate\Support\Facades\Log::info("Gateway payment completed for order {$order->id}", [
                'payment_method' => $order->payment_method,
                'transaction_id' => $paymentResult['transaction_id'] ?? null,
                'amount' => $order->total
            ]);

        } catch (\Exception $e) {
            // Log payment failure
            \Illuminate\Support\Facades\Log::error("Gateway payment failed for order {$order->id}", [
                'payment_method' => $order->payment_method,
                'error' => $e->getMessage(),
                'amount' => $order->total
            ]);

            $order->update([
                'payment_status' => 'failed',
                'payment_failure_reason' => $e->getMessage()
            ]);

            throw new \Exception("Payment processing failed: " . $e->getMessage());
        }
    }

    private function distributePayments($order)
    {
        // Distribute payments to merchants
        $merchantPayments = [];

        foreach ($order->items as $item) {
            if (!isset($merchantPayments[$item->merchant_id])) {
                $merchantPayments[$item->merchant_id] = 0;
            }
            $merchantPayments[$item->merchant_id] += $item->total;
        }

        foreach ($merchantPayments as $merchantId => $amount) {
            $merchant = User::find($merchantId);
            $commissionRate = $this->getCommissionRate();
            $commissionAmount = $amount * $commissionRate;
            $netAmount = $amount - $commissionAmount;

            $merchant->increment('wallet_balance', $netAmount);

            // Record transactions
            $merchant->walletTransactions()->create([
                'type' => 'earning',
                'amount' => $netAmount,
                'description' => "Earning from order #{$order->order_number} (Commission: {$commissionRate}%)"
            ]);

            // Record commission transaction for platform
            \App\Models\WalletTransaction::create([
                'user_id' => null, // Platform commission
                'type' => 'commission',
                'amount' => $commissionAmount,
                'description' => "Commission from order #{$order->order_number} (Merchant: {$merchant->full_name})"
            ]);
        }

        // Pay driver
        if ($order->driver_id) {
            $driver = User::find($order->driver_id);
            $driverEarning = $order->delivery_fee + $order->tip;

            $driver->increment('wallet_balance', $driverEarning);

            $driver->walletTransactions()->create([
                'type' => 'earning',
                'amount' => $driverEarning,
                'description' => "Delivery earning from order #{$order->order_number}"
            ]);
        }
    }

    /**
     * Check if user can update order status
     */
    private function canUpdateOrderStatus($user, $order, $newStatus)
    {
        // Admin can update any status
        if ($user->user_type === 'admin') {
            return true;
        }

        // Driver can only update delivery-related statuses for assigned orders
        if ($user->isDriver()) {
            if ($order->driver_id !== $user->id) {
                return false;
            }
            return in_array($newStatus, ['out_for_delivery', 'delivered']);
        }

        // Merchant can update preparation statuses for their items
        if ($user->isMerchant()) {
            $hasMerchantItems = $order->items()->where('merchant_id', $user->id)->exists();
            if (!$hasMerchantItems) {
                return false;
            }
            return in_array($newStatus, ['accepted', 'preparing', 'ready_for_delivery']);
        }

        // Customers can only cancel pending orders
        if ($user->isRegular() || $user->isTemp()) {
            if ($order->customer_id !== $user->id) {
                return false;
            }
            return $newStatus === 'cancelled' && $order->status === 'pending';
        }

        return false;
    }

    /**
     * Validate order status transitions
     */
    private function isValidStatusTransition($currentStatus, $newStatus)
    {
        $validTransitions = [
            'pending' => ['accepted', 'cancelled'],
            'accepted' => ['preparing', 'cancelled'],
            'preparing' => ['ready_for_delivery', 'cancelled'],
            'ready_for_delivery' => ['out_for_delivery', 'cancelled'],
            'out_for_delivery' => ['delivered', 'cancelled'],
            'delivered' => [], // Final state
            'cancelled' => [] // Final state
        ];

        return in_array($newStatus, $validTransitions[$currentStatus] ?? []);
    }

    /**
     * Get configurable commission rate
     */
    private function getCommissionRate()
    {
        return config('app.commission_rate', 0.1); // Default 10%
    }

    /**
     * Validate order value constraints
     */
    private function validateOrderValue($total)
    {
        $minOrderValue = config('app.min_order_value', 5.00);
        $maxOrderValue = config('app.max_order_value', 500.00);

        if ($total < $minOrderValue) {
            throw new \Exception("Order value must be at least $minOrderValue");
        }

        if ($total > $maxOrderValue) {
            throw new \Exception("Order value cannot exceed $maxOrderValue");
        }
    }

    /**
     * Process Stripe payment
     */
    private function processStripePayment($order)
    {
        try {
            // Initialize Stripe with secret key
            $stripeSecretKey = config('services.stripe.secret');
            if (!$stripeSecretKey) {
                throw new \Exception('Stripe secret key not configured');
            }

            // Create Stripe payment intent
            $stripe = new \Stripe\StripeClient($stripeSecretKey);

            $paymentIntent = $stripe->paymentIntents->create([
                'amount' => $order->total * 100, // Convert to cents
                'currency' => 'usd',
                'description' => "Payment for order #{$order->order_number}",
                'metadata' => [
                    'order_id' => $order->id,
                    'customer_id' => $order->customer_id
                ]
            ]);

            return [
                'success' => true,
                'transaction_id' => $paymentIntent->id,
                'client_secret' => $paymentIntent->client_secret,
                'amount' => $order->total,
                'currency' => 'usd'
            ];

        } catch (\Exception $e) {
            \Illuminate\Support\Facades\Log::error('Stripe payment failed', [
                'order_id' => $order->id,
                'error' => $e->getMessage()
            ]);

            return [
                'success' => false,
                'error' => $e->getMessage()
            ];
        }
    }

    /**
     * Process Zain Cash payment
     */
    private function processZainCashPayment($order)
    {
        try {
            // Zain Cash API configuration
            $zainCashConfig = config('services.zain_cash');
            if (!$zainCashConfig || !$zainCashConfig['merchant_id'] || !$zainCashConfig['secret']) {
                throw new \Exception('Zain Cash configuration missing');
            }

            // Prepare Zain Cash payment request
            $paymentData = [
                'amount' => $order->total,
                'serviceType' => 'Delivery Service',
                'msisdn' => $order->customer->phone,
                'orderId' => $order->order_number,
                'merchantId' => $zainCashConfig['merchant_id'],
                'redirectUrl' => config('app.url') . '/payment/zain-cash/callback',
                'iat' => time(),
                'exp' => time() + 3600 // 1 hour expiration
            ];

            // Create JWT token for Zain Cash
            $token = $this->createZainCashJWT($paymentData, $zainCashConfig['secret']);

            // Make API call to Zain Cash
            $response = \Illuminate\Support\Facades\Http::post($zainCashConfig['api_url'] . '/transaction/init', [
                'token' => $token
            ]);

            if (!$response->successful()) {
                throw new \Exception('Zain Cash API request failed: ' . $response->body());
            }

            $responseData = $response->json();

            return [
                'success' => true,
                'transaction_id' => $responseData['id'] ?? null,
                'redirect_url' => $responseData['redirectUrl'] ?? null,
                'amount' => $order->total,
                'currency' => 'IQD'
            ];

        } catch (\Exception $e) {
            \Illuminate\Support\Facades\Log::error('Zain Cash payment failed', [
                'order_id' => $order->id,
                'error' => $e->getMessage()
            ]);

            return [
                'success' => false,
                'error' => $e->getMessage()
            ];
        }
    }

    /**
     * Create JWT token for Zain Cash
     */
    private function createZainCashJWT($payload, $secret)
    {
        $header = json_encode(['typ' => 'JWT', 'alg' => 'HS256']);
        $payload = json_encode($payload);

        $base64Header = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode($header));
        $base64Payload = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode($payload));

        $signature = hash_hmac('sha256', $base64Header . "." . $base64Payload, $secret, true);
        $base64Signature = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode($signature));

        return $base64Header . "." . $base64Payload . "." . $base64Signature;
    }

    /**
     * Validate delivery distance
     */
    private function validateDeliveryDistance($deliveryLat, $deliveryLng, $merchantLocation)
    {
        $maxDeliveryDistance = config('app.max_delivery_distance', 20); // Default 20km

        if (!$merchantLocation || !isset($merchantLocation['lat']) || !isset($merchantLocation['lng'])) {
            return [
                'valid' => false,
                'message' => 'Merchant location not available for delivery validation'
            ];
        }

        $distance = $this->calculateDistance(
            $merchantLocation['lat'],
            $merchantLocation['lng'],
            $deliveryLat,
            $deliveryLng
        );

        if ($distance > $maxDeliveryDistance) {
            return [
                'valid' => false,
                'message' => "Delivery location is too far. Maximum distance: {$maxDeliveryDistance}km, Requested: {$distance}km"
            ];
        }

        return [
            'valid' => true,
            'distance' => $distance,
            'message' => 'Delivery location is within range'
        ];
    }

    /**
     * Calculate delivery time estimation
     */
 function calculateDeliveryTime($distance, $preparationTime)
    {
        // Base delivery time calculation
        $averageSpeed = config('app.delivery_speed_kmh', 30); // 30 km/h average
        $deliveryTimeMinutes = ($distance / $averageSpeed) * 60;

        // Add buffer time for traffic and stops
        $bufferTime = config('app.delivery_buffer_minutes', 10);
        $deliveryTimeMinutes += $bufferTime;

        // Total time = preparation time + delivery time
        $totalEstimatedTime = $preparationTime + $deliveryTimeMinutes;

        return [
            'preparation_time' => $preparationTime,
            'delivery_time' => round($deliveryTimeMinutes),
            'total_time' => round($totalEstimatedTime),
            'estimated_delivery_at' => now()->addMinutes($totalEstimatedTime)->toISOString()
        ];
    }

    /**
     * Calculate distance between two points using Haversine formula
     */
    function calculateDistance($lat1, $lng1, $lat2, $lng2)
    {
        $earthRadius = 6371; // Earth's radius in kilometers

        $dLat = deg2rad($lat2 - $lat1);
        $dLng = deg2rad($lng2 - $lng1);

        $a = sin($dLat/2) * sin($dLat/2) + cos(deg2rad($lat1)) * cos(deg2rad($lat2)) * sin($dLng/2) * sin($dLng/2);
        $c = 2 * atan2(sqrt($a), sqrt(1-$a));

        return round($earthRadius * $c, 2);
    }

    /**
     * Handle failed delivery
     */
    function handleFailedDelivery(Request $request, $orderId)
    {
        try {
            $validator = Validator::make($request->all(), [
                'reason' => 'required|string|max:500',
                'retry_attempted' => 'boolean',
                'customer_contacted' => 'boolean'
            ]);

            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'message' => 'Validation failed',
                    'errors' => $validator->errors()
                ], 422);
            }

            $user = $request->user();
            $order = Order::findOrFail($orderId);

            // Only drivers can mark delivery as failed
            if (!$user->isDriver() || $order->driver_id !== $user->id) {
                return response()->json([
                    'success' => false,
                    'message' => 'Unauthorized to mark this delivery as failed'
                ], 403);
            }

            // Order must be out for delivery
            if ($order->status !== 'out_for_delivery') {
                return response()->json([
                    'success' => false,
                    'message' => 'Order is not out for delivery'
                ], 400);
            }

            DB::transaction(function() use ($order, $request) {
                // Update order status
                $order->update([
                    'status' => 'delivery_failed',
                    'delivery_failure_reason' => $request->reason,
                    'delivery_failed_at' => now()
                ]);

                // Log the failed delivery
                \Illuminate\Support\Facades\Log::warning('Delivery failed', [
                    'order_id' => $order->id,
                    'driver_id' => $order->driver_id,
                    'reason' => $request->reason,
                    'retry_attempted' => $request->retry_attempted,
                    'customer_contacted' => $request->customer_contacted
                ]);

                // TODO: Trigger notification to customer and admin
                // TODO: Initiate refund process if payment was completed
                // TODO: Release driver for new assignments
            });

            return response()->json([
                'success' => true,
                'message' => 'Delivery failure recorded successfully',
                'data' => $order->fresh()
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to record delivery failure',
                'error' => $e->getMessage()
            ], 500);
        }
    }
}
