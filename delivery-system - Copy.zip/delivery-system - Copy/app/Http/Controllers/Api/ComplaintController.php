<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Complaint;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Validator;

class ComplaintController extends Controller
{
    /**
     * Display a listing of complaints
     */
    public function index(Request $request): JsonResponse
    {
        try {
            $user = auth()->user();
    
            $query = Complaint::query();
    
            // Filter by user role
            if ($user->user_type === 'admin') {
                // Admin can see all complaints
            } elseif ($user->user_type === 'merchant') {
                // Merchant can see complaints about their orders
                $query->whereHas('order', function($q) use ($user) {
                    $q->where('merchant_id', $user->id);
                });
            } elseif ($user->user_type === 'driver') {
                // Driver can see complaints about their deliveries
                $query->whereHas('order', function($q) use ($user) {
                    $q->where('driver_id', $user->id);
                });
            } else {
                // Regular users can only see their own complaints
                $query->where('user_id', $user->id);
            }
    
            // Apply filters
            if ($request->filled('status')) {
                $query->where('status', $request->input('status'));
            }
    
            if ($request->filled('type')) {
                $query->where('type', $request->input('type'));
            }
    
            if ($request->filled('date_from')) {
                $query->whereDate('created_at', '>=', $request->input('date_from'));
            }
    
            if ($request->filled('date_to')) {
                $query->whereDate('created_at', '<=', $request->input('date_to'));
            }
    
            $complaints = $query->with(['user:id,full_name', 'order:id,order_number'])
                ->orderBy('created_at', 'desc')
                ->paginate($request->input('per_page', 15));
    
            return response()->json([
                'success' => true,
                'message' => __('messages.complaints_retrieved'),
                'data' => $complaints
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => __('messages.failed_to_retrieve_complaints'),
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Store a newly created complaint
     */
    public function store(Request $request): JsonResponse
    {
        try {
            $validator = Validator::make($request->all(), [
                'title' => 'required|string|max:255',
                'description' => 'required|string|max:2000',
                'type' => 'required|in:order,delivery,payment,technical,other',
                'order_id' => 'nullable|exists:orders,id',
                'priority' => 'required|in:low,medium,high,urgent',
                'attachments' => 'nullable|array',
                'attachments.*' => 'nullable|string|max:255'
            ]);

            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'message' => __('messages.validation_failed'),
                    'errors' => $validator->errors()
                ], 422);
            }

            $user = auth()->user();

            $complaint = Complaint::create([
                'user_id' => $user->id,
                'title' => $request->title,
                'description' => $request->description,
                'type' => $request->type,
                'order_id' => $request->order_id,
                'priority' => $request->priority,
                'status' => 'pending',
                'attachments' => $request->attachments ?? []
            ]);

            return response()->json([
                'success' => true,
                'message' => __('messages.complaint_submitted'),
                'data' => $complaint
            ], 201);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => __('messages.failed_to_submit_complaint'),
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Display the specified complaint
     */
    public function show($id): JsonResponse
    {
        try {
            $user = auth()->user();

            $complaint = Complaint::with(['user:id,full_name', 'order:id,order_number'])
                ->findOrFail($id);

            // Check if user has permission to view this complaint
            if ($user->user_type !== 'admin' && $complaint->user_id !== $user->id) {
                // Check if it's related to user's orders (for merchants/drivers)
                if ($user->user_type === 'merchant' && $complaint->order && $complaint->order->merchant_id !== $user->id) {
                    return response()->json([
                        'success' => false,
                        'message' => __('messages.unauthorized_access')
                    ], 403);
                }

                if ($user->user_type === 'driver' && $complaint->order && $complaint->order->driver_id !== $user->id) {
                    return response()->json([
                        'success' => false,
                        'message' => __('messages.unauthorized_access')
                    ], 403);
                }
            }

            return response()->json([
                'success' => true,
                'message' => 'Complaint retrieved successfully',
                'data' => $complaint
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to retrieve complaint',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Update complaint status (admin only)
     */
    public function updateStatus(Request $request, $id): JsonResponse
    {
        try {
            $user = auth()->user();

            if ($user->user_type !== 'admin') {
                return response()->json([
                    'success' => false,
                    'message' => __('messages.unauthorized_access')
                ], 403);
            }

            $validator = Validator::make($request->all(), [
                'status' => 'required|in:pending,in_progress,resolved,closed',
                'admin_response' => 'nullable|string|max:1000',
                'resolution_notes' => 'nullable|string|max:1000'
            ]);

            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'message' => __('messages.validation_failed'),
                    'errors' => $validator->errors()
                ], 422);
            }

            $complaint = Complaint::findOrFail($id);

            $complaint->update([
                'status' => $request->status,
                'admin_response' => $request->admin_response,
                'resolution_notes' => $request->resolution_notes,
                'resolved_at' => $request->status === 'resolved' ? now() : null
            ]);

            return response()->json([
                'success' => true,
                'message' => __('messages.complaint_status_updated'),
                'data' => $complaint
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => __('messages.failed_to_update_complaint_status'),
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Add response to complaint
     */
    public function addResponse(Request $request, $id): JsonResponse
    {
        try {
            $validator = Validator::make($request->all(), [
                'response' => 'required|string|max:1000'
            ]);

            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'message' => __('messages.validation_failed'),
                    'errors' => $validator->errors()
                ], 422);
            }

            $user = auth()->user();
            $complaint = Complaint::findOrFail($id);

            // Check if user has permission to respond
            if ($user->user_type !== 'admin' && $complaint->user_id !== $user->id) {
                return response()->json([
                    'success' => false,
                    'message' => __('messages.unauthorized_access')
                ], 403);
            }

            // Add response to complaint
            $responses = $complaint->responses ?? [];
            $responses[] = [
                'user_id' => $user->id,
                'user_name' => $user->full_name,
                'response' => $request->response,
                'timestamp' => now()->toISOString()
            ];

            $complaint->update([
                'responses' => $responses,
                'status' => $user->user_type === 'admin' ? 'in_progress' : $complaint->status
            ]);

            return response()->json([
                'success' => true,
                'message' => __('messages.response_added_successfully'),
                'data' => $complaint
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => __('messages.failed_to_add_response'),
                'error' => $e->getMessage()
            ], 500);
        }
    }
}
