<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Product;
use App\Models\Category;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Storage;

class ProductController extends Controller
{
    public function index(Request $request)
    {
        try {
            $query = Product::with(['merchant', 'category']);

            // Apply filters
            if ($request->has('category_id')) {
                $query->where('category_id', $request->category_id);
            }

            if ($request->has('merchant_id')) {
                $query->where('merchant_id', $request->merchant_id);
            }

            if ($request->has('available')) {
                $query->where('is_available', $request->boolean('available'));
            }

            if ($request->has('search')) {
                $query->search($request->search);
            }

            if ($request->has('min_price')) {
                $query->where('price', '>=', $request->min_price);
            }

            if ($request->has('max_price')) {
                $query->where('price', '<=', $request->max_price);
            }

            // Default to available products only
            if (!$request->has('available')) {
                $query->available();
            }

            $products = $query->orderBy('created_at', 'desc')->paginate(20);

            return response()->json([
                'success' => true,
                'data' => $products
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => __('messages.failed_to_fetch_products'),
                'error' => $e->getMessage()
            ], 500);
        }
    }

    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'category_id' => 'required|exists:categories,id',
            'name' => 'required|string|max:255',
            'name_ar' => 'required|string|max:255',
            'description' => 'nullable|string',
            'description_ar' => 'nullable|string',
            'price' => 'required|numeric|min:0',
            'currency' => 'nullable|string|size:3',
            'images' => 'required|array|min:1',
            'images.*' => 'string', // Base64 encoded images or URLs
            'loyalty_points' => 'nullable|integer|min:0',
            'preparation_time' => 'nullable|integer|min:5'
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => __('messages.validation_failed'),
                'errors' => $validator->errors()
            ], 422);
        }

        try {
            $user = $request->user();

            if (!$user->isMerchant()) {
                return response()->json([
                    'success' => false,
                    'message' => __('messages.only_merchants_can_create_products')
                ], 403);
            }

            if (!$user->is_active) {
                return response()->json([
                    'success' => false,
                    'message' => __('messages.account_not_activated')
                ], 403);
            }

            // Process images
            $imagePaths = [];
            foreach ($request->images as $image) {
                if (filter_var($image, FILTER_VALIDATE_URL)) {
                    // If it's a URL, store it directly
                    $imagePaths[] = $image;
                } else {
                    // If it's base64, decode and store
                    $imagePaths[] = $this->storeBase64Image($image);
                }
            }

            $product = Product::create([
                'merchant_id' => $user->id,
                'category_id' => $request->category_id,
                'name' => $request->name,
                'name_ar' => $request->name_ar,
                'description' => $request->description,
                'description_ar' => $request->description_ar,
                'price' => $request->price,
                'currency' => $request->currency ?? 'USD',
                'images' => $imagePaths,
                'loyalty_points' => $request->loyalty_points ?? 0,
                'preparation_time' => $request->preparation_time ?? 30
            ]);

            return response()->json([
                'success' => true,
                'message' => __('messages.product_created'),
                'data' => [
                    'product' => $product->load(['category', 'merchant'])
                ]
            ], 201);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => __('messages.failed_to_create_product'),
                'error' => $e->getMessage()
            ], 500);
        }
    }

    public function show($id)
    {
        try {
            $product = Product::with(['merchant', 'category'])->findOrFail($id);

            return response()->json([
                'success' => true,
                'data' => [
                    'product' => $product
                ]
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => __('messages.product_not_found'),
                'error' => $e->getMessage()
            ], 404);
        }
    }

    public function update(Request $request, $id)
    {
        $validator = Validator::make($request->all(), [
            'category_id' => 'sometimes|exists:categories,id',
            'name' => 'sometimes|string|max:255',
            'name_ar' => 'sometimes|string|max:255',
            'description' => 'nullable|string',
            'description_ar' => 'nullable|string',
            'price' => 'sometimes|numeric|min:0',
            'currency' => 'nullable|string|size:3',
            'images' => 'sometimes|array|min:1',
            'images.*' => 'string',
            'is_available' => 'sometimes|boolean',
            'loyalty_points' => 'nullable|integer|min:0',
            'preparation_time' => 'nullable|integer|min:5'
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => __('messages.validation_failed'),
                'errors' => $validator->errors()
            ], 422);
        }

        try {
            $user = $request->user();
            $product = Product::findOrFail($id);

            // Check if user owns this product
            if ($product->merchant_id !== $user->id && !$user->isAdmin()) {
                return response()->json([
                    'success' => false,
                    'message' => 'Unauthorized'
                ], 403);
            }

            $updateData = $request->only([
                'category_id', 'name', 'name_ar', 'description', 'description_ar',
                'price', 'currency', 'is_available', 'loyalty_points', 'preparation_time'
            ]);

            // Process images if provided
            if ($request->has('images')) {
                $imagePaths = [];
                foreach ($request->images as $image) {
                    if (filter_var($image, FILTER_VALIDATE_URL)) {
                        $imagePaths[] = $image;
                    } else {
                        $imagePaths[] = $this->storeBase64Image($image);
                    }
                }
                $updateData['images'] = $imagePaths;
            }

            $product->update($updateData);

            return response()->json([
                'success' => true,
                'message' => __('messages.product_updated'),
                'data' => [
                    'product' => $product->fresh(['category', 'merchant'])
                ]
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => __('messages.failed_to_update_product'),
                'error' => $e->getMessage()
            ], 500);
        }
    }

    public function destroy(Request $request, $id)
    {
        try {
            $user = $request->user();
            $product = Product::findOrFail($id);

            // Check if user owns this product
            if ($product->merchant_id !== $user->id && !$user->isAdmin()) {
                return response()->json([
                    'success' => false,
                    'message' => 'Unauthorized'
                ], 403);
            }

            // Check if product has active orders
            $hasActiveOrders = $product->orderItems()
                ->whereHas('order', function($query) {
                    $query->whereIn('status', ['pending', 'accepted', 'preparing', 'ready', 'picked_up']);
                })
                ->exists();

            if ($hasActiveOrders) {
                return response()->json([
                    'success' => false,
                    'message' => 'Cannot delete product with active orders'
                ], 400);
            }

            $product->delete();

            return response()->json([
                'success' => true,
                'message' => __('messages.product_deleted')
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => __('messages.failed_to_delete_product'),
                'error' => $e->getMessage()
            ], 500);
        }
    }

    public function search(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'q' => 'required|string|min:2',
            'category_id' => 'nullable|exists:categories,id',
            'merchant_id' => 'nullable|exists:users,id',
            'min_price' => 'nullable|numeric|min:0',
            'max_price' => 'nullable|numeric|min:0',
            'sort_by' => 'nullable|in:price,name,created_at,rating',
            'sort_order' => 'nullable|in:asc,desc'
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => __('messages.validation_failed'),
                'errors' => $validator->errors()
            ], 422);
        }

        try {
            $query = Product::with(['merchant', 'category'])
                ->available()
                ->search($request->q);

            // Apply filters
            if ($request->has('category_id')) {
                $query->where('category_id', $request->category_id);
            }

            if ($request->has('merchant_id')) {
                $query->where('merchant_id', $request->merchant_id);
            }

            if ($request->has('min_price')) {
                $query->where('price', '>=', $request->min_price);
            }

            if ($request->has('max_price')) {
                $query->where('price', '<=', $request->max_price);
            }

            // Apply sorting
            $sortBy = $request->sort_by ?? 'created_at';
            $sortOrder = $request->sort_order ?? 'desc';
            $query->orderBy($sortBy, $sortOrder);

            $products = $query->paginate(20);

            return response()->json([
                'success' => true,
                'data' => $products
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Search failed',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    public function toggleAvailability(Request $request, $id)
    {
        try {
            $user = $request->user();
            $product = Product::findOrFail($id);

            // Check if user owns this product
            if ($product->merchant_id !== $user->id && !$user->isAdmin()) {
                return response()->json([
                    'success' => false,
                    'message' => 'Unauthorized'
                ], 403);
            }

            $product->update(['is_available' => !$product->is_available]);

            return response()->json([
                'success' => true,
                'message' => 'Product availability updated',
                'data' => [
                    'product' => $product->fresh()
                ]
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to update availability',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    private function storeBase64Image($base64Image)
    {
        // Remove data:image/jpeg;base64, part if present
        $image = str_replace('data:image/jpeg;base64,', '', $base64Image);
        $image = str_replace('data:image/png;base64,', '', $image);
        $image = str_replace(' ', '+', $image);

        $imageName = 'products/' . uniqid() . '.jpg';
        Storage::disk('public')->put($imageName, base64_decode($image));

        return Storage::url($imageName);
    }
}

