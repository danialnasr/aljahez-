<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Order;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;

class DriverController extends Controller
{
    /**
     * Go online (start accepting orders)
     */
    public function goOnline(): JsonResponse
    {
        try {
            $user = auth()->user();
    
            if ($user->user_type !== 'driver') {
                return response()->json([
                    'success' => false,
                    'message' => 'Only drivers can perform this action'
                ], 403);
            }
    
            $user->is_online = true;
            $user->last_online_at = now();
            $user->save();
    
            return response()->json([
                'success' => true,
                'message' => 'Driver is now online',
                'data' => [
                    'is_online' => true,
                    'last_online_at' => $user->last_online_at
                ]
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to go online',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Go offline (stop accepting orders)
     */
    public function goOffline(): JsonResponse
    {
        try {
            $user = auth()->user();

            if ($user->user_type !== 'driver') {
                return response()->json([
                    'success' => false,
                    'message' => 'Only drivers can perform this action'
                ], 403);
            }

            $user->update([
                'is_online' => false,
                'last_offline_at' => now()
            ]);

            return response()->json([
                'success' => true,
                'message' => 'Driver is now offline',
                'data' => [
                    'is_online' => false,
                    'last_offline_at' => $user->last_offline_at
                ]
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to go offline',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Get available orders for driver
     */
    public function getOrders(Request $request): JsonResponse
    {
        try {
            $user = auth()->user();

            if ($user->user_type !== 'driver') {
                return response()->json([
                    'success' => false,
                    'message' => 'Only drivers can perform this action'
                ], 403);
            }

            $query = Order::where('status', 'pending')
                ->whereNull('driver_id')
                ->where('delivery_type', 'delivery')
                ->with(['customer:id,full_name,phone,latitude,longitude', 'merchant:id,full_name,latitude,longitude']);

            // Filter by distance if driver location is available
            if ($user->latitude && $user->longitude) {
                $query->select('*')
                    ->selectRaw('
                        (6371 * acos(cos(radians(?)) * cos(radians(latitude)) *
                        cos(radians(longitude) - radians(?)) + sin(radians(?)) *
                        sin(radians(latitude)))) AS distance',
                        [$user->latitude, $user->longitude, $user->latitude])
                    ->orderBy('distance', 'asc');
            }

            // Apply filters
            if ($request->has('status')) {
                $query->where('status', $request->status);
            }

            if ($request->has('min_amount')) {
                $query->where('total_amount', '>=', $request->min_amount);
            }

            if ($request->has('max_distance')) {
                $query->having('distance', '<=', $request->max_distance);
            }

            $orders = $query->paginate($request->get('per_page', 15));

            return response()->json([
                'success' => true,
                'message' => 'Orders retrieved successfully',
                'data' => $orders
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to retrieve orders',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Accept an order
     */
    public function acceptOrder(Request $request, $orderId): JsonResponse
    {
        try {
            $user = auth()->user();

            if ($user->user_type !== 'driver') {
                return response()->json([
                    'success' => false,
                    'message' => 'Only drivers can perform this action'
                ], 403);
            }

            $order = Order::where('id', $orderId)
                ->where('status', 'pending')
                ->whereNull('driver_id')
                ->first();

            if (!$order) {
                return response()->json([
                    'success' => false,
                    'message' => 'Order not available or already assigned'
                ], 400);
            }

            $order->update([
                'driver_id' => $user->id,
                'status' => 'accepted',
                'accepted_at' => now()
            ]);

            return response()->json([
                'success' => true,
                'message' => 'Order accepted successfully',
                'data' => $order
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to accept order',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Get driver earnings
     */
    public function getEarnings(Request $request): JsonResponse
    {
        try {
            $user = auth()->user();

            if ($user->user_type !== 'driver') {
                return response()->json([
                    'success' => false,
                    'message' => 'Only drivers can perform this action'
                ], 403);
            }

            $query = Order::where('driver_id', $user->id)
                ->where('status', 'delivered');

            // Apply date filters
            if ($request->has('date_from')) {
                $query->whereDate('delivered_at', '>=', $request->date_from);
            }

            if ($request->has('date_to')) {
                $query->whereDate('delivered_at', '<=', $request->date_to);
            }

            $earnings = $query->sum('delivery_fee');
            $totalOrders = $query->count();

            // Get earnings by period
            $dailyEarnings = Order::where('driver_id', $user->id)
                ->where('status', 'delivered')
                ->whereDate('delivered_at', today())
                ->sum('delivery_fee');

            $weeklyEarnings = Order::where('driver_id', $user->id)
                ->where('status', 'delivered')
                ->whereBetween('delivered_at', [now()->startOfWeek(), now()->endOfWeek()])
                ->sum('delivery_fee');

            $monthlyEarnings = Order::where('driver_id', $user->id)
                ->where('status', 'delivered')
                ->whereMonth('delivered_at', now()->month)
                ->sum('delivery_fee');

            return response()->json([
                'success' => true,
                'message' => 'Earnings retrieved successfully',
                'data' => [
                    'total_earnings' => $earnings,
                    'total_orders' => $totalOrders,
                    'daily_earnings' => $dailyEarnings,
                    'weekly_earnings' => $weeklyEarnings,
                    'monthly_earnings' => $monthlyEarnings,
                    'currency' => 'USD'
                ]
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to retrieve earnings',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Get driver statistics
     */
    public function getStats(): JsonResponse
    {
        try {
            $user = auth()->user();

            if ($user->user_type !== 'driver') {
                return response()->json([
                    'success' => false,
                    'message' => 'Only drivers can perform this action'
                ], 403);
            }

            // Get current month stats
            $currentMonth = now()->month;
            $currentYear = now()->year;

            $monthlyStats = Order::where('driver_id', $user->id)
                ->whereMonth('created_at', $currentMonth)
                ->whereYear('created_at', $currentYear)
                ->selectRaw('
                    COUNT(*) as total_orders,
                    SUM(CASE WHEN status = "delivered" THEN 1 ELSE 0 END) as completed_orders,
                    SUM(CASE WHEN status = "cancelled" THEN 1 ELSE 0 END) as cancelled_orders,
                    SUM(delivery_fee) as total_earnings,
                    AVG(CASE WHEN status = "delivered" THEN delivery_fee ELSE NULL END) as avg_earnings_per_order
                ')
                ->first();

            // Get rating stats
            $ratingStats = DB::table('ratings')
                ->where('rated_user_id', $user->id)
                ->where('type', 'driver')
                ->selectRaw('
                    COUNT(*) as total_ratings,
                    AVG(rating) as average_rating,
                    COUNT(CASE WHEN rating >= 4 THEN 1 END) as positive_ratings
                ')
                ->first();

            // Get online hours
            $onlineHours = Order::where('driver_id', $user->id)
                ->whereMonth('created_at', $currentMonth)
                ->whereYear('created_at', $currentYear)
                ->whereNotNull('accepted_at')
                ->whereNotNull('delivered_at')
                ->selectRaw('SUM(TIMESTAMPDIFF(MINUTE, accepted_at, delivered_at)) as total_minutes')
                ->first();

            return response()->json([
                'success' => true,
                'message' => 'Statistics retrieved successfully',
                'data' => [
                    'monthly_stats' => $monthlyStats,
                    'rating_stats' => $ratingStats,
                    'online_hours' => round($onlineHours->total_minutes / 60, 2),
                    'current_status' => [
                        'is_online' => $user->is_online,
                        'last_online_at' => $user->last_online_at,
                        'last_offline_at' => $user->last_offline_at
                    ]
                ]
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to retrieve statistics',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Update driver location
     */
    public function updateLocation(Request $request): JsonResponse
    {
        try {
            $user = auth()->user();

            if ($user->user_type !== 'driver') {
                return response()->json([
                    'success' => false,
                    'message' => 'Only drivers can perform this action'
                ], 403);
            }

            $validator = Validator::make($request->all(), [
                'latitude' => 'required|numeric|between:-90,90',
                'longitude' => 'required|numeric|between:-180,180'
            ]);

            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'message' => 'Validation failed',
                    'errors' => $validator->errors()
                ], 422);
            }

            $user->update([
                'latitude' => $request->latitude,
                'longitude' => $request->longitude,
                'location_updated_at' => now()
            ]);

            return response()->json([
                'success' => true,
                'message' => 'Location updated successfully',
                'data' => [
                    'latitude' => $user->latitude,
                    'longitude' => $user->longitude,
                    'location_updated_at' => $user->location_updated_at
                ]
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to update location',
                'error' => $e->getMessage()
            ], 500);
        }
    }
}
