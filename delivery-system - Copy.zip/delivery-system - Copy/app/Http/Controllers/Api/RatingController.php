<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Rating;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Validator;

class RatingController extends Controller
{
    /**
     * Store a new rating
     */
    public function store(Request $request): JsonResponse
    {
        try {
            $validator = Validator::make($request->all(), [
                'rated_user_id' => 'required|exists:users,id',
                'rating' => 'required|numeric|between:1,5',
                'comment' => 'nullable|string|max:1000',
                'order_id' => 'nullable|exists:orders,id',
                'type' => 'required|in:driver,merchant,customer'
            ]);

            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'message' => __('messages.validation_failed'),
                    'errors' => $validator->errors()
                ], 422);
            }

            $user = auth()->user();

            // Check if user has already rated this user for this order
            if ($request->order_id) {
                $existingRating = Rating::where('user_id', $user->id)
                    ->where('rated_user_id', $request->rated_user_id)
                    ->where('order_id', $request->order_id)
                    ->first();

                if ($existingRating) {
                    return response()->json([
                        'success' => false,
                        'message' => __('messages.you_already_rated')
                    ], 400);
                }
            }

            // Create rating
            $rating = Rating::create([
                'user_id' => $user->id,
                'rated_user_id' => $request->rated_user_id,
                'rating' => $request->rating,
                'comment' => $request->comment,
                'order_id' => $request->order_id,
                'type' => $request->type
            ]);

            // Update average rating for rated user
            $this->updateUserAverageRating($request->rated_user_id);

            return response()->json([
                'success' => true,
                'message' => __('messages.rating_submitted'),
                'data' => $rating
            ], 201);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => __('messages.failed_to_add_response'),
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Get ratings for a specific user
     */
    public function getUserRatings($userId): JsonResponse
    {
        try {
            $user = User::findOrFail($userId);

            $ratings = Rating::where('rated_user_id', $userId)
                ->with('user:id,full_name,profile_image')
                ->orderBy('created_at', 'desc')
                ->paginate(15);

            // Get average rating
            $averageRating = Rating::where('rated_user_id', $userId)->avg('rating');

            return response()->json([
                'success' => true,
                'message' => 'User ratings retrieved successfully',
                'data' => [
                    'user' => [
                        'id' => $user->id,
                        'full_name' => $user->full_name,
                        'profile_image' => $user->profile_image,
                        'average_rating' => round($averageRating, 1),
                        'total_ratings' => $ratings->total()
                    ],
                    'ratings' => $ratings
                ]
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to retrieve user ratings',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Get my ratings
     */
    public function getMyRatings(): JsonResponse
    {
        try {
            $user = auth()->user();

            $ratings = Rating::where('user_id', $user->id)
                ->with('ratedUser:id,full_name,profile_image')
                ->orderBy('created_at', 'desc')
                ->paginate(15);

            return response()->json([
                'success' => true,
                'message' => 'My ratings retrieved successfully',
                'data' => $ratings
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to retrieve my ratings',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Update a rating
     */
    public function update(Request $request, $id): JsonResponse
    {
        try {
            $rating = Rating::where('user_id', auth()->id())
                ->findOrFail($id);

            $validator = Validator::make($request->all(), [
                'rating' => 'required|numeric|between:1,5',
                'comment' => 'nullable|string|max:1000'
            ]);

            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'message' => 'Validation failed',
                    'errors' => $validator->errors()
                ], 422);
            }

            $rating->update($request->only(['rating', 'comment']));

            // Update average rating for rated user
            $this->updateUserAverageRating($rating->rated_user_id);

            return response()->json([
                'success' => true,
                'message' => 'Rating updated successfully',
                'data' => $rating
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to update rating',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Delete a rating
     */
    public function destroy($id): JsonResponse
    {
        try {
            $rating = Rating::where('user_id', auth()->id())
                ->findOrFail($id);

            $ratedUserId = $rating->rated_user_id;
            $rating->delete();

            // Update average rating for rated user
            $this->updateUserAverageRating($ratedUserId);

            return response()->json([
                'success' => true,
                'message' => 'Rating deleted successfully'
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to delete rating',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Update user's average rating
     */
    private function updateUserAverageRating($userId): void
    {
        $averageRating = Rating::where('rated_user_id', $userId)->avg('rating');

        User::where('id', $userId)->update([
            'average_rating' => round($averageRating, 1)
        ]);
    }
}
