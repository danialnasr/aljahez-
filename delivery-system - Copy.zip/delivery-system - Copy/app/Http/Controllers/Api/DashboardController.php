<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Order;
use App\Models\User;
use App\Models\Product;
use App\Models\WalletTransaction;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class DashboardController extends Controller
{
    /**
     * Get comprehensive business intelligence dashboard data
     */
    public function getBusinessIntelligence(Request $request)
    {
        try {
            $user = $request->user();
            
            // Check admin permissions
            if (!$user->isAdmin()) {
                return response()->json([
                    'success' => false,
                    'message' => 'Unauthorized access to dashboard'
                ], 403);
            }

            $period = $request->input('period', '30'); // Default 30 days
            $startDate = Carbon::now()->subDays($period);

            $dashboard = [
                'overview' => $this->getOverviewMetrics($startDate),
                'revenue' => $this->getRevenueAnalytics($startDate),
                'orders' => $this->getOrderAnalytics($startDate),
                'users' => $this->getUserAnalytics($startDate),
                'performance' => $this->getPerformanceMetrics($startDate),
                'trends' => $this->getTrendAnalysis($startDate),
                'geographical' => $this->getGeographicalData($startDate)
            ];

            return response()->json([
                'success' => true,
                'data' => $dashboard,
                'period' => $period . ' days',
                'generated_at' => now()->toISOString()
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to generate dashboard',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Get overview metrics
     */
    private function getOverviewMetrics($startDate)
    {
        return [
            'total_orders' => Order::where('created_at', '>=', $startDate)->count(),
            'total_revenue' => Order::where('created_at', '>=', $startDate)
                ->where('status', 'delivered')->sum('total'),
            'active_users' => User::where('last_login_at', '>=', $startDate)->count(),
            'new_registrations' => User::where('created_at', '>=', $startDate)->count(),
            'completion_rate' => $this->calculateCompletionRate($startDate),
            'average_order_value' => Order::where('created_at', '>=', $startDate)
                ->where('status', 'delivered')->avg('total')
        ];
    }

    /**
     * Get revenue analytics
     */
    private function getRevenueAnalytics($startDate)
    {
        $dailyRevenue = Order::select(
                DB::raw('DATE(created_at) as date'),
                DB::raw('SUM(total) as revenue'),
                DB::raw('COUNT(*) as orders')
            )
            ->where('created_at', '>=', $startDate)
            ->where('status', 'delivered')
            ->groupBy('date')
            ->orderBy('date')
            ->get();

        $paymentMethods = Order::select('payment_method', DB::raw('SUM(total) as total'))
            ->where('created_at', '>=', $startDate)
            ->where('status', 'delivered')
            ->groupBy('payment_method')
            ->get();

        return [
            'daily_revenue' => $dailyRevenue,
            'payment_methods_breakdown' => $paymentMethods,
            'commission_earned' => $this->calculateCommissionEarned($startDate),
            'wallet_transactions' => WalletTransaction::where('created_at', '>=', $startDate)
                ->sum('amount')
        ];
    }

    /**
     * Get order analytics
     */
    private function getOrderAnalytics($startDate)
    {
        $statusDistribution = Order::select('status', DB::raw('COUNT(*) as count'))
            ->where('created_at', '>=', $startDate)
            ->groupBy('status')
            ->get();

        $hourlyOrders = Order::select(
                DB::raw('HOUR(created_at) as hour'),
                DB::raw('COUNT(*) as orders')
            )
            ->where('created_at', '>=', $startDate)
            ->groupBy('hour')
            ->orderBy('hour')
            ->get();

        return [
            'status_distribution' => $statusDistribution,
            'hourly_distribution' => $hourlyOrders,
            'average_delivery_time' => $this->calculateAverageDeliveryTime($startDate),
            'cancellation_rate' => $this->calculateCancellationRate($startDate),
            'peak_hours' => $this->identifyPeakHours($startDate)
        ];
    }

    /**
     * Get user analytics
     */
    private function getUserAnalytics($startDate)
    {
        $userTypes = User::select('user_type', DB::raw('COUNT(*) as count'))
            ->where('created_at', '>=', $startDate)
            ->groupBy('user_type')
            ->get();

        return [
            'user_types_distribution' => $userTypes,
            'retention_rate' => $this->calculateRetentionRate($startDate),
            'most_active_users' => $this->getMostActiveUsers($startDate),
            'driver_performance' => $this->getDriverPerformance($startDate)
        ];
    }

    /**
     * Get performance metrics
     */
    private function getPerformanceMetrics($startDate)
    {
        return [
            'average_response_time' => $this->calculateAverageResponseTime($startDate),
            'customer_satisfaction' => $this->calculateCustomerSatisfaction($startDate),
            'delivery_success_rate' => $this->calculateDeliverySuccessRate($startDate),
            'merchant_performance' => $this->getMerchantPerformance($startDate)
        ];
    }

    /**
     * Get trend analysis
     */
    private function getTrendAnalysis($startDate)
    {
        $weeklyTrends = Order::select(
                DB::raw('WEEK(created_at) as week'),
                DB::raw('COUNT(*) as orders'),
                DB::raw('SUM(total) as revenue')
            )
            ->where('created_at', '>=', $startDate)
            ->groupBy('week')
            ->orderBy('week')
            ->get();

        return [
            'weekly_trends' => $weeklyTrends,
            'growth_rate' => $this->calculateGrowthRate($startDate),
            'seasonal_patterns' => $this->identifySeasonalPatterns($startDate)
        ];
    }

    /**
     * Get geographical data
     */
    private function getGeographicalData($startDate)
    {
        $ordersByLocation = Order::select(
                'delivery_address',
                DB::raw('COUNT(*) as order_count'),
                DB::raw('AVG(delivery_lat) as avg_lat'),
                DB::raw('AVG(delivery_lng) as avg_lng')
            )
            ->where('created_at', '>=', $startDate)
            ->groupBy('delivery_address')
            ->having('order_count', '>', 5)
            ->get();

        return [
            'popular_locations' => $ordersByLocation,
            'delivery_heatmap' => $this->generateDeliveryHeatmap($startDate),
            'coverage_analysis' => $this->analyzeCoverageArea($startDate)
        ];
    }

    // Helper methods for calculations
    private function calculateCompletionRate($startDate)
    {
        $total = Order::where('created_at', '>=', $startDate)->count();
        $completed = Order::where('created_at', '>=', $startDate)
            ->where('status', 'delivered')->count();
        
        return $total > 0 ? round(($completed / $total) * 100, 2) : 0;
    }

    private function calculateCommissionEarned($startDate)
    {
        $totalRevenue = Order::where('created_at', '>=', $startDate)
            ->where('status', 'delivered')->sum('total');
        
        $commissionRate = config('app.commission_rate', 0.15); // 15% default
        return $totalRevenue * $commissionRate;
    }

    private function calculateAverageDeliveryTime($startDate)
    {
        return Order::where('created_at', '>=', $startDate)
            ->where('status', 'delivered')
            ->whereNotNull('delivered_at')
            ->selectRaw('AVG(TIMESTAMPDIFF(MINUTE, created_at, delivered_at)) as avg_time')
            ->value('avg_time') ?? 0;
    }

    private function calculateCancellationRate($startDate)
    {
        $total = Order::where('created_at', '>=', $startDate)->count();
        $cancelled = Order::where('created_at', '>=', $startDate)
            ->where('status', 'cancelled')->count();
        
        return $total > 0 ? round(($cancelled / $total) * 100, 2) : 0;
    }

    private function identifyPeakHours($startDate)
    {
        return Order::select(DB::raw('HOUR(created_at) as hour'))
            ->where('created_at', '>=', $startDate)
            ->groupBy('hour')
            ->orderByRaw('COUNT(*) DESC')
            ->limit(3)
            ->pluck('hour')
            ->toArray();
    }

    private function calculateRetentionRate($startDate)
    {
        // Calculate 7-day retention rate
        $newUsers = User::where('created_at', '>=', $startDate)->count();
        $activeAfter7Days = User::where('created_at', '>=', $startDate)
            ->where('last_login_at', '>=', Carbon::parse($startDate)->addDays(7))
            ->count();
        
        return $newUsers > 0 ? round(($activeAfter7Days / $newUsers) * 100, 2) : 0;
    }

    private function getMostActiveUsers($startDate)
    {
        return User::withCount(['orders' => function($query) use ($startDate) {
                $query->where('created_at', '>=', $startDate);
            }])
            ->having('orders_count', '>', 0)
            ->orderBy('orders_count', 'desc')
            ->limit(10)
            ->get(['id', 'name', 'email', 'orders_count']);
    }

    private function getDriverPerformance($startDate)
    {
        return User::where('user_type', 'driver')
            ->withCount(['deliveredOrders' => function($query) use ($startDate) {
                $query->where('created_at', '>=', $startDate);
            }])
            ->withAvg(['deliveredOrders' => function($query) use ($startDate) {
                $query->where('created_at', '>=', $startDate);
            }], 'rating')
            ->orderBy('delivered_orders_count', 'desc')
            ->limit(10)
            ->get();
    }

    private function calculateAverageResponseTime($startDate)
    {
        return Order::where('created_at', '>=', $startDate)
            ->where('status', '!=', 'pending')
            ->whereNotNull('accepted_at')
            ->selectRaw('AVG(TIMESTAMPDIFF(MINUTE, created_at, accepted_at)) as avg_response')
            ->value('avg_response') ?? 0;
    }

    private function calculateCustomerSatisfaction($startDate)
    {
        return DB::table('ratings')
            ->where('created_at', '>=', $startDate)
            ->avg('rating') ?? 0;
    }

    private function calculateDeliverySuccessRate($startDate)
    {
        $total = Order::where('created_at', '>=', $startDate)
            ->whereIn('status', ['delivered', 'delivery_failed'])->count();
        $successful = Order::where('created_at', '>=', $startDate)
            ->where('status', 'delivered')->count();
        
        return $total > 0 ? round(($successful / $total) * 100, 2) : 0;
    }

    private function getMerchantPerformance($startDate)
    {
        return User::where('user_type', 'merchant')
            ->withCount(['merchantOrders' => function($query) use ($startDate) {
                $query->where('created_at', '>=', $startDate);
            }])
            ->withSum(['merchantOrders' => function($query) use ($startDate) {
                $query->where('created_at', '>=', $startDate)
                      ->where('status', 'delivered');
            }], 'total')
            ->orderBy('merchant_orders_count', 'desc')
            ->limit(10)
            ->get();
    }

    private function calculateGrowthRate($startDate)
    {
        $currentPeriod = Order::where('created_at', '>=', $startDate)->count();
        $previousPeriod = Order::where('created_at', '>=', Carbon::parse($startDate)->subDays(30))
            ->where('created_at', '<', $startDate)->count();
        
        if ($previousPeriod > 0) {
            return round((($currentPeriod - $previousPeriod) / $previousPeriod) * 100, 2);
        }
        
        return 0;
    }

    private function identifySeasonalPatterns($startDate)
    {
        return Order::select(
                DB::raw('DAYOFWEEK(created_at) as day_of_week'),
                DB::raw('COUNT(*) as order_count')
            )
            ->where('created_at', '>=', $startDate)
            ->groupBy('day_of_week')
            ->orderBy('day_of_week')
            ->get();
    }

    private function generateDeliveryHeatmap($startDate)
    {
        return Order::select('delivery_lat', 'delivery_lng')
            ->where('created_at', '>=', $startDate)
            ->where('status', 'delivered')
            ->whereNotNull('delivery_lat')
            ->whereNotNull('delivery_lng')
            ->get();
    }

    private function analyzeCoverageArea($startDate)
    {
        $coordinates = Order::select('delivery_lat', 'delivery_lng')
            ->where('created_at', '>=', $startDate)
            ->whereNotNull('delivery_lat')
            ->whereNotNull('delivery_lng')
            ->get();

        if ($coordinates->isEmpty()) {
            return null;
        }

        return [
            'center_lat' => $coordinates->avg('delivery_lat'),
            'center_lng' => $coordinates->avg('delivery_lng'),
            'max_lat' => $coordinates->max('delivery_lat'),
            'min_lat' => $coordinates->min('delivery_lat'),
            'max_lng' => $coordinates->max('delivery_lng'),
            'min_lng' => $coordinates->min('delivery_lng'),
            'coverage_radius' => $this->calculateCoverageRadius($coordinates)
        ];
    }

    private function calculateCoverageRadius($coordinates)
    {
        $centerLat = $coordinates->avg('delivery_lat');
        $centerLng = $coordinates->avg('delivery_lng');
        
        $maxDistance = 0;
        foreach ($coordinates as $coord) {
            $distance = $this->calculateDistance(
                $centerLat, $centerLng,
                $coord->delivery_lat, $coord->delivery_lng
            );
            $maxDistance = max($maxDistance, $distance);
        }
        
        return round($maxDistance, 2);
    }

    private function calculateDistance($lat1, $lng1, $lat2, $lng2)
    {
        $earthRadius = 6371; // Earth's radius in kilometers

        $dLat = deg2rad($lat2 - $lat1);
        $dLng = deg2rad($lng2 - $lng1);

        $a = sin($dLat/2) * sin($dLat/2) + cos(deg2rad($lat1)) * cos(deg2rad($lat2)) * sin($dLng/2) * sin($dLng/2);
        $c = 2 * atan2(sqrt($a), sqrt(1-$a));

        return $earthRadius * $c;
    }
}
