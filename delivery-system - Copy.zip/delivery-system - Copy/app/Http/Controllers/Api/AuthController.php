<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\OtpCode;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\RateLimiter;
use Illuminate\Support\Facades\Cache;
use Illuminate\Validation\Rule;

class AuthController extends Controller
{
    public function sendOTP(Request $request)
    {
        // Rate limiting: 5 OTP requests per phone number per hour
        $phone = $this->sanitizePhone($request->phone);
        $rateLimitKey = 'otp_requests:' . $phone;
        
        if (RateLimiter::tooManyAttempts($rateLimitKey, 5)) {
            $seconds = RateLimiter::availableIn($rateLimitKey);
            return response()->json([
                'success' => false,
                'message' => 'Too many OTP requests. Please try again in ' . ceil($seconds / 60) . ' minutes.',
                'retry_after' => $seconds
            ], 429);
        }

        $validator = Validator::make($request->all(), [
            'phone' => 'required|string|min:10|max:15|regex:/^\+?[1-9]\d{1,14}$/',
            'type' => 'required|in:sms,whatsapp,telegram,email'
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => __('messages.validation_error'),
                'errors' => $validator->errors()
            ], 422);
        }

        // Increment rate limit counter
        RateLimiter::hit($rateLimitKey, 3600); // 1 hour window

        try {
            $otpCode = OtpCode::createForPhone($request->phone, $request->type);

            // Here you would integrate with SMS/WhatsApp/Email services
            // For now, we'll just return success
            $this->sendOTPViaService($request->phone, $otpCode->code, $request->type);

            return response()->json([
                'success' => true,
                'message' => __('messages.otp_sent'),
                'data' => [
                    'phone' => $request->phone,
                    'type' => $request->type,
                    'expires_at' => $otpCode->expires_at
                ]
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => __('messages.error'),
                'error' => $e->getMessage()
            ], 500);
        }
    }

    public function verifyOTP(Request $request)
    {
        // Rate limiting: 10 OTP verification attempts per phone number per hour
        $phone = $this->sanitizePhone($request->phone);
        $rateLimitKey = 'otp_verify:' . $phone;
        
        if (RateLimiter::tooManyAttempts($rateLimitKey, 10)) {
            $seconds = RateLimiter::availableIn($rateLimitKey);
            return response()->json([
                'success' => false,
                'message' => 'Too many verification attempts. Please try again in ' . ceil($seconds / 60) . ' minutes.',
                'retry_after' => $seconds
            ], 429);
        }

        $validator = Validator::make($request->all(), [
            'phone' => 'required|string|regex:/^\+?[1-9]\d{1,14}$/',
            'otp' => 'required|string|size:4|regex:/^[0-9]{4}$/'
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => __('messages.validation_error'),
                'errors' => $validator->errors()
            ], 422);
        }

        // Increment rate limit counter
        RateLimiter::hit($rateLimitKey, 3600); // 1 hour window

        $otpRecord = OtpCode::where('phone', $request->phone)
            ->where('code', $request->otp)
            ->where('is_used', false)
            ->where('expires_at', '>', now())
            ->first();

        if (!$otpRecord) {
            $debugInfo = [];
            if (app()->environment(['local', 'testing'])) {
                // Debug information for development
                $anyOtpForPhone = OtpCode::where('phone', $request->phone)->latest()->first();
                $debugInfo = [
                    'phone_searched' => $request->phone,
                    'otp_searched' => $request->otp,
                    'latest_otp_for_phone' => $anyOtpForPhone ? [
                        'code' => $anyOtpForPhone->code,
                        'expires_at' => $anyOtpForPhone->expires_at,
                        'is_used' => $anyOtpForPhone->is_used,
                        'is_expired' => $anyOtpForPhone->isExpired()
                    ] : 'No OTP found for this phone'
                ];
            }

            return response()->json([
                'success' => false,
                'message' => __('messages.otp_invalid'),
                'debug' => $debugInfo
            ], 400);
        }

        $otpRecord->markAsUsed();

        $user = User::where('phone', $request->phone)->first();

        if (!$user) {
            return response()->json([
                'success' => true,
                'message' => __('messages.otp_sent'),
                'data' => [
                    'requires_registration' => true,
                    'phone' => $request->phone
                ]
            ]);
        }

        $token = $user->createToken('auth_token')->plainTextToken;

        return response()->json([
            'success' => true,
            'message' => __('messages.login_success'),
            'data' => [
                'user' => $user,
                'token' => $token,
                'requires_registration' => false
            ]
        ]);
    }

    public function register(Request $request)
    {
        $userType = $request->input('user_type');
        $rules = [
            'phone' => 'required|string|unique:users',
            'otp' => 'required|string|size:4',
            'full_name' => 'required|string|max:255',
            'user_type' => 'required|in:regular,driver,merchant,temp',
            'email' => 'nullable|email|unique:users',
            'profile_image' => 'nullable|string',
            'home_lat' => 'required|numeric|between:-90,90',
            'home_lng' => 'required|numeric|between:-180,180',
            'home_address' => 'required|string',
            'is_freelance' => 'boolean'
        ];
        if ($userType === 'driver') {
            $rules['id_card_image'] = 'required|string';
            $rules['vin_number'] = 'required|string';
        }
        if ($userType === 'merchant') {
            $rules['id_card_image'] = 'required|string';
            $rules['business_type'] = 'required|string';
            $rules['bank_card'] = 'required|string';
            $rules['working_hours'] = 'required|array';
        }
        if ($userType === 'temp') {
            $rules['payment_method'] = 'required|in:cash,card,zain_cash';
        }
        $validator = Validator::make($request->all(), $rules);
        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => __('messages.validation_error'),
                'errors' => $validator->errors()
            ], 422);
        }

        // Verify OTP before registration
        $otpRecord = OtpCode::where('phone', $request->phone)
            ->where('code', $request->otp)
            ->where('is_used', false)
            ->where('expires_at', '>', now())
            ->first();

        if (!$otpRecord) {
            return response()->json([
                'success' => false,
                'message' => __('messages.otp_invalid')
            ], 400);
        }

        try {
            // Mark OTP as used
            $otpRecord->markAsUsed();
            
            $userData = $request->all();
            unset($userData['otp']); // Remove OTP from user data
            $userData['is_active'] = $userType === 'temp' ? true : false; // temp users are active by default
            $user = User::create($userData);
            if ($userType === 'temp') {
                // Generate internal OTP for delivery only
                $otpCode = rand(1000, 9999);
                $user->internal_otp = $otpCode;
                $user->save();
                return response()->json([
                    'success' => true,
                    'message' => __('messages.otp_sent'),
                    'data' => [
                        'user' => $user,
                        'delivery_otp' => $otpCode
                    ]
                ], 201);
            }
            $token = $user->createToken('auth_token')->plainTextToken;
            return response()->json([
                'success' => true,
                'message' => __('messages.success'),
                'data' => [
                    'user' => $user,
                    'token' => $token
                ]
            ], 201);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => __('messages.error'),
                'error' => $e->getMessage()
            ], 500);
        }
    }

    public function logout(Request $request)
    {
        try {
            $request->user()->currentAccessToken()->delete();

            return response()->json([
                'success' => true,
                'message' => __('messages.logout_success')
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => __('messages.error'),
                'error' => $e->getMessage()
            ], 500);
        }
    }

    public function me(Request $request)
    {
        return response()->json([
            'success' => true,
            'data' => [
                'user' => $request->user()
            ]
        ]);
    }

    public function refreshToken(Request $request)
    {
        try {
            $user = $request->user();
            $user->currentAccessToken()->delete();

            $token = $user->createToken('auth_token')->plainTextToken;

            return response()->json([
                'success' => true,
                'message' => __('messages.success'),
                'data' => [
                    'token' => $token
                ]
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => __('messages.error'),
                'error' => $e->getMessage()
            ], 500);
        }
    }

    private function sendOTPViaService($phone, $code, $type)
    {
        $notificationService = app(\App\Services\NotificationService::class);
        $otpMessage = "Your OTP code is: {$code}";
        switch ($type) {
            case 'sms':
                $notificationService->sendSMS($phone, $otpMessage);
                break;
            case 'whatsapp':
                $notificationService->sendWhatsAppMessage($phone, $otpMessage);
                break;
            case 'telegram':
                $notificationService->sendTelegramMessage($phone, $otpMessage);
                break;
            case 'email':
                $notificationService->sendEmail($phone, 'Your OTP Code', $otpMessage);
                break;
        }
        Log::info("OTP for {$phone}: {$code}");
    }

    // Test OTP endpoint removed for production security

/**
 * Sanitize phone number input
 */
private function sanitizePhone($phone)
{
    // Remove all non-digit characters except +
    $sanitized = preg_replace('/[^\d+]/', '', $phone);
    
    // Ensure it starts with + if it doesn't already
    if (!str_starts_with($sanitized, '+')) {
        $sanitized = '+' . $sanitized;
    }
    
    return $sanitized;
}

/**
 * Sanitize string input to prevent XSS
 */
private function sanitizeString($input)
{
    return htmlspecialchars(strip_tags(trim($input)), ENT_QUOTES, 'UTF-8');
}

/**
 * Validate and sanitize user input for registration
 */
private function sanitizeUserInput($data)
{
    $sanitized = [];
    
    foreach ($data as $key => $value) {
        if (is_string($value)) {
            switch ($key) {
                case 'phone':
                    $sanitized[$key] = $this->sanitizePhone($value);
                    break;
                case 'email':
                    $sanitized[$key] = filter_var(trim($value), FILTER_SANITIZE_EMAIL);
                    break;
                case 'full_name':
                case 'home_address':
                case 'business_type':
                    $sanitized[$key] = $this->sanitizeString($value);
                    break;
                default:
                    $sanitized[$key] = $value;
            }
        } else {
            $sanitized[$key] = $value;
        }
    }
    
    return $sanitized;
}
}

