<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Log;

class HealthController extends Controller
{
    /**
     * Basic health check endpoint
     */
    public function health(): JsonResponse
    {
        try {
            $checks = [
                'database' => $this->checkDatabase(),
                'cache' => $this->checkCache(),
                'storage' => $this->checkStorage(),
                'queue' => $this->checkQueue(),
            ];

            $allHealthy = collect($checks)->every(fn($check) => $check['status'] === 'ok');

            return response()->json([
                'status' => $allHealthy ? 'healthy' : 'unhealthy',
                'timestamp' => now()->toISOString(),
                'checks' => $checks,
                'version' => config('app.version', '1.0.0'),
                'environment' => config('app.env')
            ], $allHealthy ? 200 : 503);

        } catch (\Exception $e) {
            Log::error('Health check failed', ['error' => $e->getMessage()]);
            
            return response()->json([
                'status' => 'unhealthy',
                'timestamp' => now()->toISOString(),
                'error' => 'Health check system failure'
            ], 503);
        }
    }

    /**
     * Detailed system metrics
     */
    public function metrics(): JsonResponse
    {
        try {
            $metrics = [
                'system' => [
                    'uptime' => $this->getUptime(),
                    'memory_usage' => $this->getMemoryUsage(),
                    'php_version' => PHP_VERSION,
                    'laravel_version' => app()->version()
                ],
                'database' => [
                    'connections' => $this->getDatabaseConnections(),
                    'query_count' => $this->getQueryCount(),
                    'slow_queries' => $this->getSlowQueries()
                ],
                'orders' => [
                    'total_today' => $this->getTodayOrderCount(),
                    'pending_orders' => $this->getPendingOrderCount(),
                    'active_deliveries' => $this->getActiveDeliveryCount()
                ],
                'users' => [
                    'total_users' => $this->getTotalUserCount(),
                    'active_drivers' => $this->getActiveDriverCount(),
                    'active_merchants' => $this->getActiveMerchantCount()
                ],
                'performance' => [
                    'avg_response_time' => $this->getAverageResponseTime(),
                    'error_rate' => $this->getErrorRate(),
                    'cache_hit_rate' => $this->getCacheHitRate()
                ]
            ];

            return response()->json([
                'success' => true,
                'timestamp' => now()->toISOString(),
                'metrics' => $metrics
            ]);

        } catch (\Exception $e) {
            Log::error('Metrics collection failed', ['error' => $e->getMessage()]);
            
            return response()->json([
                'success' => false,
                'error' => 'Failed to collect metrics'
            ], 500);
        }
    }

    /**
     * Check database connectivity
     */
    private function checkDatabase(): array
    {
        try {
            $start = microtime(true);
            DB::select('SELECT 1');
            $responseTime = round((microtime(true) - $start) * 1000, 2);

            return [
                'status' => 'ok',
                'response_time_ms' => $responseTime,
                'message' => 'Database connection successful'
            ];
        } catch (\Exception $e) {
            return [
                'status' => 'error',
                'message' => 'Database connection failed: ' . $e->getMessage()
            ];
        }
    }

    /**
     * Check cache system
     */
    private function checkCache(): array
    {
        try {
            $testKey = 'health_check_' . time();
            $testValue = 'test_value';
            
            Cache::put($testKey, $testValue, 60);
            $retrieved = Cache::get($testKey);
            Cache::forget($testKey);

            if ($retrieved === $testValue) {
                return [
                    'status' => 'ok',
                    'message' => 'Cache system working'
                ];
            } else {
                return [
                    'status' => 'error',
                    'message' => 'Cache read/write test failed'
                ];
            }
        } catch (\Exception $e) {
            return [
                'status' => 'error',
                'message' => 'Cache system error: ' . $e->getMessage()
            ];
        }
    }

    /**
     * Check storage system
     */
    private function checkStorage(): array
    {
        try {
            $testFile = storage_path('logs/health_check_test.txt');
            file_put_contents($testFile, 'test');
            $content = file_get_contents($testFile);
            unlink($testFile);

            if ($content === 'test') {
                return [
                    'status' => 'ok',
                    'message' => 'Storage system working'
                ];
            } else {
                return [
                    'status' => 'error',
                    'message' => 'Storage read/write test failed'
                ];
            }
        } catch (\Exception $e) {
            return [
                'status' => 'error',
                'message' => 'Storage system error: ' . $e->getMessage()
            ];
        }
    }

    /**
     * Check queue system
     */
    private function checkQueue(): array
    {
        try {
            // Basic queue connection check
            $queueConnection = config('queue.default');
            
            return [
                'status' => 'ok',
                'connection' => $queueConnection,
                'message' => 'Queue system accessible'
            ];
        } catch (\Exception $e) {
            return [
                'status' => 'error',
                'message' => 'Queue system error: ' . $e->getMessage()
            ];
        }
    }

    /**
     * Get system uptime
     */
    private function getUptime(): string
    {
        if (function_exists('sys_getloadavg')) {
            $uptime = shell_exec('uptime');
            return trim($uptime) ?: 'Unknown';
        }
        return 'Not available on this system';
    }

    /**
     * Get memory usage
     */
    private function getMemoryUsage(): array
    {
        return [
            'current_mb' => round(memory_get_usage(true) / 1024 / 1024, 2),
            'peak_mb' => round(memory_get_peak_usage(true) / 1024 / 1024, 2),
            'limit' => ini_get('memory_limit')
        ];
    }

    /**
     * Get database connection count
     */
    private function getDatabaseConnections(): int
    {
        try {
            $result = DB::select('SHOW STATUS LIKE "Threads_connected"');
            return $result[0]->Value ?? 0;
        } catch (\Exception $e) {
            return 0;
        }
    }

    /**
     * Get query count (simplified)
     */
    private function getQueryCount(): int
    {
        return DB::getQueryLog() ? count(DB::getQueryLog()) : 0;
    }

    /**
     * Get slow queries count
     */
    private function getSlowQueries(): int
    {
        try {
            $result = DB::select('SHOW STATUS LIKE "Slow_queries"');
            return $result[0]->Value ?? 0;
        } catch (\Exception $e) {
            return 0;
        }
    }

    /**
     * Get today's order count
     */
    private function getTodayOrderCount(): int
    {
        return DB::table('orders')
            ->whereDate('created_at', today())
            ->count();
    }

    /**
     * Get pending order count
     */
    private function getPendingOrderCount(): int
    {
        return DB::table('orders')
            ->where('status', 'pending')
            ->count();
    }

    /**
     * Get active delivery count
     */
    private function getActiveDeliveryCount(): int
    {
        return DB::table('orders')
            ->whereIn('status', ['out_for_delivery', 'ready_for_delivery'])
            ->count();
    }

    /**
     * Get total user count
     */
    private function getTotalUserCount(): int
    {
        return DB::table('users')->count();
    }

    /**
     * Get active driver count
     */
    private function getActiveDriverCount(): int
    {
        return DB::table('users')
            ->where('user_type', 'driver')
            ->where('is_active', true)
            ->count();
    }

    /**
     * Get active merchant count
     */
    private function getActiveMerchantCount(): int
    {
        return DB::table('users')
            ->where('user_type', 'merchant')
            ->where('is_active', true)
            ->count();
    }

    /**
     * Get average response time (simplified)
     */
    private function getAverageResponseTime(): string
    {
        return 'Not implemented - requires APM integration';
    }

    /**
     * Get error rate (simplified)
     */
    private function getErrorRate(): string
    {
        return 'Not implemented - requires error tracking';
    }

    /**
     * Get cache hit rate (simplified)
     */
    private function getCacheHitRate(): string
    {
        return 'Not implemented - requires cache analytics';
    }
}
