<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Services\MapsService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class MapsController extends Controller
{
    private $mapsService;

    public function __construct(MapsService $mapsService)
    {
        $this->mapsService = $mapsService;
    }

    /**
     * Calculate route between two points
     */
    public function calculateRoute(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'origin_lat' => 'required|numeric|between:-90,90',
            'origin_lng' => 'required|numeric|between:-180,180',
            'dest_lat' => 'required|numeric|between:-90,90',
            'dest_lng' => 'required|numeric|between:-180,180',
            'provider' => 'nullable|in:google,mapbox'
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Validation error',
                'errors' => $validator->errors()
            ], 422);
        }

        try {
            $route = $this->mapsService->calculateRoute(
                $request->origin_lat,
                $request->origin_lng,
                $request->dest_lat,
                $request->dest_lng,
                $request->provider ?? 'google'
            );

            return response()->json([
                'success' => true,
                'data' => $route
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to calculate route',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Geocode address to coordinates
     */
    public function geocodeAddress(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'address' => 'required|string|max:255',
            'provider' => 'nullable|in:google,mapbox'
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Validation error',
                'errors' => $validator->errors()
            ], 422);
        }

        try {
            $result = $this->mapsService->geocodeAddress(
                $request->address,
                $request->provider ?? 'google'
            );

            if ($result) {
                return response()->json([
                    'success' => true,
                    'data' => $result
                ]);
            } else {
                return response()->json([
                    'success' => false,
                    'message' => 'Address not found'
                ], 404);
            }

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Geocoding failed',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Reverse geocode coordinates to address
     */
    public function reverseGeocode(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'lat' => 'required|numeric|between:-90,90',
            'lng' => 'required|numeric|between:-180,180',
            'provider' => 'nullable|in:google,mapbox'
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Validation error',
                'errors' => $validator->errors()
            ], 422);
        }

        try {
            $result = $this->mapsService->reverseGeocode(
                $request->lat,
                $request->lng,
                $request->provider ?? 'google'
            );

            if ($result) {
                return response()->json([
                    'success' => true,
                    'data' => $result
                ]);
            } else {
                return response()->json([
                    'success' => false,
                    'message' => 'Location not found'
                ], 404);
            }

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Reverse geocoding failed',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Find nearby places
     */
    public function findNearbyPlaces(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'lat' => 'required|numeric|between:-90,90',
            'lng' => 'required|numeric|between:-180,180',
            'type' => 'nullable|string|in:restaurant,gas_station,hospital,pharmacy,bank,atm',
            'radius' => 'nullable|integer|min:100|max:50000'
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Validation error',
                'errors' => $validator->errors()
            ], 422);
        }

        try {
            $places = $this->mapsService->findNearbyPlaces(
                $request->lat,
                $request->lng,
                $request->type ?? 'restaurant',
                $request->radius ?? 5000
            );

            return response()->json([
                'success' => true,
                'data' => $places,
                'count' => count($places)
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to find nearby places',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Get optimized route for multiple waypoints
     */
    public function getOptimizedRoute(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'waypoints' => 'required|array|min:2',
            'waypoints.*.lat' => 'required|numeric|between:-90,90',
            'waypoints.*.lng' => 'required|numeric|between:-180,180',
            'waypoints.*.name' => 'nullable|string',
            'provider' => 'nullable|in:google,mapbox'
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Validation error',
                'errors' => $validator->errors()
            ], 422);
        }

        try {
            $route = $this->mapsService->getOptimizedRoute(
                $request->waypoints,
                $request->provider ?? 'google'
            );

            return response()->json([
                'success' => true,
                'data' => $route
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to optimize route',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Calculate delivery zones
     */
    public function calculateDeliveryZones(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'center_lat' => 'required|numeric|between:-90,90',
            'center_lng' => 'required|numeric|between:-180,180',
            'zones' => 'nullable|array',
            'zones.*' => 'integer|min:1|max:50'
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Validation error',
                'errors' => $validator->errors()
            ], 422);
        }

        try {
            $zones = $this->mapsService->calculateDeliveryZones(
                $request->center_lat,
                $request->center_lng,
                $request->zones ?? [5, 10, 15]
            );

            return response()->json([
                'success' => true,
                'data' => $zones
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to calculate delivery zones',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Get delivery estimate for specific location
     */
    public function getDeliveryEstimate(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'merchant_lat' => 'required|numeric|between:-90,90',
            'merchant_lng' => 'required|numeric|between:-180,180',
            'delivery_lat' => 'required|numeric|between:-90,90',
            'delivery_lng' => 'required|numeric|between:-180,180',
            'preparation_time' => 'nullable|integer|min:0|max:120'
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Validation error',
                'errors' => $validator->errors()
            ], 422);
        }

        try {
            $route = $this->mapsService->calculateRoute(
                $request->merchant_lat,
                $request->merchant_lng,
                $request->delivery_lat,
                $request->delivery_lng
            );

            $preparationTime = $request->preparation_time ?? 15;
            $totalTime = $preparationTime + $route['duration_minutes'];
            
            // Calculate delivery fee based on distance
            $baseFee = config('app.base_delivery_fee', 5);
            $perKmFee = config('app.per_km_delivery_fee', 1);
            $deliveryFee = $baseFee + ($route['distance_km'] * $perKmFee);

            $estimate = [
                'route' => $route,
                'preparation_time_minutes' => $preparationTime,
                'total_time_minutes' => $totalTime,
                'delivery_fee' => round($deliveryFee, 2),
                'estimated_arrival' => now()->addMinutes($totalTime)->toISOString(),
                'is_deliverable' => $route['distance_km'] <= config('app.max_delivery_distance', 25)
            ];

            return response()->json([
                'success' => true,
                'data' => $estimate
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to calculate delivery estimate',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Track driver location (for real-time tracking)
     */
    public function trackDriver(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'driver_id' => 'required|exists:users,id',
            'lat' => 'required|numeric|between:-90,90',
            'lng' => 'required|numeric|between:-180,180',
            'heading' => 'nullable|numeric|between:0,360',
            'speed' => 'nullable|numeric|min:0'
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Validation error',
                'errors' => $validator->errors()
            ], 422);
        }

        try {
            $user = $request->user();
            
            // Only allow drivers to update their own location or admins
            if (!$user->isAdmin() && $user->id != $request->driver_id) {
                return response()->json([
                    'success' => false,
                    'message' => 'Unauthorized to update this driver location'
                ], 403);
            }

            // Store location in cache for real-time tracking
            $locationData = [
                'lat' => $request->lat,
                'lng' => $request->lng,
                'heading' => $request->heading,
                'speed' => $request->speed,
                'updated_at' => now()->toISOString()
            ];

            cache()->put("driver_location_{$request->driver_id}", $locationData, 300); // 5 minutes

            // Update user's last known location
            $driver = \App\Models\User::find($request->driver_id);
            $driver->update([
                'last_lat' => $request->lat,
                'last_lng' => $request->lng,
                'last_location_update' => now()
            ]);

            // Broadcast location update to relevant orders
            $this->broadcastDriverLocation($request->driver_id, $locationData);

            return response()->json([
                'success' => true,
                'message' => 'Location updated successfully'
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to update location',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Get driver's current location
     */
    public function getDriverLocation(Request $request, $driverId)
    {
        try {
            $user = $request->user();
            
            // Check if user can access this driver's location
            if (!$user->isAdmin() && !$this->canAccessDriverLocation($user, $driverId)) {
                return response()->json([
                    'success' => false,
                    'message' => 'Unauthorized to access driver location'
                ], 403);
            }

            $location = cache()->get("driver_location_{$driverId}");
            
            if ($location) {
                return response()->json([
                    'success' => true,
                    'data' => $location
                ]);
            } else {
                return response()->json([
                    'success' => false,
                    'message' => 'Driver location not available'
                ], 404);
            }

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to get driver location',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Get ETA for active delivery
     */
    public function getDeliveryETA(Request $request, $orderId)
    {
        try {
            $order = \App\Models\Order::with(['driver'])->findOrFail($orderId);
            
            // Check if user can access this order
            if (!$request->user()->isAdmin() && 
                $request->user()->id !== $order->customer_id && 
                $request->user()->id !== $order->driver_id) {
                return response()->json([
                    'success' => false,
                    'message' => 'Unauthorized to access this order'
                ], 403);
            }

            if (!$order->driver || !in_array($order->status, ['accepted', 'preparing', 'out_for_delivery'])) {
                return response()->json([
                    'success' => false,
                    'message' => 'Order is not in delivery phase'
                ], 400);
            }

            $driverLocation = cache()->get("driver_location_{$order->driver_id}");
            
            if (!$driverLocation) {
                return response()->json([
                    'success' => false,
                    'message' => 'Driver location not available'
                ], 404);
            }

            $route = $this->mapsService->calculateRoute(
                $driverLocation['lat'],
                $driverLocation['lng'],
                $order->delivery_lat,
                $order->delivery_lng
            );

            $eta = [
                'current_driver_location' => $driverLocation,
                'delivery_location' => [
                    'lat' => $order->delivery_lat,
                    'lng' => $order->delivery_lng,
                    'address' => $order->delivery_address
                ],
                'route' => $route,
                'estimated_arrival' => now()->addMinutes($route['duration_minutes'])->toISOString(),
                'order_status' => $order->status
            ];

            return response()->json([
                'success' => true,
                'data' => $eta
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to calculate ETA',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Private helper methods
     */
    private function broadcastDriverLocation($driverId, $locationData)
    {
        // Get active orders for this driver
        $activeOrders = \App\Models\Order::where('driver_id', $driverId)
            ->whereIn('status', ['accepted', 'preparing', 'out_for_delivery'])
            ->get();

        foreach ($activeOrders as $order) {
            // Broadcast to customer via WebSocket/Pusher
            broadcast(new \App\Events\DriverLocationUpdated($order->id, $locationData));
        }
    }

    private function canAccessDriverLocation($user, $driverId)
    {
        // Customer can access driver location if they have an active order with that driver
        return \App\Models\Order::where('customer_id', $user->id)
            ->where('driver_id', $driverId)
            ->whereIn('status', ['accepted', 'preparing', 'out_for_delivery'])
            ->exists();
    }
}
