<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\WalletTransaction;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;

class WalletController extends Controller
{
    /**
     * Get wallet balance
     */
    public function getBalance(): JsonResponse
    {
        try {
            $user = auth()->user();

            $balance = WalletTransaction::where('user_id', $user->id)
                ->sum(DB::raw('CASE WHEN type = "credit" THEN amount ELSE -amount END'));

            return response()->json([
                'success' => true,
                'message' => __('messages.balance_retrieved_successfully'),
                'data' => [
                    'balance' => $balance,
                    'currency' => 'USD'
                ]
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => __('messages.failed_to_retrieve_balance'),
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Top up wallet
     */
    public function topup(Request $request): JsonResponse
    {
        try {
            $validator = Validator::make($request->all(), [
                'amount' => 'required|numeric|min:1|max:10000',
                'payment_method' => 'required|in:card,stripe,paypal,cash',
                'reference' => 'nullable|string|max:255'
            ]);

            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'message' => __('messages.validation_failed'),
                    'errors' => $validator->errors()
                ], 422);
            }

            $user = auth()->user();

            // Create wallet transaction
            $transaction = WalletTransaction::create([
                'user_id' => $user->id,
                'type' => 'credit',
                'amount' => $request->amount,
                'payment_method' => $request->payment_method,
                'reference' => $request->reference ?? 'Top-up',
                'status' => 'completed',
                'description' => 'Wallet top-up'
            ]);

            // Get updated balance
            $balance = WalletTransaction::where('user_id', $user->id)
                ->sum(DB::raw('CASE WHEN type = "credit" THEN amount ELSE -amount END'));

            return response()->json([
                'success' => true,
                'message' => __('messages.wallet_topped_up_successfully'),
                'data' => [
                    'transaction' => $transaction,
                    'new_balance' => $balance
                ]
            ], 201);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => __('messages.failed_to_top_up_wallet'),
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Get wallet transactions
     */
    public function getTransactions(Request $request): JsonResponse
    {
        try {
            $user = auth()->user();

            $query = WalletTransaction::where('user_id', $user->id)
                ->orderBy('created_at', 'desc');

            // Apply filters
            if ($request->has('type')) {
                $query->where('type', $request->type);
            }

            if ($request->has('status')) {
                $query->where('status', $request->status);
            }

            if ($request->has('date_from')) {
                $query->whereDate('created_at', '>=', $request->date_from);
            }

            if ($request->has('date_to')) {
                $query->whereDate('created_at', '<=', $request->date_to);
            }

            $transactions = $query->paginate($request->get('per_page', 15));

            return response()->json([
                'success' => true,
                'message' => __('messages.transactions_retrieved_successfully'),
                'data' => $transactions
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => __('messages.failed_to_retrieve_transactions'),
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Withdraw from wallet
     */
    public function withdraw(Request $request): JsonResponse
    {
        try {
            $validator = Validator::make($request->all(), [
                'amount' => 'required|numeric|min:1',
                'bank_account' => 'required|string|max:255',
                'reason' => 'nullable|string|max:500'
            ]);

            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'message' => __('messages.validation_failed'),
                    'errors' => $validator->errors()
                ], 422);
            }

            $user = auth()->user();

            // Check current balance
            $currentBalance = WalletTransaction::where('user_id', $user->id)
                ->sum(DB::raw('CASE WHEN type = "credit" THEN amount ELSE -amount END'));

            if ($currentBalance < $request->amount) {
                return response()->json([
                    'success' => false,
                    'message' => __('messages.insufficient_balance')
                ], 400);
            }

            // Create withdrawal transaction
            $transaction = WalletTransaction::create([
                'user_id' => $user->id,
                'type' => 'debit',
                'amount' => $request->amount,
                'payment_method' => 'bank_transfer',
                'reference' => 'Withdrawal',
                'status' => 'pending',
                'description' => $request->reason ?? 'Wallet withdrawal',
                'metadata' => [
                    'bank_account' => $request->bank_account
                ]
            ]);

            return response()->json([
                'success' => true,
                'message' => __('messages.withdrawal_request_submitted'),
                'data' => $transaction
            ], 201);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => __('messages.failed_to_process_withdrawal'),
                'error' => $e->getMessage()
            ], 500);
        }
    }
}
