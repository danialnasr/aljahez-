<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Order;
use App\Models\User;
use App\Models\Product;
use App\Models\WalletTransaction;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class ReportsController extends Controller
{
    /**
     * Generate comprehensive financial report
     */
    public function financialReport(Request $request)
    {
        try {
            $user = $request->user();
            
            if (!$user->isAdmin() && !$user->isMerchant()) {
                return response()->json([
                    'success' => false,
                    'message' => 'Unauthorized access to financial reports'
                ], 403);
            }

            $startDate = Carbon::parse($request->input('start_date', now()->subMonth()));
            $endDate = Carbon::parse($request->input('end_date', now()));

            $report = [
                'period' => [
                    'start_date' => $startDate->toDateString(),
                    'end_date' => $endDate->toDateString(),
                    'days' => $startDate->diffInDays($endDate)
                ],
                'revenue' => $this->generateRevenueReport($startDate, $endDate, $user),
                'expenses' => $this->generateExpenseReport($startDate, $endDate, $user),
                'profit' => $this->generateProfitReport($startDate, $endDate, $user),
                'transactions' => $this->generateTransactionReport($startDate, $endDate, $user),
                'forecasting' => $this->generateForecastReport($startDate, $endDate)
            ];

            return response()->json([
                'success' => true,
                'data' => $report,
                'generated_at' => now()->toISOString()
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to generate financial report',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Generate operational performance report
     */
    public function operationalReport(Request $request)
    {
        try {
            $user = $request->user();
            
            if (!$user->isAdmin()) {
                return response()->json([
                    'success' => false,
                    'message' => 'Admin access required'
                ], 403);
            }

            $startDate = Carbon::parse($request->input('start_date', now()->subMonth()));
            $endDate = Carbon::parse($request->input('end_date', now()));

            $report = [
                'delivery_performance' => $this->generateDeliveryPerformanceReport($startDate, $endDate),
                'driver_efficiency' => $this->generateDriverEfficiencyReport($startDate, $endDate),
                'merchant_performance' => $this->generateMerchantPerformanceReport($startDate, $endDate),
                'customer_satisfaction' => $this->generateCustomerSatisfactionReport($startDate, $endDate),
                'operational_metrics' => $this->generateOperationalMetrics($startDate, $endDate)
            ];

            return response()->json([
                'success' => true,
                'data' => $report,
                'period' => $startDate->toDateString() . ' to ' . $endDate->toDateString()
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to generate operational report',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Generate customer analytics report
     */
    public function customerAnalyticsReport(Request $request)
    {
        try {
            $startDate = Carbon::parse($request->input('start_date', now()->subMonth()));
            $endDate = Carbon::parse($request->input('end_date', now()));

            $report = [
                'customer_acquisition' => $this->generateCustomerAcquisitionReport($startDate, $endDate),
                'customer_retention' => $this->generateCustomerRetentionReport($startDate, $endDate),
                'customer_lifetime_value' => $this->generateCLVReport($startDate, $endDate),
                'customer_segmentation' => $this->generateCustomerSegmentationReport($startDate, $endDate),
                'churn_analysis' => $this->generateChurnAnalysisReport($startDate, $endDate)
            ];

            return response()->json([
                'success' => true,
                'data' => $report
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to generate customer analytics',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Export report to CSV/Excel format
     */
    public function exportReport(Request $request)
    {
        try {
            $reportType = $request->input('type', 'financial');
            $format = $request->input('format', 'csv');
            $startDate = Carbon::parse($request->input('start_date', now()->subMonth()));
            $endDate = Carbon::parse($request->input('end_date', now()));

            switch ($reportType) {
                case 'financial':
                    $data = $this->prepareFinancialExportData($startDate, $endDate);
                    break;
                case 'operational':
                    $data = $this->prepareOperationalExportData($startDate, $endDate);
                    break;
                case 'customer':
                    $data = $this->prepareCustomerExportData($startDate, $endDate);
                    break;
                default:
                    throw new \Exception('Invalid report type');
            }

            $filename = $reportType . '_report_' . $startDate->format('Y-m-d') . '_to_' . $endDate->format('Y-m-d') . '.' . $format;

            if ($format === 'csv') {
                return $this->generateCSVResponse($data, $filename);
            } else {
                return $this->generateExcelResponse($data, $filename);
            }

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to export report',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    // Private helper methods for report generation

    private function generateRevenueReport($startDate, $endDate, $user)
    {
        $query = Order::whereBetween('created_at', [$startDate, $endDate])
            ->where('status', 'delivered');

        if ($user->isMerchant()) {
            $query->whereHas('items', function($q) use ($user) {
                $q->where('merchant_id', $user->id);
            });
        }

        $totalRevenue = $query->sum('total');
        $orderCount = $query->count();
        $averageOrderValue = $orderCount > 0 ? $totalRevenue / $orderCount : 0;

        $dailyRevenue = $query->select(
                DB::raw('DATE(created_at) as date'),
                DB::raw('SUM(total) as revenue'),
                DB::raw('COUNT(*) as orders')
            )
            ->groupBy('date')
            ->orderBy('date')
            ->get();

        return [
            'total_revenue' => round($totalRevenue, 2),
            'order_count' => $orderCount,
            'average_order_value' => round($averageOrderValue, 2),
            'daily_breakdown' => $dailyRevenue,
            'growth_rate' => $this->calculateRevenueGrowthRate($startDate, $endDate, $user)
        ];
    }

    private function generateExpenseReport($startDate, $endDate, $user)
    {
        // Calculate various expense categories
        $deliveryFees = Order::whereBetween('created_at', [$startDate, $endDate])
            ->where('status', 'delivered')
            ->sum('delivery_fee');

        $commissionPaid = Order::whereBetween('created_at', [$startDate, $endDate])
            ->where('status', 'delivered')
            ->get()
            ->sum(function($order) {
                return $order->total * config('app.commission_rate', 0.15);
            });

        $walletTransactions = WalletTransaction::whereBetween('created_at', [$startDate, $endDate])
            ->where('type', 'debit')
            ->sum('amount');

        return [
            'delivery_fees' => round($deliveryFees, 2),
            'commission_paid' => round($commissionPaid, 2),
            'wallet_transactions' => round($walletTransactions, 2),
            'total_expenses' => round($deliveryFees + $commissionPaid + $walletTransactions, 2)
        ];
    }

    private function generateProfitReport($startDate, $endDate, $user)
    {
        $revenue = $this->generateRevenueReport($startDate, $endDate, $user);
        $expenses = $this->generateExpenseReport($startDate, $endDate, $user);

        $grossProfit = $revenue['total_revenue'] - $expenses['total_expenses'];
        $profitMargin = $revenue['total_revenue'] > 0 ? 
            ($grossProfit / $revenue['total_revenue']) * 100 : 0;

        return [
            'gross_profit' => round($grossProfit, 2),
            'profit_margin' => round($profitMargin, 2),
            'break_even_point' => $this->calculateBreakEvenPoint($expenses['total_expenses'], $revenue['average_order_value'])
        ];
    }

    private function generateTransactionReport($startDate, $endDate, $user)
    {
        $transactions = WalletTransaction::whereBetween('created_at', [$startDate, $endDate])
            ->select('type', DB::raw('COUNT(*) as count'), DB::raw('SUM(amount) as total'))
            ->groupBy('type')
            ->get();

        $paymentMethods = Order::whereBetween('created_at', [$startDate, $endDate])
            ->where('status', 'delivered')
            ->select('payment_method', DB::raw('COUNT(*) as count'), DB::raw('SUM(total) as total'))
            ->groupBy('payment_method')
            ->get();

        return [
            'wallet_transactions' => $transactions,
            'payment_methods' => $paymentMethods,
            'transaction_volume' => WalletTransaction::whereBetween('created_at', [$startDate, $endDate])->count()
        ];
    }

    private function generateForecastReport($startDate, $endDate)
    {
        // Simple linear regression for revenue forecasting
        $historicalData = Order::select(
                DB::raw('DATE(created_at) as date'),
                DB::raw('SUM(total) as revenue')
            )
            ->where('status', 'delivered')
            ->whereBetween('created_at', [$startDate->copy()->subDays(90), $endDate])
            ->groupBy('date')
            ->orderBy('date')
            ->get();

        $forecast = $this->calculateLinearForecast($historicalData);

        return [
            'next_30_days_forecast' => $forecast,
            'confidence_level' => 75, // Simplified confidence level
            'trend' => $this->identifyTrend($historicalData)
        ];
    }

    private function generateDeliveryPerformanceReport($startDate, $endDate)
    {
        $avgDeliveryTime = Order::whereBetween('created_at', [$startDate, $endDate])
            ->where('status', 'delivered')
            ->whereNotNull('delivered_at')
            ->selectRaw('AVG(TIMESTAMPDIFF(MINUTE, created_at, delivered_at)) as avg_time')
            ->value('avg_time');

        $onTimeDeliveries = Order::whereBetween('created_at', [$startDate, $endDate])
            ->where('status', 'delivered')
            ->whereRaw('TIMESTAMPDIFF(MINUTE, created_at, delivered_at) <= estimated_delivery_time')
            ->count();

        $totalDeliveries = Order::whereBetween('created_at', [$startDate, $endDate])
            ->where('status', 'delivered')
            ->count();

        return [
            'average_delivery_time' => round($avgDeliveryTime ?? 0, 2),
            'on_time_delivery_rate' => $totalDeliveries > 0 ? round(($onTimeDeliveries / $totalDeliveries) * 100, 2) : 0,
            'total_deliveries' => $totalDeliveries,
            'failed_deliveries' => Order::whereBetween('created_at', [$startDate, $endDate])
                ->where('status', 'delivery_failed')->count()
        ];
    }

    private function generateDriverEfficiencyReport($startDate, $endDate)
    {
        return User::where('user_type', 'driver')
            ->withCount(['deliveredOrders' => function($query) use ($startDate, $endDate) {
                $query->whereBetween('created_at', [$startDate, $endDate]);
            }])
            ->withAvg(['deliveredOrders' => function($query) use ($startDate, $endDate) {
                $query->whereBetween('created_at', [$startDate, $endDate]);
            }], 'rating')
            ->having('delivered_orders_count', '>', 0)
            ->orderBy('delivered_orders_count', 'desc')
            ->get(['id', 'name', 'email', 'delivered_orders_count', 'delivered_orders_avg_rating']);
    }

    private function generateMerchantPerformanceReport($startDate, $endDate)
    {
        return User::where('user_type', 'merchant')
            ->withCount(['merchantOrders' => function($query) use ($startDate, $endDate) {
                $query->whereBetween('created_at', [$startDate, $endDate]);
            }])
            ->withSum(['merchantOrders' => function($query) use ($startDate, $endDate) {
                $query->whereBetween('created_at', [$startDate, $endDate])
                      ->where('status', 'delivered');
            }], 'total')
            ->having('merchant_orders_count', '>', 0)
            ->orderBy('merchant_orders_sum_total', 'desc')
            ->get(['id', 'name', 'email', 'merchant_orders_count', 'merchant_orders_sum_total']);
    }

    private function generateCustomerSatisfactionReport($startDate, $endDate)
    {
        $avgRating = DB::table('ratings')
            ->whereBetween('created_at', [$startDate, $endDate])
            ->avg('rating');

        $ratingDistribution = DB::table('ratings')
            ->whereBetween('created_at', [$startDate, $endDate])
            ->select('rating', DB::raw('COUNT(*) as count'))
            ->groupBy('rating')
            ->orderBy('rating')
            ->get();

        return [
            'average_rating' => round($avgRating ?? 0, 2),
            'rating_distribution' => $ratingDistribution,
            'total_reviews' => DB::table('ratings')->whereBetween('created_at', [$startDate, $endDate])->count()
        ];
    }

    private function generateOperationalMetrics($startDate, $endDate)
    {
        return [
            'order_completion_rate' => $this->calculateCompletionRate($startDate, $endDate),
            'customer_acquisition_cost' => $this->calculateCAC($startDate, $endDate),
            'driver_utilization_rate' => $this->calculateDriverUtilization($startDate, $endDate),
            'peak_hours_analysis' => $this->analyzePeakHours($startDate, $endDate)
        ];
    }

    // Additional helper methods for calculations
    private function calculateRevenueGrowthRate($startDate, $endDate, $user)
    {
        $currentRevenue = Order::whereBetween('created_at', [$startDate, $endDate])
            ->where('status', 'delivered')->sum('total');
        
        $previousPeriodStart = $startDate->copy()->subDays($startDate->diffInDays($endDate));
        $previousRevenue = Order::whereBetween('created_at', [$previousPeriodStart, $startDate])
            ->where('status', 'delivered')->sum('total');

        if ($previousRevenue > 0) {
            return round((($currentRevenue - $previousRevenue) / $previousRevenue) * 100, 2);
        }

        return 0;
    }

    private function calculateBreakEvenPoint($totalExpenses, $avgOrderValue)
    {
        if ($avgOrderValue > 0) {
            return ceil($totalExpenses / $avgOrderValue);
        }
        return 0;
    }

    private function calculateLinearForecast($historicalData)
    {
        // Simplified linear regression forecast
        if ($historicalData->count() < 2) {
            return [];
        }

        $n = $historicalData->count();
        $sumX = 0;
        $sumY = 0;
        $sumXY = 0;
        $sumX2 = 0;

        foreach ($historicalData as $index => $data) {
            $x = $index + 1;
            $y = $data->revenue;
            
            $sumX += $x;
            $sumY += $y;
            $sumXY += $x * $y;
            $sumX2 += $x * $x;
        }

        $slope = ($n * $sumXY - $sumX * $sumY) / ($n * $sumX2 - $sumX * $sumX);
        $intercept = ($sumY - $slope * $sumX) / $n;

        $forecast = [];
        for ($i = 1; $i <= 30; $i++) {
            $forecastValue = $slope * ($n + $i) + $intercept;
            $forecast[] = [
                'day' => $i,
                'forecasted_revenue' => round(max(0, $forecastValue), 2)
            ];
        }

        return $forecast;
    }

    private function identifyTrend($historicalData)
    {
        if ($historicalData->count() < 2) {
            return 'insufficient_data';
        }

        $firstHalf = $historicalData->take($historicalData->count() / 2)->avg('revenue');
        $secondHalf = $historicalData->skip($historicalData->count() / 2)->avg('revenue');

        if ($secondHalf > $firstHalf * 1.1) {
            return 'increasing';
        } elseif ($secondHalf < $firstHalf * 0.9) {
            return 'decreasing';
        } else {
            return 'stable';
        }
    }

    private function calculateCompletionRate($startDate, $endDate)
    {
        $total = Order::whereBetween('created_at', [$startDate, $endDate])->count();
        $completed = Order::whereBetween('created_at', [$startDate, $endDate])
            ->where('status', 'delivered')->count();
        
        return $total > 0 ? round(($completed / $total) * 100, 2) : 0;
    }

    private function calculateCAC($startDate, $endDate)
    {
        // Simplified CAC calculation
        $marketingCosts = 1000; // This should come from actual marketing spend data
        $newCustomers = User::whereBetween('created_at', [$startDate, $endDate])
            ->where('user_type', 'regular')->count();
        
        return $newCustomers > 0 ? round($marketingCosts / $newCustomers, 2) : 0;
    }

    private function calculateDriverUtilization($startDate, $endDate)
    {
        $totalDrivers = User::where('user_type', 'driver')->where('is_active', true)->count();
        $activeDrivers = User::where('user_type', 'driver')
            ->whereHas('deliveredOrders', function($query) use ($startDate, $endDate) {
                $query->whereBetween('created_at', [$startDate, $endDate]);
            })->count();
        
        return $totalDrivers > 0 ? round(($activeDrivers / $totalDrivers) * 100, 2) : 0;
    }

    private function analyzePeakHours($startDate, $endDate)
    {
        return Order::whereBetween('created_at', [$startDate, $endDate])
            ->select(DB::raw('HOUR(created_at) as hour'), DB::raw('COUNT(*) as order_count'))
            ->groupBy('hour')
            ->orderBy('order_count', 'desc')
            ->limit(5)
            ->get();
    }

    // Export helper methods
    private function prepareFinancialExportData($startDate, $endDate)
    {
        return Order::whereBetween('created_at', [$startDate, $endDate])
            ->where('status', 'delivered')
            ->select('id', 'order_number', 'total', 'delivery_fee', 'payment_method', 'created_at', 'delivered_at')
            ->get()
            ->toArray();
    }

    private function prepareOperationalExportData($startDate, $endDate)
    {
        return Order::with(['customer', 'driver'])
            ->whereBetween('created_at', [$startDate, $endDate])
            ->select('id', 'order_number', 'status', 'customer_id', 'driver_id', 'created_at', 'delivered_at')
            ->get()
            ->toArray();
    }

    private function prepareCustomerExportData($startDate, $endDate)
    {
        return User::withCount(['orders' => function($query) use ($startDate, $endDate) {
                $query->whereBetween('created_at', [$startDate, $endDate]);
            }])
            ->withSum(['orders' => function($query) use ($startDate, $endDate) {
                $query->whereBetween('created_at', [$startDate, $endDate])
                      ->where('status', 'delivered');
            }], 'total')
            ->where('user_type', 'regular')
            ->get(['id', 'name', 'email', 'phone', 'created_at', 'orders_count', 'orders_sum_total'])
            ->toArray();
    }

    private function generateCSVResponse($data, $filename)
    {
        $headers = [
            'Content-Type' => 'text/csv',
            'Content-Disposition' => 'attachment; filename="' . $filename . '"',
        ];

        $callback = function() use ($data) {
            $file = fopen('php://output', 'w');
            
            if (!empty($data)) {
                fputcsv($file, array_keys($data[0]));
                foreach ($data as $row) {
                    fputcsv($file, $row);
                }
            }
            
            fclose($file);
        };

        return response()->stream($callback, 200, $headers);
    }

    private function generateExcelResponse($data, $filename)
    {
        // This would require a library like PhpSpreadsheet
        // For now, return CSV format
        return $this->generateCSVResponse($data, str_replace('.xlsx', '.csv', $filename));
    }
}
