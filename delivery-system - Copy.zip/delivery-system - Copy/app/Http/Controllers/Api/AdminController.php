<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\Order;
use App\Models\Complaint;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;

class AdminController extends Controller
{
    /**
     * Get admin dashboard data
     */
    public function dashboard(): JsonResponse
    {
        try {
            // Total users by type
            $userStats = User::selectRaw('
                user_type,
                COUNT(*) as count,
                SUM(CASE WHEN is_active = 1 THEN 1 ELSE 0 END) as active_count
            ')
            ->groupBy('user_type')
            ->get();

            // Order statistics
            $orderStats = Order::selectRaw('
                status,
                COUNT(*) as count,
                SUM(total_amount) as total_revenue
            ')
            ->groupBy('status')
            ->get();

            // Recent orders
            $recentOrders = Order::with(['customer:id,full_name', 'merchant:id,full_name', 'driver:id,full_name'])
                ->orderBy('created_at', 'desc')
                ->limit(10)
                ->get();

            // Recent complaints
            $recentComplaints = Complaint::with(['user:id,full_name'])
                ->orderBy('created_at', 'desc')
                ->limit(10)
                ->get();

            // Revenue statistics
            $revenueStats = Order::where('status', 'delivered')
                ->selectRaw('
                    DATE(created_at) as date,
                    COUNT(*) as orders,
                    SUM(total_amount) as revenue
                ')
                ->whereDate('created_at', '>=', now()->subDays(30))
                ->groupBy('date')
                ->orderBy('date')
                ->get();

            return response()->json([
                'success' => true,
                'message' => 'Dashboard data retrieved successfully',
                'data' => [
                    'user_stats' => $userStats,
                    'order_stats' => $orderStats,
                    'recent_orders' => $recentOrders,
                    'recent_complaints' => $recentComplaints,
                    'revenue_stats' => $revenueStats
                ]
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to retrieve dashboard data',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Get all users with filtering
     */
    public function getUsers(Request $request): JsonResponse
    {
        try {
            $query = User::query();
    
            // Apply filters
            if ($request->has('user_type')) {
                $query->where('user_type', $request->input('user_type'));
            }
    
            if ($request->has('status')) {
                $query->where('is_active', $request->input('status') === 'active' ? 1 : 0);
            }
    
            if ($request->has('search')) {
                $query->where(function($q) use ($request) {
                    $q->where('full_name', 'like', '%' . $request->input('search') . '%')
                      ->orWhere('phone', 'like', '%' . $request->input('search') . '%')
                      ->orWhere('email', 'like', '%' . $request->input('search') . '%');
                });
            }
    
            $users = $query->orderBy('created_at', 'desc')
                ->paginate($request->input('per_page', 15));
    
            return response()->json([
                'success' => true,
                'message' => 'Users retrieved successfully',
                'data' => $users
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to retrieve users',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Activate a user
     */
    public function activateUser($id): JsonResponse
    {
        try {
            $user = User::findOrFail($id);

            $user->update(['is_active' => true]);

            return response()->json([
                'success' => true,
                'message' => 'User activated successfully',
                'data' => $user
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to activate user',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Deactivate a user
     */
    public function deactivateUser($id): JsonResponse
    {
        try {
            $user = User::findOrFail($id);

            $user->update(['is_active' => false]);

            return response()->json([
                'success' => true,
                'message' => 'User deactivated successfully',
                'data' => $user
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to deactivate user',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Get all orders with filtering
     */
    public function getAllOrders(Request $request): JsonResponse
    {
        try {
            $query = Order::with(['customer:id,full_name', 'merchant:id,full_name', 'driver:id,full_name']);

            // Apply filters
            if ($request->has('status')) {
                $query->where('status', $request->status);
            }

            if ($request->has('user_type')) {
                if ($request->user_type === 'customer') {
                    $query->whereNotNull('customer_id');
                } elseif ($request->user_type === 'merchant') {
                    $query->whereNotNull('merchant_id');
                } elseif ($request->user_type === 'driver') {
                    $query->whereNotNull('driver_id');
                }
            }

            if ($request->has('date_from')) {
                $query->whereDate('created_at', '>=', $request->date_from);
            }

            if ($request->has('date_to')) {
                $query->whereDate('created_at', '<=', $request->date_to);
            }

            if ($request->has('search')) {
                $query->where('order_number', 'like', '%' . $request->search . '%');
            }

            $orders = $query->orderBy('created_at', 'desc')
                ->paginate($request->get('per_page', 15));

            return response()->json([
                'success' => true,
                'message' => __('messages.orders_retrieved'),
                'data' => $orders
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => __('messages.failed_to_retrieve_orders'),
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Get all complaints
     */
    public function getComplaints(Request $request): JsonResponse
    {
        try {
            $query = Complaint::with(['user:id,full_name', 'order:id,order_number']);

            // Apply filters
            if ($request->has('status')) {
                $query->where('status', $request->status);
            }

            if ($request->has('type')) {
                $query->where('type', $request->type);
            }

            if ($request->has('priority')) {
                $query->where('priority', $request->priority);
            }

            if ($request->has('date_from')) {
                $query->whereDate('created_at', '>=', $request->date_from);
            }

            if ($request->has('date_to')) {
                $query->whereDate('created_at', '<=', $request->date_to);
            }

            $complaints = $query->orderBy('created_at', 'desc')
                ->paginate($request->get('per_page', 15));

            return response()->json([
                'success' => true,
                'message' => __('messages.complaints_retrieved'),
                'data' => $complaints
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => __('messages.failed_to_retrieve_complaints'),
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Resolve a complaint
     */
    public function resolveComplaint(Request $request, $id): JsonResponse
    {
        try {
            $validator = Validator::make($request->all(), [
                'status' => 'required|in:resolved,closed',
                'admin_response' => 'required|string|max:1000',
                'resolution_notes' => 'nullable|string|max:1000'
            ]);

            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'message' => 'Validation failed',
                    'errors' => $validator->errors()
                ], 422);
            }

            $complaint = Complaint::findOrFail($id);

            $complaint->update([
                'status' => $request->status,
                'admin_response' => $request->admin_response,
                'resolution_notes' => $request->resolution_notes,
                'resolved_at' => now()
            ]);

            return response()->json([
                'success' => true,
                'message' => __('messages.complaint_resolved'),
                'data' => $complaint
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => __('messages.failed_to_resolve_complaint'),
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Get comprehensive reports
     */
    public function getReports(Request $request): JsonResponse
    {
        try {
            $dateFrom = $request->get('date_from', now()->startOfMonth());
            $dateTo = $request->get('date_to', now()->endOfMonth());

            // System overview
            $systemOverview = [
                'total_users' => User::count(),
                'total_orders' => Order::count(),
                'total_revenue' => Order::where('status', 'delivered')->sum('total_amount'),
                'active_drivers' => User::where('user_type', 'driver')->where('is_online', true)->count(),
                'active_merchants' => User::where('user_type', 'merchant')->where('is_active', true)->count()
            ];

            // Revenue analysis
            $revenueAnalysis = Order::where('status', 'delivered')
                ->whereBetween('created_at', [$dateFrom, $dateTo])
                ->selectRaw('
                    DATE(created_at) as date,
                    COUNT(*) as orders,
                    SUM(total_amount) as revenue,
                    AVG(total_amount) as avg_order_value
                ')
                ->groupBy('date')
                ->orderBy('date')
                ->get();

            // User growth
            $userGrowth = User::whereBetween('created_at', [$dateFrom, $dateTo])
                ->selectRaw('
                    DATE(created_at) as date,
                    user_type,
                    COUNT(*) as new_users
                ')
                ->groupBy('date', 'user_type')
                ->orderBy('date')
                ->get();

            // Top performing merchants
            $topMerchants = Order::where('status', 'delivered')
                ->whereBetween('created_at', [$dateFrom, $dateTo])
                ->join('users', 'orders.merchant_id', '=', 'users.id')
                ->selectRaw('
                    users.full_name,
                    COUNT(*) as total_orders,
                    SUM(orders.total_amount) as total_revenue
                ')
                ->groupBy('users.id', 'users.full_name')
                ->orderBy('total_revenue', 'desc')
                ->limit(10)
                ->get();

            return response()->json([
                'success' => true,
                'message' => 'Reports retrieved successfully',
                'data' => [
                    'system_overview' => $systemOverview,
                    'revenue_analysis' => $revenueAnalysis,
                    'user_growth' => $userGrowth,
                    'top_merchants' => $topMerchants,
                    'period' => [
                        'from' => $dateFrom,
                        'to' => $dateTo
                    ]
                ]
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to retrieve reports',
                'error' => $e->getMessage()
            ], 500);
        }
    }
}
