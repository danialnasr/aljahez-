<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\LoyaltyTransaction;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;

class LoyaltyController extends Controller
{
    /**
     * Get user loyalty points
     */
    public function getPoints(): JsonResponse
    {
        try {
            $user = auth()->user();
            
            $points = LoyaltyTransaction::where('user_id', $user->getAuthIdentifier())
                ->sum(DB::raw('CASE WHEN type = "earned" THEN points ELSE -points END'));
    
            return response()->json([
                'success' => true,
                'message' => 'Points retrieved successfully',
                'data' => [
                    'points' => $points,
                    'value' => $points * 0.1, // 1 point = $0.1
                    'currency' => 'USD'
                ]
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to retrieve points',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Redeem loyalty points
     */
    public function redeemPoints(Request $request): JsonResponse
    {
        try {
            $validator = Validator::make($request->all(), [
                'points' => 'required|integer|min:10',
                'reward_type' => 'required|in:discount,cashback,free_delivery',
                'description' => 'nullable|string|max:500'
            ]);

            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'message' => 'Validation failed',
                    'errors' => $validator->errors()
                ], 422);
            }

            $user = auth()->user();
            $pointsToRedeem = $request->input('points');

            // Use atomic transaction to prevent race conditions
            $result = DB::transaction(function() use ($user, $pointsToRedeem, $request) {
                // Lock user's loyalty transactions to prevent concurrent redemptions
                $currentPoints = LoyaltyTransaction::where('user_id', $user->id)
                    ->lockForUpdate()
                    ->sum(DB::raw('CASE WHEN type = "earned" THEN points ELSE -points END'));

                if ($currentPoints < $pointsToRedeem) {
                    throw new \Exception('Insufficient loyalty points. Available: ' . $currentPoints . ', Requested: ' . $pointsToRedeem);
                }

                // Calculate reward value
                $rewardValue = $pointsToRedeem * 0.1; // 1 point = $0.1

                // Create redemption transaction
                $transaction = LoyaltyTransaction::create([
                    'user_id' => $user->id,
                    'type' => 'redeemed',
                    'points' => $pointsToRedeem,
                    'description' => $request->input('description', 'Points redeemed for ' . $request->input('reward_type')),
                    'reward_type' => $request->input('reward_type'),
                    'reward_value' => $rewardValue,
                    'status' => 'completed'
                ]);

                // Log the redemption for audit trail
                \Illuminate\Support\Facades\Log::info("Loyalty points redeemed", [
                    'user_id' => $user->id,
                    'points_redeemed' => $pointsToRedeem,
                    'reward_type' => $request->input('reward_type'),
                    'reward_value' => $rewardValue,
                    'remaining_points' => $currentPoints - $pointsToRedeem
                ]);

                return [
                    'transaction' => $transaction,
                    'remaining_points' => $currentPoints - $pointsToRedeem,
                    'reward_value' => $rewardValue
                ];
            });

            return response()->json([
                'success' => true,
                'message' => 'Points redeemed successfully',
                'data' => $result
            ], 201);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to redeem points',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Get loyalty transactions
     */
    public function getTransactions(Request $request): JsonResponse
    {
        try {
            $user = auth()->user();
            
            $query = LoyaltyTransaction::where('user_id', $user->id)
                ->orderBy('created_at', 'desc');

            // Apply filters
            if ($request->has('type')) {
                $query->where('type', $request->type);
            }

            if ($request->has('reward_type')) {
                $query->where('reward_type', $request->reward_type);
            }

            if ($request->has('date_from')) {
                $query->whereDate('created_at', '>=', $request->date_from);
            }

            if ($request->has('date_to')) {
                $query->whereDate('created_at', '<=', $request->date_to);
            }

            $transactions = $query->paginate($request->get('per_page', 15));

            return response()->json([
                'success' => true,
                'message' => 'Transactions retrieved successfully',
                'data' => $transactions
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to retrieve transactions',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Get available rewards
     */
    public function getAvailableRewards(): JsonResponse
    {
        try {
            $user = auth()->user();
            
            $currentPoints = LoyaltyTransaction::where('user_id', $user->id)
                ->sum(DB::raw('CASE WHEN type = "earned" THEN points ELSE -points END'));

            $rewards = [
                [
                    'id' => 1,
                    'name' => '10% Discount',
                    'points_required' => 50,
                    'value' => 5.0,
                    'type' => 'discount',
                    'description' => 'Get 10% discount on your next order',
                    'available' => $currentPoints >= 50
                ],
                [
                    'id' => 2,
                    'name' => 'Free Delivery',
                    'points_required' => 30,
                    'value' => 3.0,
                    'type' => 'free_delivery',
                    'description' => 'Free delivery on your next order',
                    'available' => $currentPoints >= 30
                ],
                [
                    'id' => 3,
                    'name' => '$5 Cashback',
                    'points_required' => 100,
                    'value' => 5.0,
                    'type' => 'cashback',
                    'description' => 'Get $5 cashback to your wallet',
                    'available' => $currentPoints >= 100
                ],
                [
                    'id' => 4,
                    'name' => '20% Discount',
                    'points_required' => 200,
                    'value' => 20.0,
                    'type' => 'discount',
                    'description' => 'Get 20% discount on your next order',
                    'available' => $currentPoints >= 200
                ]
            ];

            return response()->json([
                'success' => true,
                'message' => 'Available rewards retrieved successfully',
                'data' => [
                    'rewards' => $rewards,
                    'current_points' => $currentPoints
                ]
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to retrieve rewards',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Earn points from order
     */
    public function earnPointsFromOrder($orderId): JsonResponse
    {
        try {
            $user = auth()->user();
            
            // This would typically be called after a successful order
            // For now, we'll create a sample earning transaction
            $points = 10; // 1 point per $10 spent
            
            $transaction = LoyaltyTransaction::create([
                'user_id' => $user->id,
                'type' => 'earned',
                'points' => $points,
                'order_id' => $orderId,
                'description' => 'Points earned from order',
                'status' => 'completed'
            ]);

            return response()->json([
                'success' => true,
                'message' => 'Points earned successfully',
                'data' => $transaction
            ], 201);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to earn points',
                'error' => $e->getMessage()
            ], 500);
        }
    }
}
