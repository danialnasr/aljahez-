<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Order;
use App\Models\Product;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;

class MerchantController extends Controller
{
    /**
     * Get list of merchants
     */
    public function index(Request $request): JsonResponse
    {
        try {
            $query = User::where('user_type', 'merchant')
                ->where('is_active', true)
                ->select('id', 'full_name', 'phone', 'email', 'address', 'lat', 'lng', 'created_at');

            // Apply search filter if provided
            if ($request->has('search')) {
                $search = $request->search;
                $query->where(function($q) use ($search) {
                    $q->where('full_name', 'like', '%' . $search . '%')
                      ->orWhere('phone', 'like', '%' . $search . '%')
                      ->orWhere('email', 'like', '%' . $search . '%');
                });
            }

            // Apply location-based filtering if coordinates provided
            if ($request->has('lat') && $request->has('lng')) {
                $lat = $request->lat;
                $lng = $request->lng;
                $radius = $request->get('radius', 10); // Default 10km radius
                
                $query->selectRaw(
                    "*, ( 6371 * acos( cos( radians(?) ) * cos( radians( lat ) ) * cos( radians( lng ) - radians(?) ) + sin( radians(?) ) * sin( radians( lat ) ) ) ) AS distance",
                    [$lat, $lng, $lat]
                )->having('distance', '<', $radius)
                 ->orderBy('distance');
            }

            $merchants = $query->orderBy('created_at', 'desc')
                ->paginate($request->get('per_page', 15));

            return response()->json([
                'success' => true,
                'message' => 'Merchants retrieved successfully',
                'data' => $merchants
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to retrieve merchants',
                'error' => $e->getMessage()
            ], 500);
        }
    }


    /**
     * Get merchant orders
     */
    public function getOrders(Request $request): JsonResponse
    {
        try {
            $user = auth()->user();

            if ($user->user_type !== 'merchant') {
                return response()->json([
                    'success' => false,
                    'message' => 'Only merchants can perform this action'
                ], 403);
            }

            $query = Order::where('merchant_id', $user->id)
                ->with(['customer:id,full_name,phone', 'driver:id,full_name,phone']);

            // Apply filters
            if ($request->has('status')) {
                $query->where('status', $request->status);
            }

            if ($request->has('date_from')) {
                $query->whereDate('created_at', '>=', $request->date_from);
            }

            if ($request->has('date_to')) {
                $query->whereDate('created_at', '<=', $request->date_to);
            }

            if ($request->has('search')) {
                $query->where('order_number', 'like', '%' . $request->search . '%');
            }

            $orders = $query->orderBy('created_at', 'desc')
                ->paginate($request->get('per_page', 15));

            return response()->json([
                'success' => true,
                'message' => 'Orders retrieved successfully',
                'data' => $orders
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to retrieve orders',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Accept an order
     */
    public function acceptOrder(Request $request, $orderId): JsonResponse
    {
        try {
            $user = auth()->user();

            if ($user->user_type !== 'merchant') {
                return response()->json([
                    'success' => false,
                    'message' => 'Only merchants can perform this action'
                ], 403);
            }

            $order = Order::where('id', $orderId)
                ->where('merchant_id', $user->id)
                ->where('status', 'pending')
                ->first();

            if (!$order) {
                return response()->json([
                    'success' => false,
                    'message' => 'Order not found or not available for acceptance'
                ], 400);
            }

            $order->update([
                'status' => 'accepted',
                'accepted_at' => now()
            ]);

            return response()->json([
                'success' => true,
                'message' => 'Order accepted successfully',
                'data' => $order
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to accept order',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Reject an order
     */
    public function rejectOrder(Request $request, $orderId): JsonResponse
    {
        try {
            $user = auth()->user();

            if ($user->user_type !== 'merchant') {
                return response()->json([
                    'success' => false,
                    'message' => 'Only merchants can perform this action'
                ], 403);
            }

        $validator = Validator::make($request->all(), [
                'reason' => 'required|string|max:500'
        ]);

        if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'message' => 'Validation failed',
                    'errors' => $validator->errors()
                ], 422);
            }

            $order = Order::where('id', $orderId)
                ->where('merchant_id', $user->id)
                ->where('status', 'pending')
                ->first();

            if (!$order) {
                return response()->json([
                    'success' => false,
                    'message' => 'Order not found or not available for rejection'
                ], 400);
            }

            $order->update([
                'status' => 'rejected',
                'rejection_reason' => $request->reason,
                'rejected_at' => now()
            ]);

        return response()->json([
                'success' => true,
                'message' => 'Order rejected successfully',
                'data' => $order
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to reject order',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Get merchant reports
     */
    public function getReports(Request $request): JsonResponse
    {
        try {
            $user = auth()->user();

            if ($user->user_type !== 'merchant') {
                return response()->json([
                    'success' => false,
                    'message' => 'Only merchants can perform this action'
                ], 403);
            }

            $dateFrom = $request->get('date_from', now()->startOfMonth());
            $dateTo = $request->get('date_to', now()->endOfMonth());

            // Sales report
            $salesReport = Order::where('merchant_id', $user->id)
                ->whereBetween('created_at', [$dateFrom, $dateTo])
                ->selectRaw('
                    COUNT(*) as total_orders,
                    SUM(total_amount) as total_revenue,
                    SUM(CASE WHEN status = "delivered" THEN total_amount ELSE 0 END) as completed_revenue,
                    SUM(CASE WHEN status = "cancelled" THEN total_amount ELSE 0 END) as cancelled_revenue,
                    AVG(total_amount) as average_order_value
                ')
                ->first();

            // Product performance
            $productPerformance = DB::table('order_items')
                ->join('orders', 'order_items.order_id', '=', 'orders.id')
                ->join('products', 'order_items.product_id', '=', 'products.id')
                ->where('orders.merchant_id', $user->id)
                ->whereBetween('orders.created_at', [$dateFrom, $dateTo])
                ->selectRaw('
                    products.name,
                    SUM(order_items.quantity) as total_quantity,
                    SUM(order_items.quantity * order_items.price) as total_revenue
                ')
                ->groupBy('products.id', 'products.name')
                ->orderBy('total_quantity', 'desc')
                ->limit(10)
                ->get();

            // Daily sales
            $dailySales = Order::where('merchant_id', $user->id)
                ->whereBetween('created_at', [$dateFrom, $dateTo])
                ->selectRaw('
                    DATE(created_at) as date,
                    COUNT(*) as orders,
                    SUM(total_amount) as revenue
                ')
                ->groupBy('date')
                ->orderBy('date')
                ->get();

            return response()->json([
                'success' => true,
                'message' => 'Reports retrieved successfully',
                'data' => [
                    'sales_report' => $salesReport,
                    'product_performance' => $productPerformance,
                    'daily_sales' => $dailySales,
                    'period' => [
                        'from' => $dateFrom,
                        'to' => $dateTo
                    ]
                ]
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to retrieve reports',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Get merchant statistics
     */
    public function getStats(): JsonResponse
    {
        try {
            $user = auth()->user();

            if ($user->user_type !== 'merchant') {
                return response()->json([
                    'success' => false,
                    'message' => 'Only merchants can perform this action'
                ], 403);
            }

            // Current month stats
            $currentMonth = now()->month;
            $currentYear = now()->year;

            $monthlyStats = Order::where('merchant_id', $user->id)
                ->whereMonth('created_at', $currentMonth)
                ->whereYear('created_at', $currentYear)
                ->selectRaw('
                    COUNT(*) as total_orders,
                    SUM(CASE WHEN status = "delivered" THEN 1 ELSE 0 END) as completed_orders,
                    SUM(CASE WHEN status = "cancelled" THEN 1 ELSE 0 END) as cancelled_orders,
                    SUM(total_amount) as total_revenue,
                    AVG(total_amount) as average_order_value
                ')
                ->first();

            // Product stats
            $productStats = Product::where('merchant_id', $user->id)
                ->selectRaw('
                    COUNT(*) as total_products,
                    SUM(CASE WHEN is_available = 1 THEN 1 ELSE 0 END) as available_products,
                    AVG(price) as average_price
                ')
                ->first();

            // Rating stats
            $ratingStats = DB::table('ratings')
                ->join('orders', 'ratings.order_id', '=', 'orders.id')
                ->where('orders.merchant_id', $user->id)
                ->where('ratings.type', 'merchant')
                ->selectRaw('
                    COUNT(*) as total_ratings,
                    AVG(rating) as average_rating,
                    COUNT(CASE WHEN rating >= 4 THEN 1 END) as positive_ratings
                ')
                ->first();

            return response()->json([
                'success' => true,
                'message' => 'Statistics retrieved successfully',
                'data' => [
                    'monthly_stats' => $monthlyStats,
                    'product_stats' => $productStats,
                    'rating_stats' => $ratingStats
                ]
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to retrieve statistics',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Update working hours
     */
    public function updateWorkingHours(Request $request): JsonResponse
    {
        try {
            $user = auth()->user();
    
            if ($user->user_type !== 'merchant') {
                return response()->json([
                    'success' => false,
                    'message' => 'Only merchants can perform this action'
                ], 403);
            }
    
            $validator = Validator::make($request->all(), [
                'working_hours' => 'required|array',
                'working_hours.*.day' => 'required|in:monday,tuesday,wednesday,thursday,friday,saturday,sunday',
                'working_hours.*.is_open' => 'required|boolean',
                'working_hours.*.open_time' => 'required_if:working_hours.*.is_open,true|nullable|date_format:H:i',
                'working_hours.*.close_time' => 'required_if:working_hours.*.is_open,true|nullable|date_format:H:i'
            ]);
    
            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'message' => 'Validation failed',
                    'errors' => $validator->errors()
                ], 422);
            }
    
            $user->working_hours = $request->working_hours;
            $user->save();
    
            return response()->json([
                'success' => true,
                'message' => 'Working hours updated successfully',
                'data' => [
                    'working_hours' => $user->working_hours
                ]
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to update working hours',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Get merchant profile
     */
    public function getProfile(): JsonResponse
    {
        try {
            $user = auth()->user();

            if ($user->user_type !== 'merchant') {
                return response()->json([
                    'success' => false,
                    'message' => 'Only merchants can perform this action'
                ], 403);
            }

            return response()->json([
                'success' => true,
                'message' => 'Profile retrieved successfully',
                'data' => $user
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to retrieve profile',
                'error' => $e->getMessage()
            ], 500);
        }
    }
}
