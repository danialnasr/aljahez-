<?php

namespace App\Exceptions;

use Illuminate\Foundation\Exceptions\Handler as ExceptionHandler;
use Illuminate\Auth\AuthenticationException;
use Throwable;

class Handler extends ExceptionHandler
{
    /**
     * The list of the inputs that are never flashed to the session on validation exceptions.
     *
     * @var array<int, string>
     */
    protected $dontFlash = [
        'current_password',
        'password',
        'password_confirmation',
    ];

    /**
     * Render an exception into an HTTP response.
     */
    public function render($request, Throwable $e)
    {
        // Handle authentication exceptions specifically
        if ($e instanceof AuthenticationException) {
            return $this->unauthenticated($request, $e);
        }
        
        // For API requests, always return JSON
        if ($request->expectsJson() || $request->is('api/*')) {
            return response()->json([
                'success' => false,
                'message' => 'Server Error',
                'error' => app()->hasDebugModeEnabled() ? $e->getMessage() : 'Something went wrong.',
                'code' => $this->isHttpException($e) ? $e->getStatusCode() : 500
            ], $this->isHttpException($e) ? $e->getStatusCode() : 500);
        }
        
        return parent::render($request, $e);
    }

    /**
     * Convert an authentication exception into a response.
     * Override parent method to prevent login route redirect.
     */
    protected function unauthenticated($request, AuthenticationException $exception)
    {
        // Always return JSON for API requests - no redirects
        return response()->json([
            'success' => false,
            'message' => 'Unauthenticated.',
            'error' => 'Authentication required to access this resource.',
            'code' => 401
        ], 401);
    }

    /**
     * Register the exception handling callbacks for the application.
     */
    public function register(): void
    {
        $this->reportable(function (Throwable $e) {
            //
        });
    }
}
