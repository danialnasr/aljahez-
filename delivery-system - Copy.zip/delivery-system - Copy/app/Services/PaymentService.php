<?php

namespace App\Services;

use App\Models\Order;
use App\Models\User;
use App\Models\WalletTransaction;
use Exception;

class PaymentService
{
    public function processPayment(Order $order, array $paymentDetails = [])
    {
        try {
            switch ($order->payment_method) {
                case 'wallet':
                    return $this->processWalletPayment($order);
                case 'card':
                    return $this->processCardPayment($order, $paymentDetails);
                case 'zain_cash':
                    return $this->processZainCashPayment($order, $paymentDetails);
                case 'cash':
                    return $this->processCashPayment($order);
                default:
                    throw new Exception('Unsupported payment method');
            }
        } catch (Exception $e) {
            \Log::error("Payment processing failed for order {$order->id}: " . $e->getMessage());
            throw $e;
        }
    }

    private function processWalletPayment(Order $order)
    {
        $customer = $order->customer;

        if ($customer->wallet_balance < $order->total) {
            throw new Exception('Insufficient wallet balance');
        }

        $customer->decrement('wallet_balance', $order->total);

        // Record transaction
        WalletTransaction::create([
            'user_id' => $customer->id,
            'type' => 'payment',
            'amount' => -$order->total,
            'description' => "Payment for order #{$order->order_number}"
        ]);

        return [
            'status' => 'success',
            'transaction_id' => 'wallet_' . uniqid(),
            'message' => 'Payment processed successfully'
        ];
    }

    private function processCardPayment(Order $order, array $paymentDetails)
    {
        // Integration with Stripe payment gateway
        try {
            if (!isset($paymentDetails['card_token'])) {
                throw new Exception('Card token is required');
            }
            $stripeSecret = env('STRIPE_SECRET');
            if (!$stripeSecret) {
                throw new Exception('Stripe secret key not configured');
            }
            \Stripe\Stripe::setApiKey($stripeSecret);
            $charge = \Stripe\Charge::create([
                'amount' => intval($order->total * 100), // Stripe uses cents
                'currency' => 'usd',
                'source' => $paymentDetails['card_token'],
                'description' => "Payment for order #{$order->order_number}"
            ]);
            if ($charge->status !== 'succeeded') {
                throw new Exception('Stripe payment failed');
            }
            \Log::info("Stripe card payment processed for order {$order->id}", [
                'amount' => $order->total,
                'transaction_id' => $charge->id
            ]);
            return [
                'status' => 'success',
                'transaction_id' => $charge->id,
                'message' => 'Card payment processed successfully'
            ];
        } catch (Exception $e) {
            throw new Exception('Card payment failed: ' . $e->getMessage());
        }
    }

    private function processZainCashPayment(Order $order, array $paymentDetails)
    {
        // Integration with Zain Cash API
        try {
            if (!isset($paymentDetails['phone'])) {
                throw new Exception('Phone number is required for Zain Cash');
            }
            $zainCashApiUrl = env('ZAINCASH_API_URL');
            $zainCashMerchantId = env('ZAINCASH_MERCHANT_ID');
            $zainCashSecret = env('ZAINCASH_SECRET');
            if (!$zainCashApiUrl || !$zainCashMerchantId || !$zainCashSecret) {
                throw new Exception('Zain Cash API not configured');
            }
            $payload = [
                'msisdn' => $paymentDetails['phone'],
                'amount' => $order->total,
                'merchantId' => $zainCashMerchantId,
                'orderId' => $order->order_number,
                'description' => "Payment for order #{$order->order_number}"
            ];
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $zainCashApiUrl);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_HTTPHEADER, [
                'Authorization: Bearer ' . $zainCashSecret,
                'Content-Type: application/json'
            ]);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);
            $result = json_decode($response, true);
            if ($httpCode !== 200 || empty($result['status']) || $result['status'] !== 'success') {
                throw new Exception('Zain Cash payment failed: ' . ($result['message'] ?? 'Unknown error'));
            }
            \Log::info("Zain Cash payment processed for order {$order->id}", [
                'amount' => $order->total,
                'transaction_id' => $result['transactionId'] ?? null
            ]);
            return [
                'status' => 'success',
                'transaction_id' => $result['transactionId'] ?? null,
                'message' => 'Zain Cash payment processed successfully'
            ];
        } catch (Exception $e) {
            throw new Exception('Zain Cash payment failed: ' . $e->getMessage());
        }
    }

    private function processCashPayment(Order $order)
    {
        // Cash payment is handled on delivery
        return [
            'status' => 'pending',
            'transaction_id' => 'cash_' . uniqid(),
            'message' => 'Cash payment will be collected on delivery'
        ];
    }

    public function refundPayment(Order $order, $amount = null)
    {
        $refundAmount = $amount ?? $order->total;

        try {
            switch ($order->payment_method) {
                case 'wallet':
                    return $this->refundToWallet($order, $refundAmount);
                case 'card':
                    return $this->refundToCard($order, $refundAmount);
                case 'zain_cash':
                    return $this->refundToZainCash($order, $refundAmount);
                case 'cash':
                    return $this->refundCash($order, $refundAmount);
                default:
                    throw new Exception('Cannot process refund for this payment method');
            }
        } catch (Exception $e) {
            \Log::error("Refund processing failed for order {$order->id}: " . $e->getMessage());
            throw $e;
        }
    }

    private function refundToWallet(Order $order, $amount)
    {
        $customer = $order->customer;
        $customer->increment('wallet_balance', $amount);

        WalletTransaction::create([
            'user_id' => $customer->id,
            'type' => 'refund',
            'amount' => $amount,
            'description' => "Refund for order #{$order->order_number}"
        ]);

        return [
            'status' => 'success',
            'message' => 'Refund processed to wallet'
        ];
    }

    private function refundToCard(Order $order, $amount)
    {
        // Process card refund through payment gateway
        $transactionId = 'refund_' . uniqid();

        \Log::info("Card refund processed for order {$order->id}", [
            'amount' => $amount,
            'transaction_id' => $transactionId
        ]);

        return [
            'status' => 'success',
            'transaction_id' => $transactionId,
            'message' => 'Refund processed to original card'
        ];
    }

    private function refundToZainCash(Order $order, $amount)
    {
        // Process Zain Cash refund
        $transactionId = 'zain_refund_' . uniqid();

        \Log::info("Zain Cash refund processed for order {$order->id}", [
            'amount' => $amount,
            'transaction_id' => $transactionId
        ]);

        return [
            'status' => 'success',
            'transaction_id' => $transactionId,
            'message' => 'Refund processed via Zain Cash'
        ];
    }

    private function refundCash(Order $order, $amount)
    {
        // Cash refund requires manual handling
        return [
            'status' => 'pending',
            'message' => 'Cash refund requires manual processing'
        ];
    }

    public function distributePayments(Order $order)
    {
        if ($order->payment_status !== 'completed') {
            throw new Exception('Payment not completed');
        }

        // Distribute to merchants
        $merchantPayments = [];
        foreach ($order->items as $item) {
            if (!isset($merchantPayments[$item->merchant_id])) {
                $merchantPayments[$item->merchant_id] = 0;
            }
            $merchantPayments[$item->merchant_id] += $item->total;
        }

        foreach ($merchantPayments as $merchantId => $amount) {
            $merchant = User::find($merchantId);
            $commission = $amount * 0.1; // 10% commission
            $netAmount = $amount - $commission;

            $merchant->increment('wallet_balance', $netAmount);

            // Record merchant earning
            WalletTransaction::create([
                'user_id' => $merchant->id,
                'type' => 'earning',
                'amount' => $netAmount,
                'description' => "Earning from order #{$order->order_number}"
            ]);

            // Record commission deduction
            WalletTransaction::create([
                'user_id' => $merchant->id,
                'type' => 'commission',
                'amount' => -$commission,
                'description' => "Commission for order #{$order->order_number}"
            ]);
        }

        // Pay driver
        if ($order->driver_id) {
            $driver = User::find($order->driver_id);
            $driverEarning = $order->delivery_fee + $order->tip;

            $driver->increment('wallet_balance', $driverEarning);

            WalletTransaction::create([
                'user_id' => $driver->id,
                'type' => 'earning',
                'amount' => $driverEarning,
                'description' => "Delivery earning from order #{$order->order_number}"
            ]);
        }

        \Log::info("Payments distributed for order {$order->id}");
    }

    public function calculateDeliveryFee($fromLat, $fromLng, $toLat, $toLng)
    {
        // Calculate distance using Haversine formula
        $earthRadius = 6371; // km

        $latDelta = deg2rad($toLat - $fromLat);
        $lngDelta = deg2rad($toLng - $fromLng);

        $a = sin($latDelta / 2) * sin($latDelta / 2) +
             cos(deg2rad($fromLat)) * cos(deg2rad($toLat)) *
             sin($lngDelta / 2) * sin($lngDelta / 2);

        $c = 2 * atan2(sqrt($a), sqrt(1 - $a));
        $distance = $earthRadius * $c;

        // Base fee + distance fee
        $baseFee = 2.0; // $2 base fee
        $perKmFee = 0.5; // $0.5 per km

        return max($baseFee, $baseFee + ($distance * $perKmFee));
    }

    public function getRouteAndETA($fromLat, $fromLng, $toLat, $toLng)
    {
        $googleApiKey = env('GOOGLE_MAPS_API_KEY');
        if (!$googleApiKey) {
            throw new \Exception('Google Maps API key not configured');
        }
        $url = "https://maps.googleapis.com/maps/api/directions/json?origin={$fromLat},{$fromLng}&destination={$toLat},{$toLng}&key={$googleApiKey}";
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        $result = json_decode($response, true);
        if ($httpCode !== 200 || empty($result['routes'][0]['legs'][0])) {
            throw new \Exception('Failed to get route from Google Maps API');
        }
        $leg = $result['routes'][0]['legs'][0];
        return [
            'distance_meters' => $leg['distance']['value'],
            'distance_text' => $leg['distance']['text'],
            'duration_seconds' => $leg['duration']['value'],
            'duration_text' => $leg['duration']['text'],
            'polyline' => $result['routes'][0]['overview_polyline']['points'] ?? null
        ];
    }
}

