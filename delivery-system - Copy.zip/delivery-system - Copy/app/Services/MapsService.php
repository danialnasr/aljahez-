<?php

namespace App\Services;

use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Log;

class MapsService
{
    private $googleMapsApiKey;
    private $mapboxAccessToken;

    public function __construct()
    {
        $this->googleMapsApiKey = config('services.google_maps.api_key');
        $this->mapboxAccessToken = config('services.mapbox.access_token');
    }

    /**
     * Calculate distance and duration between two points
     */
    public function calculateRoute($originLat, $originLng, $destLat, $destLng, $provider = 'google')
    {
        $cacheKey = "route_{$originLat}_{$originLng}_{$destLat}_{$destLng}_{$provider}";
        
        return Cache::remember($cacheKey, 3600, function() use ($originLat, $originLng, $destLat, $destLng, $provider) {
            try {
                if ($provider === 'google' && $this->googleMapsApiKey) {
                    return $this->calculateRouteGoogle($originLat, $originLng, $destLat, $destLng);
                } elseif ($provider === 'mapbox' && $this->mapboxAccessToken) {
                    return $this->calculateRouteMapbox($originLat, $originLng, $destLat, $destLng);
                } else {
                    // Fallback to Haversine formula
                    return $this->calculateRouteHaversine($originLat, $originLng, $destLat, $destLng);
                }
            } catch (\Exception $e) {
                Log::error('Route calculation failed', [
                    'error' => $e->getMessage(),
                    'origin' => [$originLat, $originLng],
                    'destination' => [$destLat, $destLng],
                    'provider' => $provider
                ]);
                
                // Fallback to Haversine
                return $this->calculateRouteHaversine($originLat, $originLng, $destLat, $destLng);
            }
        });
    }

    /**
     * Google Maps Distance Matrix API
     */
    private function calculateRouteGoogle($originLat, $originLng, $destLat, $destLng)
    {
        $response = Http::get('https://maps.googleapis.com/maps/api/distancematrix/json', [
            'origins' => "{$originLat},{$originLng}",
            'destinations' => "{$destLat},{$destLng}",
            'units' => 'metric',
            'mode' => 'driving',
            'traffic_model' => 'best_guess',
            'departure_time' => 'now',
            'key' => $this->googleMapsApiKey
        ]);

        $data = $response->json();

        if ($data['status'] === 'OK' && isset($data['rows'][0]['elements'][0])) {
            $element = $data['rows'][0]['elements'][0];
            
            if ($element['status'] === 'OK') {
                return [
                    'distance_km' => round($element['distance']['value'] / 1000, 2),
                    'distance_text' => $element['distance']['text'],
                    'duration_minutes' => round($element['duration']['value'] / 60, 0),
                    'duration_text' => $element['duration']['text'],
                    'duration_in_traffic_minutes' => isset($element['duration_in_traffic']) 
                        ? round($element['duration_in_traffic']['value'] / 60, 0) 
                        : null,
                    'provider' => 'google',
                    'status' => 'success'
                ];
            }
        }

        throw new \Exception('Google Maps API returned invalid response');
    }

    /**
     * Mapbox Directions API
     */
    private function calculateRouteMapbox($originLat, $originLng, $destLat, $destLng)
    {
        $response = Http::get("https://api.mapbox.com/directions/v5/mapbox/driving/{$originLng},{$originLat};{$destLng},{$destLat}", [
            'access_token' => $this->mapboxAccessToken,
            'geometries' => 'geojson',
            'steps' => 'true',
            'annotations' => 'duration,distance'
        ]);

        $data = $response->json();

        if (isset($data['routes'][0])) {
            $route = $data['routes'][0];
            
            return [
                'distance_km' => round($route['distance'] / 1000, 2),
                'distance_text' => round($route['distance'] / 1000, 1) . ' km',
                'duration_minutes' => round($route['duration'] / 60, 0),
                'duration_text' => round($route['duration'] / 60, 0) . ' min',
                'geometry' => $route['geometry'],
                'provider' => 'mapbox',
                'status' => 'success'
            ];
        }

        throw new \Exception('Mapbox API returned invalid response');
    }

    /**
     * Fallback Haversine calculation
     */
    private function calculateRouteHaversine($originLat, $originLng, $destLat, $destLng)
    {
        $earthRadius = 6371; // Earth's radius in kilometers

        $dLat = deg2rad($destLat - $originLat);
        $dLng = deg2rad($destLng - $originLng);

        $a = sin($dLat/2) * sin($dLat/2) + 
             cos(deg2rad($originLat)) * cos(deg2rad($destLat)) * 
             sin($dLng/2) * sin($dLng/2);
        
        $c = 2 * atan2(sqrt($a), sqrt(1-$a));
        $distance = $earthRadius * $c;

        // Estimate duration (assuming average speed of 30 km/h in city)
        $estimatedDuration = ($distance / 30) * 60; // minutes

        return [
            'distance_km' => round($distance, 2),
            'distance_text' => round($distance, 1) . ' km',
            'duration_minutes' => round($estimatedDuration, 0),
            'duration_text' => round($estimatedDuration, 0) . ' min',
            'provider' => 'haversine',
            'status' => 'estimated'
        ];
    }

    /**
     * Geocode address to coordinates
     */
    public function geocodeAddress($address, $provider = 'google')
    {
        $cacheKey = "geocode_" . md5($address . $provider);
        
        return Cache::remember($cacheKey, 86400, function() use ($address, $provider) {
            try {
                if ($provider === 'google' && $this->googleMapsApiKey) {
                    return $this->geocodeAddressGoogle($address);
                } elseif ($provider === 'mapbox' && $this->mapboxAccessToken) {
                    return $this->geocodeAddressMapbox($address);
                }
                
                throw new \Exception('No geocoding provider available');
            } catch (\Exception $e) {
                Log::error('Geocoding failed', [
                    'error' => $e->getMessage(),
                    'address' => $address,
                    'provider' => $provider
                ]);
                
                return null;
            }
        });
    }

    /**
     * Google Geocoding API
     */
    private function geocodeAddressGoogle($address)
    {
        $response = Http::get('https://maps.googleapis.com/maps/api/geocode/json', [
            'address' => $address,
            'key' => $this->googleMapsApiKey
        ]);

        $data = $response->json();

        if ($data['status'] === 'OK' && isset($data['results'][0])) {
            $result = $data['results'][0];
            $location = $result['geometry']['location'];
            
            return [
                'lat' => $location['lat'],
                'lng' => $location['lng'],
                'formatted_address' => $result['formatted_address'],
                'place_id' => $result['place_id'] ?? null,
                'provider' => 'google'
            ];
        }

        return null;
    }

    /**
     * Mapbox Geocoding API
     */
    private function geocodeAddressMapbox($address)
    {
        $response = Http::get("https://api.mapbox.com/geocoding/v5/mapbox.places/" . urlencode($address) . ".json", [
            'access_token' => $this->mapboxAccessToken,
            'limit' => 1
        ]);

        $data = $response->json();

        if (isset($data['features'][0])) {
            $feature = $data['features'][0];
            $coordinates = $feature['geometry']['coordinates'];
            
            return [
                'lat' => $coordinates[1],
                'lng' => $coordinates[0],
                'formatted_address' => $feature['place_name'],
                'place_id' => $feature['id'] ?? null,
                'provider' => 'mapbox'
            ];
        }

        return null;
    }

    /**
     * Reverse geocode coordinates to address
     */
    public function reverseGeocode($lat, $lng, $provider = 'google')
    {
        $cacheKey = "reverse_geocode_{$lat}_{$lng}_{$provider}";
        
        return Cache::remember($cacheKey, 86400, function() use ($lat, $lng, $provider) {
            try {
                if ($provider === 'google' && $this->googleMapsApiKey) {
                    return $this->reverseGeocodeGoogle($lat, $lng);
                } elseif ($provider === 'mapbox' && $this->mapboxAccessToken) {
                    return $this->reverseGeocodeMapbox($lat, $lng);
                }
                
                return null;
            } catch (\Exception $e) {
                Log::error('Reverse geocoding failed', [
                    'error' => $e->getMessage(),
                    'coordinates' => [$lat, $lng],
                    'provider' => $provider
                ]);
                
                return null;
            }
        });
    }

    /**
     * Google Reverse Geocoding
     */
    private function reverseGeocodeGoogle($lat, $lng)
    {
        $response = Http::get('https://maps.googleapis.com/maps/api/geocode/json', [
            'latlng' => "{$lat},{$lng}",
            'key' => $this->googleMapsApiKey
        ]);

        $data = $response->json();

        if ($data['status'] === 'OK' && isset($data['results'][0])) {
            $result = $data['results'][0];
            
            return [
                'formatted_address' => $result['formatted_address'],
                'components' => $this->parseAddressComponents($result['address_components']),
                'provider' => 'google'
            ];
        }

        return null;
    }

    /**
     * Mapbox Reverse Geocoding
     */
    private function reverseGeocodeMapbox($lat, $lng)
    {
        $response = Http::get("https://api.mapbox.com/geocoding/v5/mapbox.places/{$lng},{$lat}.json", [
            'access_token' => $this->mapboxAccessToken,
            'limit' => 1
        ]);

        $data = $response->json();

        if (isset($data['features'][0])) {
            $feature = $data['features'][0];
            
            return [
                'formatted_address' => $feature['place_name'],
                'components' => $this->parseMapboxContext($feature['context'] ?? []),
                'provider' => 'mapbox'
            ];
        }

        return null;
    }

    /**
     * Find nearby places
     */
    public function findNearbyPlaces($lat, $lng, $type = 'restaurant', $radius = 5000)
    {
        if (!$this->googleMapsApiKey) {
            return [];
        }

        $cacheKey = "nearby_places_{$lat}_{$lng}_{$type}_{$radius}";
        
        return Cache::remember($cacheKey, 1800, function() use ($lat, $lng, $type, $radius) {
            try {
                $response = Http::get('https://maps.googleapis.com/maps/api/place/nearbysearch/json', [
                    'location' => "{$lat},{$lng}",
                    'radius' => $radius,
                    'type' => $type,
                    'key' => $this->googleMapsApiKey
                ]);

                $data = $response->json();

                if ($data['status'] === 'OK') {
                    return collect($data['results'])->map(function($place) {
                        return [
                            'place_id' => $place['place_id'],
                            'name' => $place['name'],
                            'rating' => $place['rating'] ?? null,
                            'price_level' => $place['price_level'] ?? null,
                            'lat' => $place['geometry']['location']['lat'],
                            'lng' => $place['geometry']['location']['lng'],
                            'vicinity' => $place['vicinity'] ?? null,
                            'types' => $place['types'] ?? []
                        ];
                    })->toArray();
                }

                return [];
            } catch (\Exception $e) {
                Log::error('Nearby places search failed', [
                    'error' => $e->getMessage(),
                    'coordinates' => [$lat, $lng],
                    'type' => $type
                ]);
                
                return [];
            }
        });
    }

    /**
     * Get optimized route for multiple waypoints
     */
    public function getOptimizedRoute($waypoints, $provider = 'google')
    {
        if (count($waypoints) < 2) {
            throw new \Exception('At least 2 waypoints required');
        }

        try {
            if ($provider === 'google' && $this->googleMapsApiKey) {
                return $this->getOptimizedRouteGoogle($waypoints);
            } elseif ($provider === 'mapbox' && $this->mapboxAccessToken) {
                return $this->getOptimizedRouteMapbox($waypoints);
            }
            
            // Fallback: simple route without optimization
            return $this->getSimpleMultiRoute($waypoints);
        } catch (\Exception $e) {
            Log::error('Route optimization failed', [
                'error' => $e->getMessage(),
                'waypoints' => $waypoints,
                'provider' => $provider
            ]);
            
            throw $e;
        }
    }

    /**
     * Google Directions API with waypoint optimization
     */
    private function getOptimizedRouteGoogle($waypoints)
    {
        $origin = array_shift($waypoints);
        $destination = array_pop($waypoints);
        
        $waypointsStr = '';
        if (!empty($waypoints)) {
            $waypointsStr = 'optimize:true|' . implode('|', array_map(function($wp) {
                return $wp['lat'] . ',' . $wp['lng'];
            }, $waypoints));
        }

        $params = [
            'origin' => $origin['lat'] . ',' . $origin['lng'],
            'destination' => $destination['lat'] . ',' . $destination['lng'],
            'key' => $this->googleMapsApiKey
        ];

        if ($waypointsStr) {
            $params['waypoints'] = $waypointsStr;
        }

        $response = Http::get('https://maps.googleapis.com/maps/api/directions/json', $params);
        $data = $response->json();

        if ($data['status'] === 'OK' && isset($data['routes'][0])) {
            $route = $data['routes'][0];
            
            return [
                'distance_km' => round(collect($route['legs'])->sum('distance.value') / 1000, 2),
                'duration_minutes' => round(collect($route['legs'])->sum('duration.value') / 60, 0),
                'waypoint_order' => $data['routes'][0]['waypoint_order'] ?? [],
                'polyline' => $route['overview_polyline']['points'],
                'legs' => collect($route['legs'])->map(function($leg) {
                    return [
                        'distance_km' => round($leg['distance']['value'] / 1000, 2),
                        'duration_minutes' => round($leg['duration']['value'] / 60, 0),
                        'start_address' => $leg['start_address'],
                        'end_address' => $leg['end_address']
                    ];
                })->toArray(),
                'provider' => 'google'
            ];
        }

        throw new \Exception('Google Directions API returned invalid response');
    }

    /**
     * Mapbox Optimization API
     */
    private function getOptimizedRouteMapbox($waypoints)
    {
        $coordinates = collect($waypoints)->map(function($wp) {
            return $wp['lng'] . ',' . $wp['lat'];
        })->implode(';');

        $response = Http::get("https://api.mapbox.com/optimized-trips/v1/mapbox/driving/{$coordinates}", [
            'access_token' => $this->mapboxAccessToken,
            'geometries' => 'geojson',
            'steps' => 'true'
        ]);

        $data = $response->json();

        if (isset($data['trips'][0])) {
            $trip = $data['trips'][0];
            
            return [
                'distance_km' => round($trip['distance'] / 1000, 2),
                'duration_minutes' => round($trip['duration'] / 60, 0),
                'waypoint_order' => collect($data['waypoints'])->pluck('waypoint_index')->toArray(),
                'geometry' => $trip['geometry'],
                'legs' => collect($trip['legs'])->map(function($leg) {
                    return [
                        'distance_km' => round($leg['distance'] / 1000, 2),
                        'duration_minutes' => round($leg['duration'] / 60, 0)
                    ];
                })->toArray(),
                'provider' => 'mapbox'
            ];
        }

        throw new \Exception('Mapbox Optimization API returned invalid response');
    }

    /**
     * Simple multi-route without optimization (fallback)
     */
    private function getSimpleMultiRoute($waypoints)
    {
        $totalDistance = 0;
        $totalDuration = 0;
        $legs = [];

        for ($i = 0; $i < count($waypoints) - 1; $i++) {
            $route = $this->calculateRouteHaversine(
                $waypoints[$i]['lat'], $waypoints[$i]['lng'],
                $waypoints[$i + 1]['lat'], $waypoints[$i + 1]['lng']
            );
            
            $totalDistance += $route['distance_km'];
            $totalDuration += $route['duration_minutes'];
            
            $legs[] = [
                'distance_km' => $route['distance_km'],
                'duration_minutes' => $route['duration_minutes']
            ];
        }

        return [
            'distance_km' => round($totalDistance, 2),
            'duration_minutes' => round($totalDuration, 0),
            'waypoint_order' => range(0, count($waypoints) - 1),
            'legs' => $legs,
            'provider' => 'haversine'
        ];
    }

    /**
     * Parse Google address components
     */
    private function parseAddressComponents($components)
    {
        $parsed = [];
        
        foreach ($components as $component) {
            $types = $component['types'];
            
            if (in_array('street_number', $types)) {
                $parsed['street_number'] = $component['long_name'];
            } elseif (in_array('route', $types)) {
                $parsed['street'] = $component['long_name'];
            } elseif (in_array('locality', $types)) {
                $parsed['city'] = $component['long_name'];
            } elseif (in_array('administrative_area_level_1', $types)) {
                $parsed['state'] = $component['long_name'];
            } elseif (in_array('country', $types)) {
                $parsed['country'] = $component['long_name'];
                $parsed['country_code'] = $component['short_name'];
            } elseif (in_array('postal_code', $types)) {
                $parsed['postal_code'] = $component['long_name'];
            }
        }
        
        return $parsed;
    }

    /**
     * Parse Mapbox context
     */
    private function parseMapboxContext($context)
    {
        $parsed = [];
        
        foreach ($context as $item) {
            if (strpos($item['id'], 'place') === 0) {
                $parsed['city'] = $item['text'];
            } elseif (strpos($item['id'], 'region') === 0) {
                $parsed['state'] = $item['text'];
            } elseif (strpos($item['id'], 'country') === 0) {
                $parsed['country'] = $item['text'];
            } elseif (strpos($item['id'], 'postcode') === 0) {
                $parsed['postal_code'] = $item['text'];
            }
        }
        
        return $parsed;
    }

    /**
     * Validate coordinates
     */
    public function validateCoordinates($lat, $lng)
    {
        return is_numeric($lat) && is_numeric($lng) && 
               $lat >= -90 && $lat <= 90 && 
               $lng >= -180 && $lng <= 180;
    }

    /**
     * Calculate delivery zones based on distance
     */
    public function calculateDeliveryZones($centerLat, $centerLng, $zones = [5, 10, 15])
    {
        return collect($zones)->map(function($radius) use ($centerLat, $centerLng) {
            return [
                'radius_km' => $radius,
                'center' => ['lat' => $centerLat, 'lng' => $centerLng],
                'delivery_fee' => $this->calculateDeliveryFeeByDistance($radius),
                'estimated_time' => $this->estimateDeliveryTime($radius)
            ];
        })->toArray();
    }

    /**
     * Calculate delivery fee based on distance
     */
    private function calculateDeliveryFeeByDistance($distance)
    {
        $baseFee = config('app.base_delivery_fee', 5);
        $perKmFee = config('app.per_km_delivery_fee', 1);
        
        return $baseFee + ($distance * $perKmFee);
    }

    /**
     * Estimate delivery time based on distance
     */
    private function estimateDeliveryTime($distance)
    {
        $averageSpeed = config('app.delivery_speed_kmh', 30);
        $preparationTime = config('app.preparation_time_minutes', 15);
        
        return round($preparationTime + ($distance / $averageSpeed * 60), 0);
    }
}
