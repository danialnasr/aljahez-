<?php

namespace App\Services;

use App\Models\User;
use App\Models\Order;
use Exception;

class NotificationService
{
    public function sendOrderNotification(Order $order, string $type, User $recipient = null)
    {
        try {
            switch ($type) {
                case 'order_placed':
                    return $this->notifyMerchantsNewOrder($order);
                case 'order_accepted':
                    return $this->notifyCustomerOrderAccepted($order);
                case 'order_ready':
                    return $this->notifyDriverOrderReady($order);
                case 'order_picked_up':
                    return $this->notifyCustomerOrderPickedUp($order);
                case 'order_delivered':
                    return $this->notifyOrderDelivered($order);
                case 'order_cancelled':
                    return $this->notifyOrderCancelled($order);
                default:
                    throw new Exception('Unknown notification type');
            }
        } catch (Exception $e) {
            \Log::error("Notification failed: " . $e->getMessage());
            return false;
        }
    }

    private function notifyMerchantsNewOrder(Order $order)
    {
        $merchantIds = $order->items->pluck('merchant_id')->unique();

        foreach ($merchantIds as $merchantId) {
            $merchant = User::find($merchantId);

            $this->sendPushNotification($merchant, [
                'title' => 'New Order Received',
                'body' => "Order #{$order->order_number} - {$order->items->count()} items",
                'data' => [
                    'type' => 'new_order',
                    'order_id' => $order->id,
                    'order_number' => $order->order_number
                ]
            ]);

            $this->sendSMS($merchant->phone, "New order #{$order->order_number} received. Please check your app.");
        }

        return true;
    }

    private function notifyCustomerOrderAccepted(Order $order)
    {
        $customer = $order->customer;

        $this->sendPushNotification($customer, [
            'title' => 'Order Accepted',
            'body' => "Your order #{$order->order_number} has been accepted and is being prepared",
            'data' => [
                'type' => 'order_accepted',
                'order_id' => $order->id,
                'estimated_time' => $order->estimated_delivery_time
            ]
        ]);

        return true;
    }

    private function notifyDriverOrderReady(Order $order)
    {
        // Notify available drivers about ready order
        $availableDrivers = User::where('user_type', 'driver')
            ->where('is_active', true)
            ->where('is_online', true)
            ->get();

        foreach ($availableDrivers as $driver) {
            $this->sendPushNotification($driver, [
                'title' => 'Delivery Available',
                'body' => "Order #{$order->order_number} ready for pickup - ${$order->delivery_fee} delivery fee",
                'data' => [
                    'type' => 'delivery_available',
                    'order_id' => $order->id,
                    'delivery_fee' => $order->delivery_fee,
                    'tip' => $order->tip
                ]
            ]);
        }

        return true;
    }

    private function notifyCustomerOrderPickedUp(Order $order)
    {
        $customer = $order->customer;

        $this->sendPushNotification($customer, [
            'title' => 'Order Picked Up',
            'body' => "Your order is on the way! Driver: {$order->driver->full_name}",
            'data' => [
                'type' => 'order_picked_up',
                'order_id' => $order->id,
                'driver_name' => $order->driver->full_name,
                'driver_phone' => $order->driver->phone,
                'otp' => $order->customer_otp
            ]
        ]);

        $this->sendSMS($customer->phone, "Your order #{$order->order_number} is on the way! OTP: {$order->customer_otp}");

        return true;
    }

    private function notifyOrderDelivered(Order $order)
    {
        $customer = $order->customer;

        $this->sendPushNotification($customer, [
            'title' => 'Order Delivered',
            'body' => "Your order #{$order->order_number} has been delivered successfully!",
            'data' => [
                'type' => 'order_delivered',
                'order_id' => $order->id
            ]
        ]);

        // Notify driver
        if ($order->driver) {
            $this->sendPushNotification($order->driver, [
                'title' => 'Delivery Completed',
                'body' => "Order #{$order->order_number} delivered successfully. Earnings: ${$order->delivery_fee + $order->tip}",
                'data' => [
                    'type' => 'delivery_completed',
                    'order_id' => $order->id,
                    'earnings' => $order->delivery_fee + $order->tip
                ]
            ]);
        }

        return true;
    }

    private function notifyOrderCancelled(Order $order)
    {
        // Notify customer
        $this->sendPushNotification($order->customer, [
            'title' => 'Order Cancelled',
            'body' => "Your order #{$order->order_number} has been cancelled",
            'data' => [
                'type' => 'order_cancelled',
                'order_id' => $order->id
            ]
        ]);

        // Notify driver if assigned
        if ($order->driver) {
            $this->sendPushNotification($order->driver, [
                'title' => 'Delivery Cancelled',
                'body' => "Order #{$order->order_number} has been cancelled",
                'data' => [
                    'type' => 'delivery_cancelled',
                    'order_id' => $order->id
                ]
            ]);
        }

        // Notify merchants
        $merchantIds = $order->items->pluck('merchant_id')->unique();
        foreach ($merchantIds as $merchantId) {
            $merchant = User::find($merchantId);
            $this->sendPushNotification($merchant, [
                'title' => 'Order Cancelled',
                'body' => "Order #{$order->order_number} has been cancelled",
                'data' => [
                    'type' => 'order_cancelled',
                    'order_id' => $order->id
                ]
            ]);
        }

        return true;
    }

    public function sendPushNotification(User $user, array $notification)
    {
        if (!$user->fcm_token) {
            \Log::warning("No FCM token for user {$user->id}");
            return false;
        }

        try {
            // Integration with Firebase Cloud Messaging
            $fcmUrl = 'https://fcm.googleapis.com/fcm/send';
            $fcmKey = env('FCM_SERVER_KEY');

            if (!$fcmKey) {
                \Log::error('FCM_SERVER_KEY not configured');
                return false;
            }

            $headers = [
                'Authorization: key=' . $fcmKey,
                'Content-Type: application/json'
            ];

            $payload = [
                'to' => $user->fcm_token,
                'notification' => [
                    'title' => $notification['title'],
                    'body' => $notification['body'],
                    'sound' => 'default'
                ],
                'data' => $notification['data'] ?? []
            ];

            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $fcmUrl);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));

            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);

            if ($httpCode === 200) {
                \Log::info("Push notification sent to user {$user->id}");
                return true;
            } else {
                \Log::error("FCM request failed with code {$httpCode}: {$response}");
                return false;
            }

        } catch (Exception $e) {
            \Log::error("Push notification failed: " . $e->getMessage());
            return false;
        }
    }

    public function sendSMS(string $phone, string $message)
    {
        try {
            // Integration with Twilio SMS
            $twilioSid = env('TWILIO_SID');
            $twilioToken = env('TWILIO_TOKEN');
            $twilioFrom = env('TWILIO_FROM');
            if (!$twilioSid || !$twilioToken || !$twilioFrom) {
                \Log::warning('Twilio SMS service not configured');
                return false;
            }
            $client = new \Twilio\Rest\Client($twilioSid, $twilioToken);
            $client->messages->create($phone, [
                'from' => $twilioFrom,
                'body' => $message
            ]);
            \Log::info("SMS sent to {$phone}: {$message}");
            return true;
        } catch (\Exception $e) {
            \Log::error("SMS sending failed: " . $e->getMessage());
            return false;
        }
    }

    public function sendEmail(string $email, string $subject, string $body)
    {
        try {
            // Use Laravel's built-in mail functionality
            \Mail::raw($body, function ($message) use ($email, $subject) {
                $message->to($email)->subject($subject);
            });

            \Log::info("Email sent to {$email}");
            return true;

        } catch (Exception $e) {
            \Log::error("Email sending failed: " . $e->getMessage());
            return false;
        }
    }

    public function sendWhatsAppMessage(string $phone, string $message)
    {
        try {
            // Integration with Twilio WhatsApp
            $twilioSid = env('TWILIO_SID');
            $twilioToken = env('TWILIO_TOKEN');
            $twilioFromWhatsapp = env('TWILIO_FROM_WHATSAPP');
            if (!$twilioSid || !$twilioToken || !$twilioFromWhatsapp) {
                \Log::warning('Twilio WhatsApp service not configured');
                return false;
            }
            $client = new \Twilio\Rest\Client($twilioSid, $twilioToken);
            $client->messages->create("whatsapp:" . $phone, [
                'from' => $twilioFromWhatsapp,
                'body' => $message
            ]);
            \Log::info("WhatsApp sent to {$phone}: {$message}");
            return true;
        } catch (\Exception $e) {
            \Log::error("WhatsApp sending failed: " . $e->getMessage());
            return false;
        }
    }

    public function sendTelegramMessage(string $chatId, string $message)
    {
        try {
            $telegramBotToken = env('TELEGRAM_BOT_TOKEN');
            if (!$telegramBotToken) {
                \Log::warning('Telegram Bot Token not configured');
                return false;
            }
            $telegramApiUrl = "https://api.telegram.org/bot{$telegramBotToken}/sendMessage";
            $payload = [
                'chat_id' => $chatId,
                'text' => $message
            ];
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $telegramApiUrl);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($payload));
            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);
            if ($httpCode === 200) {
                \Log::info("Telegram sent to {$chatId}: {$message}");
                return true;
            } else {
                \Log::error("Telegram API failed with code {$httpCode}: {$response}");
                return false;
            }
        } catch (\Exception $e) {
            \Log::error("Telegram sending failed: " . $e->getMessage());
            return false;
        }
    }

    public function updateFCMToken(User $user, string $token)
    {
        $user->update(['fcm_token' => $token]);
        \Log::info("FCM token updated for user {$user->id}");
    }
}

