import os
import shutil
import datetime
import subprocess

# إعدادات المسارات
PROJECT_DIR = os.path.dirname(os.path.abspath(__file__))
BACKUP_DIR = os.path.join(PROJECT_DIR, 'backup')
DB_SQLITE = os.path.join(PROJECT_DIR, 'database', 'database.sqlite')
DB_MYSQL_NAME = os.environ.get('DB_DATABASE', 'delivery_system')
DB_MYSQL_USER = os.environ.get('DB_USERNAME', 'root')
DB_MYSQL_PASS = os.environ.get('DB_PASSWORD', '')
DB_MYSQL_HOST = os.environ.get('DB_HOST', 'localhost')

os.makedirs(BACKUP_DIR, exist_ok=True)
date_str = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')

# نسخ احتياطي لقاعدة البيانات
if os.path.exists(DB_SQLITE):
    backup_db = os.path.join(BACKUP_DIR, f'database_{date_str}.sqlite')
    shutil.copy2(DB_SQLITE, backup_db)
    print(f'SQLite DB backup done: {backup_db}')
else:
    # جرب MySQL
    try:
        backup_db = os.path.join(BACKUP_DIR, f'database_{date_str}.sql')
        cmd = [
            'mysqldump',
            f'-u{DB_MYSQL_USER}',
            f'-p{DB_MYSQL_PASS}',
            f'-h{DB_MYSQL_HOST}',
            DB_MYSQL_NAME
        ]
        with open(backup_db, 'w', encoding='utf-8') as f:
            subprocess.run(cmd, stdout=f, check=True)
        print(f'MySQL DB backup done: {backup_db}')
    except Exception as e:
        print('No database found or backup failed:', e)

# نسخ احتياطي للملفات (باستثناء vendor, node_modules, storage/logs)
archive_name = os.path.join(BACKUP_DIR, f'delivery-system_{date_str}.tar.gz')
exclude = ['vendor', 'node_modules', 'storage/logs', 'backup']
def exclude_filter(tarinfo):
    for ex in exclude:
        if ex in tarinfo.name:
            return None
    return tarinfo
import tarfile
with tarfile.open(archive_name, 'w:gz') as tar:
    for item in os.listdir(PROJECT_DIR):
        if item in exclude or item.startswith('.'):
            continue
        tar.add(os.path.join(PROJECT_DIR, item), arcname=item, filter=exclude_filter)
print(f'Project files backup done: {archive_name}')
