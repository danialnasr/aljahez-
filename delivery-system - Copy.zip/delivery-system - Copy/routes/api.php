<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\AuthController;
use App\Http\Controllers\Api\OrderController;
use App\Http\Controllers\Api\ProductController;
use App\Http\Controllers\Api\UserController;
use App\Http\Controllers\Api\DriverController;
use App\Http\Controllers\Api\MerchantController;
use App\Http\Controllers\Api\CategoryController;
use App\Http\Controllers\Api\ComplaintController;
use App\Http\Controllers\Api\RatingController;
use App\Http\Controllers\Api\WalletController;
use App\Http\Controllers\Api\LoyaltyController;
use App\Http\Controllers\Api\AdminController;
use App\Http\Controllers\Api\MapsController;
use App\Http\Controllers\Api\DashboardController;
use App\Http\Controllers\Api\ReportsController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/

// Public routes
Route::prefix('v1')->group(function () {

    // Authentication routes
    Route::prefix('auth')->group(function () {
        Route::post('send-otp', [AuthController::class, 'sendOTP']);
        Route::post('verify-otp', [AuthController::class, 'verifyOTP']);
        Route::post('register', [AuthController::class, 'register']);
        Route::post('test-otp', [AuthController::class, 'generateTestOTP']); // Development only
    });

    // Public product and category routes
    Route::get('categories', [CategoryController::class, 'index']);
    Route::get('products', [ProductController::class, 'index']);
    Route::get('products/{id}', [ProductController::class, 'show']);
    Route::get('products/search', [ProductController::class, 'search']);
    Route::get('merchants', [MerchantController::class, 'index']);

    // Protected routes
    Route::middleware('auth:sanctum')->group(function () {

        // Authentication
        Route::prefix('auth')->group(function () {
            Route::post('logout', [AuthController::class, 'logout']);
            Route::get('me', [AuthController::class, 'me']);
            Route::post('refresh-token', [AuthController::class, 'refreshToken']);
        });

        // User management
        Route::prefix('user')->group(function () {
            Route::get('profile', [UserController::class, 'profile']);
            Route::put('profile', [UserController::class, 'updateProfile']);
            Route::post('profile/image', [UserController::class, 'uploadImage']);
            Route::put('profile/location', [UserController::class, 'updateLocation']);
            Route::post('change-password', [UserController::class, 'changePassword']);
        });

        // Orders
        Route::prefix('orders')->group(function () {
            Route::get('/', [OrderController::class, 'index']);
            Route::post('/', [OrderController::class, 'store']);
            Route::get('{id}', [OrderController::class, 'show']);
            Route::put('{id}/status', [OrderController::class, 'updateStatus']);
            Route::post('{id}/verify-delivery', [OrderController::class, 'verifyDelivery']);
            Route::post('{id}/accept-delivery', [OrderController::class, 'acceptDelivery']);
            Route::post('{id}/cancel', [OrderController::class, 'cancel']);
        });

        // Products (for merchants)
        Route::prefix('products')->middleware('merchant')->group(function () {
            Route::post('/', [ProductController::class, 'store']);
            Route::put('{id}', [ProductController::class, 'update']);
            Route::delete('{id}', [ProductController::class, 'destroy']);
            Route::post('{id}/toggle-availability', [ProductController::class, 'toggleAvailability']);
        });

        // Categories (admin only)
        Route::prefix('categories')->middleware('admin')->group(function () {
            Route::post('/', [CategoryController::class, 'store']);
            Route::put('{id}', [CategoryController::class, 'update']);
            Route::delete('{id}', [CategoryController::class, 'destroy']);
        });

        // Driver routes
        Route::prefix('driver')->middleware('driver')->group(function () {
            Route::post('online', [DriverController::class, 'goOnline']);
            Route::post('offline', [DriverController::class, 'goOffline']);
            Route::get('orders', [DriverController::class, 'getOrders']);
            Route::post('orders/{id}/accept', [DriverController::class, 'acceptOrder']);
            Route::get('earnings', [DriverController::class, 'getEarnings']);
            Route::get('stats', [DriverController::class, 'getStats']);
            Route::put('location', [DriverController::class, 'updateLocation']);
        });

        // Merchant routes
        Route::prefix('merchant')->middleware('merchant')->group(function () {
            Route::get('orders', [MerchantController::class, 'getOrders']);
            Route::post('orders/{id}/accept', [MerchantController::class, 'acceptOrder']);
            Route::post('orders/{id}/reject', [MerchantController::class, 'rejectOrder']);
            Route::get('reports', [MerchantController::class, 'getReports']);
            Route::get('stats', [MerchantController::class, 'getStats']);
            Route::put('working-hours', [MerchantController::class, 'updateWorkingHours']);
            Route::get('profile', [MerchantController::class, 'getProfile']);
        });

        // Wallet
        Route::prefix('wallet')->group(function () {
            Route::get('/', [WalletController::class, 'getBalance']);
            Route::post('topup', [WalletController::class, 'topup']);
            Route::get('transactions', [WalletController::class, 'getTransactions']);
            Route::post('withdraw', [WalletController::class, 'withdraw']);
        });

        // Loyalty points
        Route::prefix('loyalty')->group(function () {
            Route::get('points', [LoyaltyController::class, 'getPoints']);
            Route::post('redeem', [LoyaltyController::class, 'redeemPoints']);
            Route::get('transactions', [LoyaltyController::class, 'getTransactions']);
            Route::get('rewards', [LoyaltyController::class, 'getAvailableRewards']);
        });

        // Complaints
        Route::prefix('complaints')->group(function () {
            Route::get('/', [ComplaintController::class, 'index']);
            Route::post('/', [ComplaintController::class, 'store']);
            Route::get('{id}', [ComplaintController::class, 'show']);
            Route::put('{id}/status', [ComplaintController::class, 'updateStatus']);
            Route::post('{id}/response', [ComplaintController::class, 'addResponse']);
        });

        // Ratings
        Route::prefix('ratings')->group(function () {
            Route::post('/', [RatingController::class, 'store']);
            Route::get('user/{id}', [RatingController::class, 'getUserRatings']);
            Route::get('my-ratings', [RatingController::class, 'getMyRatings']);
            Route::put('{id}', [RatingController::class, 'update']);
            Route::delete('{id}', [RatingController::class, 'destroy']);
        });

        // Admin routes
        Route::prefix('admin')->middleware('admin')->group(function () {
            Route::get('dashboard', [AdminController::class, 'dashboard']);
            Route::get('users', [AdminController::class, 'getUsers']);
            Route::post('users/{id}/activate', [AdminController::class, 'activateUser']);
            Route::post('users/{id}/deactivate', [AdminController::class, 'deactivateUser']);
            Route::get('orders', [AdminController::class, 'getAllOrders']);
            Route::get('complaints', [AdminController::class, 'getComplaints']);
            Route::post('complaints/{id}/resolve', [AdminController::class, 'resolveComplaint']);
            Route::get('reports', [AdminController::class, 'getReports']);
        });
    });
});

// Middleware definitions would be in app/Http/Kernel.php
// 'merchant' => \App\Http\Middleware\MerchantMiddleware::class,
// 'driver' => \App\Http\Middleware\DriverMiddleware::class,
// 'admin' => \App\Http\Middleware\AdminMiddleware::class,

